"""Blank parameter template matching the tool's fixed layout (rows 1–3 headers, data from row 4, columns A–N)."""
import sys, openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.comments import Comment

out = sys.argv[1]
src = openpyxl.load_workbook('/home/claude/data/week1.xlsx')
wb = openpyxl.Workbook()

# --- Instructions
ins = wb.active; ins.title = 'Instructions'
lines = [
 ('How to fill in this template', True),
 ('', False),
 ('1. Enter one print per row on the "Parameters" sheet, starting at row 4. Do not change rows 1–3 or the column order.', False),
 ('2. Columns A–N are read by the Print Parameter Explorer; anything to the right of column N is ignored (use it for notes).', False),
 ('3. Required in every row: S/N, Material, Temperature, e1, v1, a1, t1, Clarity, Stability.', False),
 ('4. Blank or "-" is allowed for: Colour (read as "unspecified"), Layer Height (read as 2 mm), e2 / v2 / a2 (read as "not used").', False),
 ('5. Clarity and Stability must be whole numbers 1–5 (see "Grading Metrics").', False),
 ('6. Numbers only in numeric columns – no units, no text. Units: mm, °C, mm/s, mm/s², s.', False),
 ('7. S/N should follow the order in which prints were made: the History view assumes S/N order = test order.', False),
 ('8. Cell colours and fills are ignored by the tool.', False),
 ('9. Keep the data on a sheet whose cell A2 reads "S/N". If several sheets do, the first one is used.', False),
 ('', False),
 ('Recording anything else that changed (geometry, filament reel, nozzle…)? Note it in a column right of N.', False),
 ('The tool will not use it, but you will need it to explain unexpected results.', False),
]
for i, (t, b) in enumerate(lines, 1):
    ins.cell(i, 1, t).font = Font(bold=b, size=12 if b else 11)
ins.column_dimensions['A'].width = 120

# --- Grading Metrics (copied from week 1 file)
gm = wb.create_sheet('Grading Metrics')
for row in src['Grading Metrics'].iter_rows():
    for c in row:
        if c.value is not None: gm.cell(c.row, c.column, c.value)
for c in ('A1', 'B1', 'C1'): gm[c].font = Font(bold=True)
gm.column_dimensions['A'].width = 14; gm.column_dimensions['B'].width = 14; gm.column_dimensions['C'].width = 110

# --- Parameters
ws = wb.create_sheet('Parameters')
hdr = Font(bold=True); ctr = Alignment(horizontal='center', vertical='center', wrap_text=True)
grey = PatternFill('solid', fgColor='EDEDED'); thin = Side(style='thin', color='BFBFBF')
ws['B1'] = 'Essential Printing Parameters'; ws.merge_cells('B1:L1')
ws['M1'] = 'Grading'; ws.merge_cells('M1:N1')
row2 = {'A': 'S/N', 'B': 'Material', 'C': 'Colour', 'D': 'Layer Height', 'E': 'Temperature',
        'F': 'Extrusion Speed', 'H': 'Robot Velocity', 'J': 'Acceleration', 'L': 'Pause Time', 'M': 'Clarity', 'N': 'Stability'}
for col, v in row2.items(): ws[col + '2'] = v
for rng in ('A2:A3', 'B2:B3', 'C2:C3', 'D2:D3', 'E2:E3', 'F2:G2', 'H2:I2', 'J2:K2', 'M2:M3', 'N2:N3'): ws.merge_cells(rng)
for col, v in zip('FGHIJKL', ['e1', 'e2', 'v1', 'v2', 'a1', 'a2', 't1']): ws[col + '3'] = v
for r in (1, 2, 3):
    for col in 'ABCDEFGHIJKLMN':
        c = ws[col + str(r)]; c.font = hdr; c.alignment = ctr; c.fill = grey; c.border = Border(bottom=thin, right=thin)
units = {'D': 'mm', 'E': '°C', 'F': 'mm/s', 'G': 'mm/s (blank = not used)', 'H': 'mm/s', 'I': 'mm/s (blank = not used)',
         'J': 'mm/s²', 'K': 'mm/s² (blank = not used)', 'L': 's', 'C': 'blank = "unspecified"', 'M': 'whole number 1–5', 'N': 'whole number 1–5'}
for col, u in units.items():
    cell = ws[col + ('3' if col in 'FGHIJKL' else '2')]
    cell.comment = Comment('Unit / rule: ' + u + ('. Blank = 2 mm.' if col == 'D' else ''), 'Template')
widths = {'A': 7, 'B': 18, 'C': 14, 'D': 13, 'E': 13, 'F': 9, 'G': 9, 'H': 9, 'I': 9, 'J': 9, 'K': 9, 'L': 9, 'M': 10, 'N': 10, 'O': 40}
for k, w in widths.items(): ws.column_dimensions[k].width = w
ws['O2'] = 'Notes (ignored by the tool)'; ws['O2'].font = Font(italic=True, color='808080')
ws.freeze_panes = 'B4'
last = 500
score = DataValidation(type='whole', operator='between', formula1='1', formula2='5', allow_blank=True,
                       showErrorMessage=True, errorTitle='Score', error='Clarity and Stability must be whole numbers from 1 to 5.')
num = DataValidation(type='decimal', operator='greaterThanOrEqual', formula1='0', allow_blank=True,
                     showErrorMessage=True, errorTitle='Number', error='Enter a number (no units). Leave blank or "-" only where allowed.')
num.errorStyle = 'warning'  # a warning, so "-" can still be typed where blanks are allowed
ws.add_data_validation(score); ws.add_data_validation(num)
score.add(f'M4:N{last}'); num.add(f'D4:L{last}')
wb.move_sheet('Parameters', offset=-2)  # Parameters first
wb.active = 0
wb.save(out); print('saved', out)
