"""Font audit: every visible text element on the page and in the plot must resolve to Roboto; PDF text must use Roboto only."""
import sys, re, zlib, subprocess
from playwright.sync_api import sync_playwright
html = sys.argv[1] if len(sys.argv) > 1 else 'file:///home/claude/build/dist/print_parameter_explorer.html'
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1400,'height':1000}, accept_downloads=True)
    pg.goto(html); pg.set_input_files('#file','/home/claude/data/week1.xlsx'); pg.wait_for_timeout(1000)
    pg.click('#guide summary'); pg.click('#dataDetails summary'); pg.click('#printsDetails summary')
    res={}
    for v in ['map2d','scatter','history']:
        pg.click(f'#viewSeg button[data-v={v}]'); pg.wait_for_timeout(500)
        if v=='history': pg.select_option('#topN','3'); pg.wait_for_timeout(300)
        bad=pg.evaluate("""(()=>{const out={};
          for (const e of document.querySelectorAll('body *')) {
            const own=[...e.childNodes].some(n=>n.nodeType===3&&n.textContent.trim()) || ['SELECT','INPUT','BUTTON','OPTION'].includes(e.tagName);
            if(!own) continue; const r=e.getBoundingClientRect(); if(!r.width&&e.tagName!=='OPTION') continue;
            const f=getComputedStyle(e).fontFamily.split(',')[0].replace(/["']/g,'').trim();
            if(f!=='Roboto'){const k=e.tagName+'.'+(e.getAttribute('class')||'')+' → '+getComputedStyle(e).fontFamily; out[k]=(out[k]||0)+1;}
          } return out;})()""")
        res[v]=bad
    print('elements whose font is not Roboto, per view:', res)
    print('Roboto weights loaded:', pg.evaluate("Promise.all([400,500,700].map(w=>document.fonts.load(w+' 14px Roboto'))).then(()=>[...document.fonts].filter(f=>f.family.replace(/\\\"/g,'')==='Roboto'&&f.status==='loaded').map(f=>f.weight))"))
    # PDF font usage
    pg.select_option('#exFormat','pdf')
    with pg.expect_download() as d: pg.click('#exGo')
    d.value.save_as('/tmp/audit.pdf'); b.close()
pdf=open('/tmp/audit.pdf','rb').read()
fontres={}
for m in re.finditer(rb'(\d+) 0 obj\s*<<(.*?)>>', pdf, re.S):
    bf=re.search(rb'/BaseFont\s*/([\w+-]+)', m.group(2))
    if bf: fontres[m.group(1).decode()]=bf.group(1).decode()
used=set()
for m in re.finditer(rb'stream\r?\n(.*?)\r?\nendstream', pdf, re.S):
    try: s=zlib.decompress(m.group(1))
    except Exception: s=m.group(1)
    for f in re.findall(rb'/(F\d+)\s+[\d.]+\s+Tf', s): used.add(f.decode())
# map /F names via the font dictionary
fmap={}
for m in re.finditer(rb'/(F\d+)\s+(\d+) 0 R', pdf): fmap[m.group(1).decode()]=fontres.get(m.group(2).decode(),'?')
print('PDF fonts actually used for text:', sorted({fmap.get(u,'?') for u in used}))
