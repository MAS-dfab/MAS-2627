from playwright.sync_api import sync_playwright
import re
R=[]
def ok(n,c,i=''): R.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n+((' ['+str(i)+']') if i!='' else ''))
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1400,'height':1000}, accept_downloads=True); errs=[]
    pg.on('pageerror',lambda e: errs.append(str(e))); pg.on('console',lambda m: m.type=='error' and errs.append(m.text))
    pg.goto('file:///home/claude/build/dist/print_parameter_explorer.html'); pg.set_input_files('#file','/home/claude/data/week1.xlsx'); pg.wait_for_timeout(1000)
    W=lambda ms=400: pg.wait_for_timeout(ms); gd=lambda js: pg.evaluate("(()=>{const gd=document.getElementById('plot');return "+js+"})()")
    pg.click('#viewSeg button[data-v=history]'); W()
    ok('top-n off by default: no bands, no table', gd("(gd.layout.shapes||[]).length")==0 and not pg.is_visible('#topBox'))
    pg.select_option('#topN','3'); W()
    ok('top 3 weakest-score: 9 bands (ties)', gd("gd.layout.shapes.length")==9)
    ok('rank labels #1 x9', gd("gd.layout.annotations.filter(a=>a.text==='#1').length")==9)
    ok('default ring rendered white', gd("getComputedStyle(gd.querySelector('.scatterlayer .trace:last-child .point')).stroke")=='rgb(255, 255, 255)', gd("getComputedStyle(gd.querySelector('.scatterlayer .trace:last-child .point')).stroke"))
    ok('rings on both scores: 18', gd("gd.data.find(t=>t.meta==='top|callout').x.length")==18)
    ok('table 9 rows', pg.eval_on_selector_all('#topBox tbody tr','e=>e.length')==9)
    ok('tie note shown', 'tied at the cut-off' in pg.inner_text('#matchBox'))
    pg.select_option('#rankBy','clarity'); W(); ok('rank by clarity: 12 bands, rings on clarity only', gd("gd.layout.shapes.length")==12 and gd("gd.data.find(t=>t.meta==='top|callout').x.length")==12)
    pg.select_option('#rankBy','sum'); pg.select_option('#topN','10'); W(); ok('sum top10: 12 incl. #10 ties', gd("gd.layout.annotations.filter(a=>a.text==='#10').length")==3 and pg.eval_on_selector_all('#topBox tbody tr','e=>e.length')==12)
    pg.select_option('#rankBy','min'); pg.select_option('#topN','3'); W()
    # line types
    pg.select_option('#chips select[data-dkey="hist|clarity"]','dot'); W(); ok('clarity dash = dot', gd("gd.data.find(t=>t.meta==='hist|clarity').line.dash")=='dot')
    pg.select_option('#chips select[data-dkey="hist|temp"]','solid'); W(); ok('overlay temp dash = solid', gd("gd.data.find(t=>t.meta==='hist|temp').line.dash")=='solid')
    ok('no dash selector on callouts', pg.eval_on_selector_all('#chips select[data-dkey="top|callout"]','e=>e.length')==0)
    # callout colour + opacity
    pg.eval_on_selector('#chips input[data-key="top|callout"]','e=>{e.value="#ffd400";e.dispatchEvent(new Event("input"));e.dispatchEvent(new Event("change"))}'); W()
    pg.eval_on_selector('#chips input[data-okey="top|callout"]','e=>{e.value=50;e.dispatchEvent(new Event("input"));e.dispatchEvent(new Event("change"))}'); W()
    ok('callout colour & 50% opacity', gd("gd.data.find(t=>t.meta==='top|callout').marker.color")=='#ffd400' and gd("getComputedStyle(gd.querySelector('.scatterlayer .trace:last-child .point')).stroke")=='rgb(255, 212, 0)' and gd("gd.layout.annotations.find(a=>a.text==='#1').font.color")=='rgba(255,212,0,0.5)')
    # persists across views
    pg.click('#viewSeg button[data-v=map2d]'); W(); ok('top table hidden in other views', not pg.is_visible('#topBox'))
    pg.click('#viewSeg button[data-v=history]'); W(); ok('settings kept on return', gd("gd.layout.shapes.length")==9 and gd("gd.data.find(t=>t.meta==='hist|clarity').line.dash")=='dot')
    pg.locator('#plot').scroll_into_view_if_needed(); pos=gd("(()=>{const xa=gd._fullLayout.xaxis,ya=gd._fullLayout.yaxis,r=gd.getBoundingClientRect();return [r.left+xa._offset+xa.l2p(13),r.top+ya._offset+ya._length/2]})()")
    for dx in (-2,0,1): pg.mouse.move(pos[0]+dx,pos[1]); W(150)
    W(300); ht=gd("Array.from(document.querySelectorAll('#plot .hoverlayer text')).map(t=>t.textContent).join(' | ')"); ok('hover on top S/N mentions rank', 'Top result #1' in ht, ht[:100])
    pg.screenshot(path='s7_top.png', full_page=True)
    # exports
    def export(fmt,bg,size,name):
        pg.select_option('#exFormat',fmt); pg.select_option('#exBg',bg); pg.select_option('#exSize',size)
        with pg.expect_download(timeout=60000) as d: pg.click('#exGo')
        path='exports3/'+name+d.value.suggested_filename; d.value.save_as(path); W(200); return path
    s=open(export('svg','black','uhd','E_')).read()
    ok('SVG: dotted clarity (dasharray) + 9 bands + caption top line', 'stroke-dasharray: 3px, 3px' in s and s.count('#1</text>')>=1 and 'Top 3 by weakest score' in s)
    pdf=open(export('pdf','black','a4','E_'),'rb').read(); ok('PDF exported', pdf[:4]==b'%PDF')
    ok('PNG exported', open(export('png','transparent','uhd','E_'),'rb').read()[:4]==b'\x89PNG')
    pg.click('#resetCol'); W(); ok('reset clears line types', gd("gd.data.find(t=>t.meta==='hist|clarity').line.dash")=='solid')
    ok('no browser errors', not errs, errs[:2]); b.close()
print('TOTAL',len(R),'PASSED',sum(r[1] for r in R),'FAILED',[r[0] for r in R if not r[1]])
