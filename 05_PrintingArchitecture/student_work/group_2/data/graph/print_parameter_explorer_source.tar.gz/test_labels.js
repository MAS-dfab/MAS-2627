global.PrintSelect=require('./src/select.js'); global.PrintDelaunay=require('./src/delaunay.js');
const XLSX=require('xlsx'),P=require('./src/parse.js'),PL=require('./src/plots.js'),S=PrintSelect;
const rows=P.parseWorkbook(XLSX.readFile('../data/week1.xlsx'),XLSX).rows, info=S.paramInfo(rows);
const ax=info.filter(i=>i.axisOK).map(i=>i.key); let bad=0,n=0;
const sels=[];
for(const x of ax){ for(const y of ax) if(y!==x){ sels.push({view:'map2d',x,y}); } }
for(const c of info.filter(i=>i.varies)) sels.push({view:'scatter',colorBy:c.key});
for(const s0 of sels) for (const score of ['clarity','stability']) {
  const s=Object.assign({allRows:rows,score},s0); const f=PL.build(s,info,{ramp:PL.RAMPS.blue,overrides:{},labels:true});
  const labs=[]; f.data.filter(t=>t.text).forEach(t=>t.text.forEach(x=>x&&x.split(/, |<br>/).forEach(v=>labs.push(v))));
  const exp=f.rows.map(r=>r.sn).sort(); const got=labs.slice().sort();
  // hover count must equal marker count, and every plotted row has a marker
  const markerCount=f.data.filter(t=>t.text).reduce((a,t)=>a+t.text.length,0);
  const hoverCount=f.data.filter(t=>t.text).reduce((a,t)=>a+t.hovertemplate.length,0);
  n++; if(JSON.stringify(exp)!==JSON.stringify(got)||markerCount!==hoverCount){bad++;console.log('BAD',JSON.stringify(s0),score,exp.length,got.length);}
}
console.log('views checked',n,'problems',bad);
