from playwright.sync_api import sync_playwright
import struct, re, zlib, subprocess
def pagesize(f):
    m=re.search(r'Page size:\s+([\d.]+) x ([\d.]+) pts', subprocess.run(['pdfinfo',f],capture_output=True,text=True).stdout)
    return (round(float(m.group(1)),2), round(float(m.group(2)),2))
R=[]
def ok(name, cond, info=''):
    R.append((name, bool(cond))); print(('PASS ' if cond else 'FAIL ')+name+(('  ['+str(info)+']') if info else ''))
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1400,'height':1000}, accept_downloads=True); errs=[]
    pg.on('pageerror',lambda e: errs.append(str(e))); pg.on('console',lambda m: m.type=='error' and errs.append(m.text))
    pg.goto('file:///home/claude/build/dist/print_parameter_explorer.html')
    W=lambda ms=400: pg.wait_for_timeout(ms)
    gd=lambda js: pg.evaluate("(()=>{const gd=document.getElementById('plot');return "+js+"})()")
    # ---- loading
    pg.set_input_files('#file','testfiles/bad_header.xlsx'); W()
    ok('bad header rejected, panels hidden', 'does not match the template' in pg.inner_text('#messages') and not pg.is_visible('#selSection') and not pg.is_visible('#exportSection'))
    pg.set_input_files('#file','testfiles/not_template.xlsx'); W(); ok('non-template file rejected', 'No sheet has' in pg.inner_text('#messages'))
    pg.set_input_files('#file','testfiles/bad_rows.xlsx'); W(); ok('bad rows: 5 skipped, 29 loaded', '5 row(s) skipped' in pg.inner_text('#messages') and gd("getSelection_().fig.rows.length")==29)
    pg.set_input_files('#file','testfiles/blank_colour.xlsx'); W(); ok('blank colour -> unspecified', 'unspecified' in pg.text_content('#summary'))
    pg.set_input_files('#file','/home/claude/data/week1.xlsx'); W(900)
    ok('week1 loads clean', 'No problems found' in pg.inner_text('#messages') and pg.eval_on_selector_all('#table tbody tr','e=>e.length')==33)
    asp=lambda: gd("Math.round(gd.getBoundingClientRect().width/gd.getBoundingClientRect().height*1000)/1000")
    ok('B preview is 16:9', abs(asp()-16/9)<0.01, asp())
    ok('views = B, D, E', pg.eval_on_selector_all('#viewSeg button','b=>b.map(x=>x.dataset.v)')==['map2d','scatter','history'])
    # ---- B 2D map
    ok('B default temp x e1, 33 prints', gd("[getSelection_().sel.x,getSelection_().sel.y,getSelection_().fig.rows.length].join()")=='temp,e1,33')
    pg.select_option('#selX','lh'); pg.select_option('#selY','v1'); pg.select_option('#selZ','stability'); W()
    ok('B axis/score change', gd("gd.layout.xaxis.title.text+'|'+gd.layout.yaxis.title.text+'|'+gd.data.filter(t=>t.meta&&t.meta.startsWith('score')).map(t=>t.name).join(',')").startswith('Layer Height (mm)|Robot v1 (mm/s)|Stability'))
    pg.select_option('#selX','temp'); pg.select_option('#selY','e1'); pg.select_option('#selZ','clarity'); W()
    pg.uncheck('#cbLabels'); W(); ok('labels off', gd("gd.data.filter(t=>t.meta&&t.meta.startsWith('score')).every(t=>t.mode==='markers')"))
    pg.check('#cbLabels'); W(); ok('labels on', gd("gd.data.filter(t=>t.meta&&t.meta.startsWith('score')).every(t=>t.mode==='markers+text')"))
    pg.select_option('#selScheme','aqua'); W(); ok('scheme aqua: score 5 colour', gd("gd.data.find(t=>t.meta==='score|5').marker.color")=='#c6f0df')
    pg.select_option('#selScheme','custom'); W(); pg.eval_on_selector('#cLo','e=>{e.value="#ff0000";e.dispatchEvent(new Event("input"))}'); pg.eval_on_selector('#cHi','e=>{e.value="#0000ff";e.dispatchEvent(new Event("input"))}'); W()
    ok('custom scheme ends', gd("[gd.data.find(t=>t.meta==='score|1').marker.color,gd.data.find(t=>t.meta==='score|5').marker.color].join()")=='#ff0000,#0000ff')
    pg.select_option('#selScheme','blue'); W()
    pg.eval_on_selector('#chips input[data-key="score|2"]','e=>{e.value="#ffff00";e.dispatchEvent(new Event("input"));e.dispatchEvent(new Event("change"))}'); W()
    ok('colour override score|2', gd("gd.data.find(t=>t.meta==='score|2').marker.color")=='#ffff00')
    def slide(key,val):
        pg.eval_on_selector(f'#chips input[data-okey="{key}"]',f'e=>{{e.value={val};e.dispatchEvent(new Event("input"));e.dispatchEvent(new Event("change"))}}'); W()
    slide('score|3',20); ok('opacity score|3 = 0.2', gd("gd.data.find(t=>t.meta==='score|3')._fade")==0.2)
    slide('link|map',0); ok('opacity connection lines = 0', gd("gd.data.find(t=>t.meta==='link|map')._fade")==0)
    ok('chip shows %', '20%' in pg.inner_text('#chips'))
    ok('other traces untouched', gd("gd.data.find(t=>t.meta==='score|5')._fade")==None)
    # hover on a point
    pg.locator('#plot').scroll_into_view_if_needed()
    pos=gd("(()=>{const t=gd._fullData.find(t=>t.meta==='score|5');const xa=gd._fullLayout.xaxis,ya=gd._fullLayout.yaxis,r=gd.getBoundingClientRect();return [r.left+xa._offset+xa.l2p(t.x[0]),r.top+ya._offset+ya.l2p(t.y[0])]})()")
    pg.mouse.move(pos[0],pos[1]); W(500); ok('B hover shows settings', 'S/N' in gd("Array.from(document.querySelectorAll('#plot .hoverlayer text')).map(t=>t.textContent).join(' ')"))
    # ---- B export with opacity
    def export(fmt,bg,size,text='standard',name=''):
        pg.select_option('#exFormat',fmt); pg.select_option('#exBg',bg); pg.select_option('#exSize',size)
        with pg.expect_download(timeout=60000) as d: pg.click('#exGo')
        path='exports2/'+name+d.value.suggested_filename; d.value.save_as(path); W(200); return path
    f=export('svg','black','hd',name='B_'); s=open(f).read()
    ok('B SVG: faded trace opacity 0.2 present', re.search(r'(opacity:\s*0\.2|,\s*0\.2\))', s) is not None)
    ok('B SVG: Roboto embedded', '@font-face' in s and 'font/woff2' in s)
    f=export('pdf','transparent','a4',name='B_'); pdf=open(f,'rb').read()
    ok('B PDF: transparency state written', re.search(rb'/CA 0\.2|/ca 0\.2', pdf) is not None)
    ok('B PDF: Roboto embedded', b'Roboto' in pdf and b'FontFile2' in pdf)
    ok('B PDF: A4 page', pagesize(f)==(841.89,595.28), pagesize(f))
    for size,dims,dpi in [('hd',(1920,1080),144),('uhd',(3840,2160),288),('a4',(3508,2480),300),('a3',(4961,3508),300)]:
        f=export('png','black',size,name='B_'); d=open(f,'rb').read(); wh=struct.unpack('>II',d[16:24]); i=d.find(b'pHYs')
        got_dpi=round(struct.unpack('>I',d[i+4:i+8])[0]*0.0254) if i>0 else None
        ok(f'B PNG {size}: {dims[0]}x{dims[1]} @ {dpi} dpi', wh==dims and got_dpi==dpi, (wh,got_dpi))
    f=export('pdf','black','uhd',name='B169_'); pdf=open(f,'rb').read()
    ok('B PDF 16:9 slide page 960x540 pt', pagesize(f)==(960.0,540.0), pagesize(f))
    f=export('png','transparent','a3',name='Bt_'); d=open(f,'rb').read(); ok('PNG transparent RGBA + 300dpi', d[25]==6 and b'pHYs' in d)
    # reset
    pg.click('#resetCol'); W(); ok('reset colours & opacity', gd("gd.data.every(t=>t._fade===undefined)") and pg.evaluate("Object.keys(SEL_STATE.overrides).length+Object.keys(SEL_STATE.opacity).length")==0)
    # ---- D
    pg.click('#viewSeg button[data-v=scatter]'); W()
    for c in pg.eval_on_selector_all('#selC option','o=>o.map(x=>x.value)'):
        pg.select_option('#selC',c); W(250)
        n=gd("gd.data.reduce((a,t)=>a+t.x.length,0)")
        ok(f'D colour by {c}: all prints shown', gd("getSelection_().fig.rows.length")==33 and n>=1)
    pg.select_option('#selC','material'); W(); slide('material|PLA NX1',30)
    ok('D preview is 16:9', abs(asp()-16/9)<0.01, asp())
    ok('D opacity on PLA', gd("gd.data.find(t=>t.meta==='material|PLA NX1')._fade")==0.3)
    f=export('png','black','uhd',name='D_'); ok('D PNG export', open(f,'rb').read()[:4]==b'\x89PNG')
    f=export('pdf','black','a4',name='D_'); ok('D PDF export', open(f,'rb').read()[:4]==b'%PDF')
    # ---- E
    pg.click('#viewSeg button[data-v=history]'); W()
    ok('E preview is 16:9', abs(asp()-16/9)<0.01, asp())
    ok('E default overlay temp', gd("getSelection_().fig.overlays.join()")=='temp')
    pg.select_option('#ov2','lh'); W(); ok('E two overlays', gd("getSelection_().fig.overlays.join()")=='temp,lh' and gd("!!gd.layout.yaxis3"))
    pg.select_option('#ov1','lh'); W(); ok('E duplicate overlay prevented', gd("getSelection_().fig.overlays.join()")=='lh')
    pg.select_option('#ov1','temp'); pg.select_option('#ov2','e1'); W()
    slide('hist|stability',15); slide('hist|e1',40)
    ok('E opacity stability 0.15, e1 0.4', gd("[gd.data.find(t=>t.meta==='hist|stability')._fade,gd.data.find(t=>t.meta==='hist|e1')._fade].join()")=='0.15,0.4')
    pg.locator('#plot').scroll_into_view_if_needed()
    pos=gd("(()=>{const xa=gd._fullLayout.xaxis,ya=gd._fullLayout.yaxis,r=gd.getBoundingClientRect();return [r.left+xa._offset+xa.l2p(22),r.top+ya._offset+ya._length/2]})()")
    for dx in (-2,0,1): pg.mouse.move(pos[0]+dx,pos[1]); W(150)
    W(400); ht=gd("Array.from(document.querySelectorAll('#plot .hoverlayer text')).map(t=>t.textContent).join(' | ')")
    ok('E unified hover (faded lines still listed)', 'Stability: 1' in ht and 'Extrusion e1' in ht, ht[:120])
    f=export('svg','transparent','uhd',name='E_'); s=open(f).read(); ok('E SVG opacity 0.15 & 0.4', re.search(r'(opacity:\s*0\.15|,\s*0\.15\))',s) and re.search(r'(opacity:\s*0\.4|,\s*0\.4\))',s))
    f=export('pdf','black','a3','xlarge',name='E_'); pdf=open(f,'rb').read(); ok('E PDF A3 with transparency', pagesize(f)==(1190.55,841.89) and re.search(rb'/CA 0\.15|/ca 0\.15', pdf), pagesize(f))
    f=export('png','black','hd','large',name='E_'); ok('E PNG export', open(f,'rb').read()[:4]==b'\x89PNG')
    # opacity persists per entity across views
    pg.click('#viewSeg button[data-v=scatter]'); W(); pg.click('#viewSeg button[data-v=history]'); W()
    ok('opacity kept when switching views', gd("gd.data.find(t=>t.meta==='hist|stability')._fade")==0.15)
    pg.screenshot(path='s6_E_opacity.png', full_page=True)
    # reload file keeps working
    pg.set_input_files('#file','testfiles/bad_rows.xlsx'); W(800); ok('reload another file', gd("getSelection_().fig.rows.length")==29)
    ok('no browser errors', not errs, errs[:3])
    b.close()
print('\nTOTAL', len(R), 'PASSED', sum(1 for r in R if r[1]), 'FAILED', [r[0] for r in R if not r[1]])
