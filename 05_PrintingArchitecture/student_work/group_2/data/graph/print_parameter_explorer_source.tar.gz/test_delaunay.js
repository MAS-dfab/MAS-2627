const D=require('./src/delaunay.js');
const sets=[];
let seed=7; const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
for(let s=0;s<200;s++){const n=3+Math.floor(rnd()*(s%3==0?20:25));const pts=[];const seen={};
  while(pts.length<n){const p= s%3==0?[Math.round(rnd()*4),Math.round(rnd()*4)]:[rnd()*300,rnd()*8];const k=p.join();if(!seen[k]){seen[k]=1;pts.push(p);}}
  sets.push(pts);}
sets.push([[220,7],[230,7],[230,5],[210,10]]); sets.push([[7,10],[10,5],[5,5],[3,5]]); sets.push([[0,0],[1,0],[2,0],[1,1]]);
console.log(JSON.stringify(sets.map(p=>({p,t:D.triangulate(p)}))));
