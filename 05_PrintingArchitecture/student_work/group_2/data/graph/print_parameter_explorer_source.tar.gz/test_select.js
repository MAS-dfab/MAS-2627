const XLSX=require('xlsx'),P=require('./src/parse.js'),S=require('./src/select.js');
const d=P.parseWorkbook(XLSX.readFile(process.argv[2]),XLSX);const info=S.paramInfo(d.rows);
const res={info:info.map(i=>[i.key,i.varies,i.axisOK,i.values]),pairs:{}};
const ax=info.filter(i=>i.axisOK).map(i=>i.key);
for(const x of ax){ res.pairs[x+'|']=S.groups(d.rows,info,x,null).list.map(g=>[g.sns,g.positions.length,g.nX,g.surface]);
 for(const y of ax) if(y!==x) res.pairs[x+'|'+y]=S.groups(d.rows,info,x,y).list.map(g=>[g.sns,g.positions.length,g.nX,g.surface]);}
console.log(JSON.stringify(res));
