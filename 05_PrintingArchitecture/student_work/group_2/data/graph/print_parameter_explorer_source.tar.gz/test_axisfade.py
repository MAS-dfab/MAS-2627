from playwright.sync_api import sync_playwright
import re
R=[]
def ok(n,c,i=''): R.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n+((' ['+str(i)+']') if i!='' else ''))
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1400,'height':1000}, accept_downloads=True); errs=[]
    pg.on('pageerror',lambda e: errs.append(str(e))); pg.on('console',lambda m: m.type=='error' and errs.append(m.text))
    pg.goto('file:///home/claude/build/dist/print_parameter_explorer.html'); pg.set_input_files('#file','/home/claude/data/week1.xlsx'); pg.wait_for_timeout(900)
    W=lambda ms=400: pg.wait_for_timeout(ms)
    pg.click('#viewSeg button[data-v=history]'); pg.select_option('#ov2','lh'); W()
    # rendered styles of each right axis: tick label fill, title fill, axis line stroke
    q=lambda ax: pg.evaluate(f"""(()=>{{const gd=document.getElementById('plot');
       const tick=gd.querySelector('.{ax}tick text'), title=gd.querySelector('text.{ax}title'), line=gd.querySelector('path.x{ax}-y.crisp');
       const cs=e=>getComputedStyle(e);
       const op=e=>Math.round(parseFloat(cs(e).fillOpacity)*parseFloat(cs(e).opacity)*100)/100;
       return [op(tick), op(title), Math.round(parseFloat(cs(line).strokeOpacity)*100)/100];}})()""")
    before2,before3=q('y2'),q('y3'); ok('overlay axes fully opaque by default', all(v==1 for v in before2+before3), (before2,before3))
    def slide(key,val):
        pg.eval_on_selector(f'#chips input[data-okey="{key}"]',f'e=>{{e.value={val};e.dispatchEvent(new Event("input"));e.dispatchEvent(new Event("change"))}}'); W()
    slide('hist|temp',30)
    a2,a3=q('y2'),q('y3')
    ok('temp 30%: right axis ticks/title/line at 0.3', all(v==0.3 for v in a2), a2)
    ok('layer-height axis untouched', a3==before3, a3)
    ok('score (left) axis untouched', pg.evaluate("getComputedStyle(document.querySelector('#plot .ytick text')).fillOpacity")=='1')
    slide('hist|lh',0); a3=q('y3'); ok('lh 0%: outer axis invisible', all(v==0 for v in a3), a3)
    slide('hist|clarity',20); ok('fading a score line leaves overlay axes alone', q('y2')==a2)
    # drag-time update (keepChips path) also refreshes axis
    pg.eval_on_selector('#chips input[data-okey="hist|temp"]','e=>{e.value=60;e.dispatchEvent(new Event("input"))}'); W()
    ok('live slider update fades axis', all(v==0.6 for v in q('y2')), q('y2'))
    # export carries it
    pg.select_option('#exFormat','svg'); pg.select_option('#exSize','uhd')
    with pg.expect_download() as d: pg.click('#exGo')
    d.value.save_as('exports4/axisfade.svg'); s=open('exports4/axisfade.svg').read()
    ok('SVG: faded axis colours written', 'rgba(195, 194, 183, 0.6)' in s or re.search(r'fill: rgb\(195, 194, 183\); fill-opacity: 0\.6', s))
    pg.select_option('#exFormat','pdf')
    with pg.expect_download() as d: pg.click('#exGo')
    d.value.save_as('exports4/axisfade.pdf'); ok('PDF exported', open('exports4/axisfade.pdf','rb').read()[:4]==b'%PDF')
    pg.click('#resetCol'); W(); ok('reset restores axis', all(v==1 for v in q('y2')), q('y2'))
    ok('no browser errors', not errs, errs[:2]); b.close()
print('TOTAL',len(R),'PASSED',sum(r[1] for r in R),'FAILED',[r[0] for r in R if not r[1]])
