/* export.js – Stage 5: PNG / SVG / PDF export of the current figure.
   Pipeline: rebuild figure (same text sizes as the on-screen graph) → background / caption → Plotly SVG →
   embed Roboto (@font-face, base64) → SVG file | canvas → PNG | svg2pdf → vector PDF. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var PL = window.PrintPlots, S = window.PrintSelect, F = window.ROBOTO;

  var BASE_W = 1600; // layout width in CSS px; larger presets scale it up, so text keeps its proportion
  var PRESETS = {
    // 16:9 presets: dpi tag and PDF page match a standard widescreen slide (13.333 × 7.5 in = 960 × 540 pt),
    // so an inserted PNG/PDF fills the slide exactly
    hd:  { w: 1920, h: 1080, label: '16:9 slide – 1920 × 1080 px (Full HD)', dpi: 144, page: [960, 540], slide: true },
    uhd: { w: 3840, h: 2160, label: '16:9 slide – 3840 × 2160 px (4K)',      dpi: 288, page: [960, 540], slide: true },
    a4:  { w: 3508, h: 2480, label: 'A4 landscape @ 300 dpi – 3508 × 2480 px', dpi: 300, page: [841.89, 595.28] },
    a3:  { w: 4961, h: 3508, label: 'A3 landscape @ 300 dpi – 4961 × 3508 px', dpi: 300, page: [1190.55, 841.89] }
  };
  var opts = { format: 'png', bg: 'black', size: 'uhd', caption: true, captionSize: 12 };

  // ---------------------------------------------------------------- UI
  function sel(id, label, options, cur) {
    return '<label class="f">' + label + '<select id="' + id + '">' + options.map(function (o) {
      return '<option value="' + o[0] + '"' + (o[0] === cur ? ' selected' : '') + '>' + o[1] + '</option>';
    }).join('') + '</select></label>';
  }
  function renderUI() {
    $('exportRow').innerHTML =
      sel('exFormat', 'Format', [['png', 'PNG (image)'], ['svg', 'SVG (vector)'], ['pdf', 'PDF (vector)']], opts.format) +
      sel('exBg', 'Background', [['black', 'Black'], ['transparent', 'Transparent']], opts.bg) +
      sel('exSize', 'Size', Object.keys(PRESETS).map(function (k) { return [k, PRESETS[k].label]; }), opts.size) +
      '<label class="f cb"><input type="checkbox" id="exCaption"' + (opts.caption ? ' checked' : '') + '> Caption (axes, S/Ns, assumptions)</label>' +
      '<label class="tsz" id="exCapSizeWrap">Caption size<input type="range" id="exCapSize" min="6" max="40" step="1" value="' + opts.captionSize + '"><span class="pc">' + opts.captionSize + '</span></label>' +
      '<button id="exGo" class="primary">Export</button>';
    ['exFormat', 'exBg', 'exSize'].forEach(function (id) {
      $(id).onchange = function () { opts[{ exFormat: 'format', exBg: 'bg', exSize: 'size' }[id]] = this.value; note(); schedulePreview(); };
    });
    $('exCaption').onchange = function () { opts.caption = this.checked; $('exCapSizeWrap').style.opacity = opts.caption ? 1 : 0.4; schedulePreview(); };
    $('exCapSize').oninput = function () { opts.captionSize = +this.value; this.nextSibling.textContent = this.value; schedulePreview(); };
    $('exGo').onclick = run;
    note();
  }
  function note() {
    var p = PRESETS[opts.size], t = '';
    if (opts.format === 'png') t = 'PNG at ' + p.w + ' × ' + p.h + ' px, tagged ' + p.dpi + ' dpi' +
      (p.slide ? ' – fills a 16:9 slide (13.33 × 7.5 in) exactly when inserted.' : '.');
    else t = (opts.format === 'svg' ? 'SVG' : 'PDF') + ' is vector: resolution does not apply; the size sets the proportions' +
             (opts.format === 'pdf' ? ' and the page size (' + (p.page[0] / 72 * 25.4).toFixed(1) + ' × ' + (p.page[1] / 72 * 25.4).toFixed(1) + ' mm' +
               (p.slide ? ' = 16:9 slide' : '') + ').' : '.') +
             (opts.format === 'svg' ? ' Roboto is embedded for browsers; design apps that ignore embedded fonts need Roboto installed.' : ' Roboto is embedded.');
    if (opts.bg === 'transparent') t += ' Transparent: text is light grey, intended for dark slides.';
    $('exNote').textContent = t;
  }
  document.addEventListener('dataloaded', function () { $('exportSection').classList.remove('hidden'); renderUI(); schedulePreview(); });
  document.addEventListener('figuredrawn', function () { schedulePreview(); });

  // ---------------------------------------------------------------- live preview (same SVG the PNG is drawn from)
  var pvTimer = null, pvToken = 0;
  function schedulePreview() { clearTimeout(pvTimer); pvTimer = setTimeout(refreshPreview, 300); }
  function refreshPreview() {
    var state = window.getSelection_ && window.getSelection_();
    if (!state || $('exportSection').classList.contains('hidden')) return;
    var token = ++pvToken, ex = exportFigure(state), p = ex.preset;
    toSVG(ex).then(function (svg) {
      if (token !== pvToken) return; // a newer preview is on its way
      var box = $('exPreview');
      box.style.aspectRatio = p.w + ' / ' + p.h;
      box.classList.toggle('transp', opts.bg === 'transparent');
      $('exPreviewImg').src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
      $('exPreviewInfo').textContent = 'Exactly what ' + (opts.format === 'pdf' ? 'the PDF is converted from' : 'will be exported') + ': ' +
        p.w + ' × ' + p.h + ' px' + (p.slide ? ' (16:9 slide)' : '') + ', ' + (opts.bg === 'transparent' ? 'transparent background (shown on a checkerboard)' : 'black background') +
        '. Updates as you change the graph or the export options.';
      window.LAST_PREVIEW = { token: token, w: p.w, h: p.h, bg: opts.bg, svgLength: svg.length };
    }).catch(function (e) { $('exPreviewInfo').textContent = 'Preview failed: ' + e.message; });
  }

  // ---------------------------------------------------------------- figure preparation
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function ranges(sns) {
    var nums = sns.map(Number);
    if (nums.some(isNaN)) return sns.join(', ');
    nums.sort(function (a, b) { return a - b; });
    var out = [], s = nums[0], p = nums[0];
    for (var i = 1; i <= nums.length; i++) {
      if (i < nums.length && nums[i] === p + 1) { p = nums[i]; continue; }
      out.push(s === p ? String(s) : s + '–' + p);
      if (i < nums.length) { s = p = nums[i]; }
    }
    return out.join(', ');
  }
  function captionText(state) {
    var sel = state.sel, fig = state.fig, info = S.paramInfo(window.SEL_STATE.rows);
    var lab = function (k) {
      if (k === 'clarity') return 'Clarity'; if (k === 'stability') return 'Stability';
      var p = info.filter(function (q) { return q.key === k; })[0]; return p.label + (p.unit ? ' (' + p.unit + ')' : '');
    };
    var l1, l2 = [];
    if (sel.view === 'map2d') {
      l1 = '2D map · X: ' + lab(sel.x) + ' · Y: ' + lab(sel.y) + ' · Colour: ' + lab(sel.score);
      l2.push('Dotted lines join only prints with identical other settings.');
    } else if (sel.view === 'scatter') {
      l1 = 'Clarity vs Stability · Colour: ' + lab(sel.colorBy);
      l2.push('Prints in the same cell are spread out inside it.');
    } else {
      l1 = 'History in S/N order · Clarity & Stability' + (fig.overlays.length ? ' · Overlay: ' + fig.overlays.map(lab).join(', ') : '');
      if (fig.overlays.length) l2.push('Overlays use their own right-hand scales; line heights are not comparable.');
      if (fig.top && fig.top.length) l2.push('Top ' + sel.topN + ' by ' + PL.RANKERS[sel.rankBy].label.toLowerCase() + ' (ties included): S/N ' +
        fig.top.map(function (e) { return e.row.sn + ' (#' + e.rank + ')'; }).join(', ') + '.');
    }
    l1 += ' · ' + fig.rows.length + ' prints (S/N ' + ranges(fig.rows.map(function (r) { return r.sn; })) + ')';
    var asm = {};
    fig.rows.forEach(function (r) { (r._assumed || []).forEach(function (k) { (asm[k] = asm[k] || []).push(r.sn); }); });
    Object.keys(asm).forEach(function (k) {
      l2.push('Assumed ' + (k === 'lh' ? 'layer height 2 mm' : k === 'colour' ? 'colour "unspecified"' : k) + ' for S/N ' + ranges(asm[k]) + ' (blank in file).');
    });
    if (fig.excluded && fig.excluded.length) l2.push('Not placeable ("not used" on an axis): S/N ' + ranges(fig.excluded) + '.');
    var src = window.APP_STATE && window.APP_STATE.fileName ? 'Source: ' + window.APP_STATE.fileName : '';
    if (src) l2.push(src);
    return [l1].concat(l2);
  }
  function exportFigure(state) {
    var p = PRESETS[opts.size];
    var fig = PL.build(state.sel, S.paramInfo(window.SEL_STATE.rows), state.optsUsed), ts = fig.text;
    var data = clone(fig.data), layout = clone(fig.layout);
    var w = BASE_W, h = Math.round(BASE_W * p.h / p.w);
    layout.width = w; layout.height = h;
    if (opts.bg === 'transparent') { layout.paper_bgcolor = 'rgba(0,0,0,0)'; layout.plot_bgcolor = 'rgba(0,0,0,0)'; }
    layout.margin = layout.margin || {};
    layout.margin.l = Math.max(layout.margin.l || 70, 80); layout.margin.r = Math.max(layout.margin.r || 30, 40);
    layout.margin.t = Math.max(layout.margin.t || 30, 50);
    // room under the plot for x tick labels + x title, sized from the chosen text sizes
    layout.margin.b = Math.max(layout.margin.b || 60, 80, Math.ceil(ts.tick * 1.9 + ts.axis * 1.9 + 24));
    if (opts.caption) {
      var lines = captionText(state), fs = opts.captionSize, capH = Math.ceil(lines.length * fs * 1.45 + 16);
      var bOld = layout.margin.b;
      layout.margin.b = bOld + capH;
      layout.annotations = (layout.annotations || []).concat([{
        xref: 'paper', yref: 'paper', x: 0, y: 0, xanchor: 'left', yanchor: 'top', yshift: -(bOld + 4), align: 'left', showarrow: false,
        text: lines.map(function (l, i) { return i === 0 ? '<b>' + esc(l) + '</b>' : esc(l); }).join('<br>'),
        font: { family: 'Roboto, sans-serif', size: fs, color: '#c3c2b7' }
      }]);
      if (layout.xaxis) layout.xaxis.automargin = false;
    }
    return { data: data, layout: layout, w: w, h: h, preset: p };
  }
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }); }

  // ---------------------------------------------------------------- SVG with embedded font
  function fontFaceCSS(fmt) {
    return [400, 700].map(function (wt) {
      return '@font-face{font-family:Roboto;font-style:normal;font-weight:' + wt + ';src:url(data:font/woff2;base64,' + F.woff2[wt] + ") format('woff2');}";
    }).join('');
  }
  function toSVG(ex) {
    return Plotly.toImage({ data: ex.data, layout: ex.layout }, { format: 'svg', width: ex.w, height: ex.h }).then(function (url) {
      var svg = decodeURIComponent(url.slice(url.indexOf(',') + 1));
      // Plotly writes <b> as font-weight:bold – keep; embed the font right after the root element opens
      var i = svg.indexOf('>', svg.indexOf('<svg')) + 1;
      return svg.slice(0, i) + '<defs><style type="text/css">' + fontFaceCSS() + '</style></defs>' + svg.slice(i);
    });
  }

  // ---------------------------------------------------------------- PNG (+ pHYs dpi chunk)
  var CRC_TABLE = (function () { var t = [], c; for (var n = 0; n < 256; n++) { c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(bytes) { var c = 0xffffffff; for (var i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
  function withDpi(buf, dpi) {
    var src = new Uint8Array(buf), ppm = Math.round(dpi / 0.0254);
    var chunk = new Uint8Array(21), dv = new DataView(chunk.buffer);
    dv.setUint32(0, 9); chunk.set([0x70, 0x48, 0x59, 0x73], 4); // "pHYs"
    dv.setUint32(8, ppm); dv.setUint32(12, ppm); chunk[16] = 1;
    dv.setUint32(17, crc32(chunk.subarray(4, 17)));
    var at = 8 + 25; // after signature + IHDR (13-byte data + 12 bytes framing)
    var out = new Uint8Array(src.length + 21);
    out.set(src.subarray(0, at), 0); out.set(chunk, at); out.set(src.subarray(at), at + 21);
    return out;
  }
  function toPNG(svg, ex) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      img.onload = function () {
        var c = document.createElement('canvas'); c.width = ex.preset.w; c.height = ex.preset.h;
        var ctx = c.getContext('2d');
        // let the embedded font finish decoding before drawing
        setTimeout(function () {
          ctx.drawImage(img, 0, 0, c.width, c.height);
          c.toBlob(function (b) {
            if (!ex.preset.dpi) return resolve(b);
            b.arrayBuffer().then(function (ab) { resolve(new Blob([withDpi(ab, ex.preset.dpi)], { type: 'image/png' })); });
          }, 'image/png');
        }, 150);
      };
      img.onerror = function () { reject(new Error('The graph could not be rasterised.')); };
      img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    });
  }

  // ---------------------------------------------------------------- PDF (vector)
  function toPDF(svg, ex) {
    var JS = window.jspdf.jsPDF;
    var wpt = ex.preset.page[0], hpt = ex.preset.page[1];
    var doc = new JS({ orientation: wpt > hpt ? 'l' : 'p', unit: 'pt', format: [wpt, hpt], compress: true });
    doc.addFileToVFS('Roboto-Regular.ttf', F.ttf[400]); doc.addFont('Roboto-Regular.ttf', 'Roboto', 'normal');
    doc.addFileToVFS('Roboto-Bold.ttf', F.ttf[700]); doc.addFont('Roboto-Bold.ttf', 'Roboto', 'bold');
    var holder = document.createElement('div');
    holder.style.cssText = 'position:absolute;left:-99999px;top:0;';
    holder.innerHTML = svg;
    document.body.appendChild(holder);
    var el = holder.querySelector('svg');
    return doc.svg(el, { x: 0, y: 0, width: wpt, height: hpt }).then(function () {
      document.body.removeChild(holder);
      return doc.output('blob');
    }, function (e) { document.body.removeChild(holder); throw e; });
  }

  // ---------------------------------------------------------------- run
  function fileBase(state) {
    var name = (window.APP_STATE.fileName || 'data').replace(/\.[^.]+$/, '');
    var s = state.sel, part;
    if (s.view === 'map2d') part = '2Dmap_' + s.x + '_x_' + s.y + '_' + s.score;
    else if (s.view === 'scatter') part = 'clarity_vs_stability_by_' + s.colorBy;
    else part = 'history' + (state.fig.overlays.length ? '_' + state.fig.overlays.join('_') : '');
    return (name + '_' + part).replace(/[^A-Za-z0-9_.-]+/g, '-');
  }
  function download(blob, name) {
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); document.body.removeChild(a); }, 1000);
  }
  function run() {
    var state = window.getSelection_ && window.getSelection_();
    if (!state) return;
    var btn = $('exGo'); btn.disabled = true; $('exStatus').textContent = 'Exporting…';
    var ex = exportFigure(state), base = fileBase(state);
    toSVG(ex).then(function (svg) {
      if (opts.format === 'svg') return { blob: new Blob([svg], { type: 'image/svg+xml' }), name: base + '.svg' };
      if (opts.format === 'png') return toPNG(svg, ex).then(function (b) { return { blob: b, name: base + '_' + ex.preset.w + 'x' + ex.preset.h + '.png' }; });
      return toPDF(svg, ex).then(function (b) { return { blob: b, name: base + '.pdf' }; });
    }).then(function (r) {
      window.LAST_EXPORT = r; // for testing
      download(r.blob, r.name);
      $('exStatus').textContent = 'Saved ' + r.name + ' (' + Math.round(r.blob.size / 1024) + ' KB)';
    }).catch(function (e) {
      $('exStatus').textContent = 'Export failed: ' + e.message;
    }).then(function () { btn.disabled = false; });
  }
  window.PrintExport = { refreshPreview: refreshPreview, PRESETS: PRESETS, exportFigure: exportFigure, toSVG: toSVG, toPNG: toPNG, toPDF: toPDF, opts: opts, captionText: captionText };
})();
