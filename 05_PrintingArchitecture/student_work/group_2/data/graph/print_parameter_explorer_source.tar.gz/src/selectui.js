/* selectui.js – view / axis / colour controls and plot rendering (R1: all prints, connect like with like). */
(function () {
  'use strict';
  var S = window.PrintSelect, PL = window.PrintPlots;
  var $ = function (id) { return document.getElementById(id); };
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  var st = {
    rows: [], info: [], view: 'map2d', x: null, y: null, score: 'clarity', colorBy: null,
    overlays: [null, null], scheme: 'blue', customLo: '#1f4f8f', customHi: '#e6f0fb', overrides: {}, opacity: {}, dash: {}, text: JSON.parse(JSON.stringify(PL.TEXT_DEFAULT)), topN: 0, rankBy: 'min', labels: true, last: null
  };
  window.SEL_STATE = st;

  function plabel(k) { var p = st.info.filter(function (i) { return i.key === k; })[0] || S.byKey(k); return p.label + (p.unit ? ' (' + p.unit + ')' : ''); }
  function axisKeys() { return st.info.filter(function (p) { return p.axisOK; }).map(function (p) { return p.key; }); }
  function ramp() { return st.scheme === 'custom' ? [st.customLo, st.customHi] : PL.RAMPS[st.scheme]; }

  document.addEventListener('dataloaded', function (e) {
    st.rows = e.detail.rows;
    st.info = S.paramInfo(st.rows);
    var axes = axisKeys();
    $('selSection').classList.remove('hidden');
    if (!axes.length) { $('axisRow').innerHTML = '<div class="msg err">No numeric parameter varies in this file, so there is nothing to plot.</div>'; return; }
    st.x = axes.indexOf('temp') !== -1 ? 'temp' : axes[0];
    st.y = axes.indexOf('e1') !== -1 && st.x !== 'e1' ? 'e1' : axes.filter(function (k) { return k !== st.x; })[0] || null;
    if (st.view === 'map2d' && !st.y) st.view = 'scatter';
    st.colorBy = st.info.filter(function (p) { return p.varies; }).map(function (p) { return p.key; })[0];
    st.overlays = [st.info.some(function (p) { return p.key === 'temp' && p.varies; }) ? 'temp' : null, null];
    render();
  });

  Array.prototype.forEach.call($('viewSeg').querySelectorAll('button'), function (b) {
    b.addEventListener('click', function () {
      st.view = b.dataset.v;
      if (st.view === 'map2d' && !st.y) st.y = axisKeys().filter(function (k) { return k !== st.x; })[0] || null;
      if (st.view === 'map2d' && !st.y) { st.view = 'scatter'; }
      render();
    });
  });

  function selectHTML(id, label, opts, cur) {
    return '<label class="f">' + esc(label) + '<select id="' + id + '">' + opts.map(function (o) {
      return '<option value="' + esc(o.v) + '"' + (o.v === cur ? ' selected' : '') + '>' + esc(o.t) + '</option>';
    }).join('') + '</select></label>';
  }

  function renderControls() {
    var axes = axisKeys().map(function (k) { return { v: k, t: plabel(k) }; });
    var h = '';
    if (st.view === 'history') {
      var vary = st.info.filter(function (p) { return p.varies; }).map(function (p) { return { v: p.key, t: plabel(p.key) }; });
      h += selectHTML('ov1', 'Overlay 1 (right axis, dashed)', [{ v: '', t: '— none —' }].concat(vary), st.overlays[0] || '');
      h += selectHTML('ov2', 'Overlay 2 (outer right axis, dotted)', [{ v: '', t: '— none —' }].concat(vary.filter(function (o) { return o.v !== st.overlays[0]; })), st.overlays[1] || '');
      var nOpts = [{ v: '0', t: 'off' }]; for (var n = 1; n <= 10; n++) nOpts.push({ v: String(n), t: 'Top ' + n });
      h += selectHTML('topN', 'Call out top results', nOpts, String(st.topN));
      h += selectHTML('rankBy', 'Rank by', Object.keys(PL.RANKERS).map(function (k) { return { v: k, t: PL.RANKERS[k].label }; }), st.rankBy);
      h += '<div class="note" style="margin:0 0 6px">Prints in S/N order. Overlay markers show where the parameter changed; hollow = assumed value.</div>';
    } else if (st.view === 'scatter') {
      h += selectHTML('selC', 'Colour points by', st.info.filter(function (p) { return p.varies; }).map(function (p) { return { v: p.key, t: plabel(p.key) }; }), st.colorBy);
      h += '<div class="note" style="margin:0 0 6px">X = Clarity, Y = Stability. Every print is one point; prints in the same cell are spread out inside it.</div>';
    } else {
      h += selectHTML('selX', 'X axis', axes, st.x);
      h += selectHTML('selY', 'Y axis', axes.filter(function (o) { return o.v !== st.x; }), st.y);
      h += selectHTML('selZ', 'Colour = score', S.SCORES.map(function (s) { return { v: s.key, t: s.label }; }), st.score);
    }
    $('axisRow').innerHTML = h;
    if (st.view === 'history') {
      $('ov1').onchange = function () { st.overlays[0] = this.value || null; if (st.overlays[1] === st.overlays[0]) st.overlays[1] = null; render(); };
      $('ov2').onchange = function () { st.overlays[1] = this.value || null; render(); };
      $('topN').onchange = function () { st.topN = +this.value; render(); };
      $('rankBy').onchange = function () { st.rankBy = this.value; render(); };
    } else if (st.view === 'scatter') $('selC').onchange = function () { st.colorBy = this.value; render(); };
    else {
      $('selX').onchange = function () {
        st.x = this.value;
        if (st.y === st.x) st.y = axisKeys().filter(function (k) { return k !== st.x; })[0];
        render();
      };
      $('selY').onchange = function () { st.y = this.value || null; render(); };
      $('selZ').onchange = function () { st.score = this.value; render(); };
    }
    var fixed = st.info.filter(function (p) { return !p.varies; });
    $('fixedNote').innerHTML = fixed.length ? 'Same for every print in this file (not offered): ' +
      fixed.map(function (p) { return esc(p.label) + ' = ' + esc(p.values[0]); }).join(' · ') : '';

    var schemes = [{ v: 'blue', t: 'Blue' }, { v: 'orange', t: 'Orange' }, { v: 'aqua', t: 'Aqua' }, { v: 'magenta', t: 'Magenta' }, { v: 'grey', t: 'Grey' }, { v: 'custom', t: 'Custom (pick two)' }];
    var c = selectHTML('selScheme', 'Colour scheme (scores & numeric values)', schemes, st.scheme);
    if (st.scheme === 'custom') c += '<label class="f">Low<input type="color" id="cLo" value="' + st.customLo + '"></label><label class="f">High<input type="color" id="cHi" value="' + st.customHi + '"></label>';
    if (st.view !== 'history') c += '<label class="f cb"><input type="checkbox" id="cbLabels"' + (st.labels ? ' checked' : '') + '> Show S/N labels</label>';
    $('colourRow').innerHTML = c;
    renderTextRow();
    $('selScheme').onchange = function () { st.scheme = this.value; render(); };
    if ($('cLo')) { $('cLo').oninput = function () { st.customLo = this.value; draw(); }; $('cHi').oninput = function () { st.customHi = this.value; draw(); }; }
    if ($('cbLabels')) $('cbLabels').onchange = function () { st.labels = this.checked; draw(); };
  }

  var DASHES = [['solid', '──── solid'], ['dash', '– – dash'], ['dot', '····· dot'], ['dashdot', '–·–· dash-dot'], ['longdash', '—— long dash'], ['longdashdot', '—·— long dash-dot']];
  function renderChips(keys, note) {
    var h = keys.map(function (k) {
      var pc = Math.round((k.opacity === undefined ? 1 : k.opacity) * 100);
      return '<span class="chip' + (pc < 100 ? ' faded' : '') + '">' +
        '<input type="color" title="Colour" data-key="' + esc(k.key) + '" value="' + k.colour + '">' +
        '<span class="cl">' + esc(k.label) + '</span>' +
        '<input type="range" title="Opacity" min="0" max="100" step="5" data-okey="' + esc(k.key) + '" value="' + pc + '">' +
        '<span class="pc">' + pc + '%</span>' +
        (k.dash && !k.noDash ? '<select class="dash" title="Line type" data-dkey="' + esc(k.key) + '">' + DASHES.map(function (d) {
          return '<option value="' + d[0] + '"' + (d[0] === k.dash ? ' selected' : '') + '>' + d[1] + '</option>'; }).join('') + '</select>' : '') +
        '</span>';
    }).join('');
    var any = Object.keys(st.overrides).length || Object.keys(st.opacity).length || Object.keys(st.dash).length;
    if (any) h += '<button id="resetCol">Reset colours, opacity &amp; line types</button>';
    if (note) h += '<span class="no">' + esc(note) + '</span>';
    $('chips').innerHTML = h;
    Array.prototype.forEach.call($('chips').querySelectorAll('input[type=color]'), function (inp) {
      inp.oninput = function () { st.overrides[inp.dataset.key] = inp.value; draw(true); };
      inp.onchange = function () { draw(); };
    });
    Array.prototype.forEach.call($('chips').querySelectorAll('input[type=range]'), function (inp) {
      inp.oninput = function () {
        var v = +inp.value;
        if (v === 100) delete st.opacity[inp.dataset.okey]; else st.opacity[inp.dataset.okey] = v / 100;
        inp.nextSibling.textContent = v + '%';
        inp.parentNode.classList.toggle('faded', v < 100);
        draw(true);
      };
      inp.onchange = function () { draw(); };
    });
    Array.prototype.forEach.call($('chips').querySelectorAll('select.dash'), function (sl) {
      sl.onchange = function () { st.dash[sl.dataset.dkey] = sl.value; draw(); };
    });
    if ($('resetCol')) $('resetCol').onclick = function () { st.overrides = {}; st.opacity = {}; st.dash = {}; draw(); };
  }

  var TEXT_ITEMS = [['axis', 'Axis titles'], ['tick', 'Tick labels'], ['legend', 'Legend'], ['label', 'Point labels (S/N, ranks)']];
  function renderTextRow() {
    var h = '<span class="tlabel">Text size</span>' + TEXT_ITEMS.map(function (it) {
      return '<label class="tsz">' + it[1] + '<input type="range" min="6" max="40" step="1" data-tkey="' + it[0] + '" value="' + st.text[it[0]] + '">' +
             '<span class="pc">' + st.text[it[0]] + '</span></label>';
    }).join('') + '<button id="resetText">Default sizes</button>' +
      '<span class="note" style="flex-basis:100%;margin:0">Sizes in px of the export layout (1600 px wide); the graph above and the export preview use the same sizes. ' +
      'On a 16:9 slide 10 px ≈ 6 pt – for projected slides about 24 px (≈ 14 pt) or more reads well.</span>';
    $('textRow').innerHTML = h;
    Array.prototype.forEach.call($('textRow').querySelectorAll('input[type=range]'), function (inp) {
      inp.oninput = function () { st.text[inp.dataset.tkey] = +inp.value; inp.nextSibling.textContent = inp.value; draw(true); };
      inp.onchange = function () { draw(); };
    });
    $('resetText').onclick = function () { st.text = JSON.parse(JSON.stringify(PL.TEXT_DEFAULT)); renderTextRow(); draw(); };
  }

  function selection() {
    return { topN: st.topN, rankBy: st.rankBy, overlays: st.overlays, view: st.view, x: st.x, y: st.y, score: st.score, colorBy: st.colorBy, allRows: st.rows };
  }

  // keepChips: while dragging a colour picker, don't rebuild the chips (it would close the picker)
  function draw(keepChips) {
    var sel = selection();
    var optsUsed = { ramp: ramp().slice(), overrides: JSON.parse(JSON.stringify(st.overrides)), opacity: JSON.parse(JSON.stringify(st.opacity)),
                     dash: JSON.parse(JSON.stringify(st.dash)), text: JSON.parse(JSON.stringify(st.text)), labels: st.labels };
    var fig = PL.build(sel, st.info, optsUsed);
    st.last = { sel: sel, fig: fig, optsUsed: optsUsed };
    Plotly.react('plot', fig.data, fig.layout, { displaylogo: false, responsive: true, modeBarButtonsToRemove: ['toImage', 'sendDataToCloud', 'select2d', 'lasso2d'] });
    if (!keepChips) renderChips(fig.colourKeys, fig.tooManyCategories ? 'More than 8 categories – some colours repeat; set them individually.' : '');

    var n = fig.rows.length;
    var m = '<span class="big">' + n + ' print' + (n === 1 ? '' : 's') + ' plotted</span>';
    if (st.view === 'history') {
      m += ' in S/N order (assumed to be the order of testing)';
      if (fig.top && fig.top.length) {
        var tieNote = fig.top.length > st.topN ? ' – ' + fig.top.length + ' prints, because prints tied at the cut-off are all included' : '';
        m += '<br><b>Top ' + st.topN + ' by ' + esc(PL.RANKERS[st.rankBy].label.toLowerCase()) + '</b>' + esc(tieNote) + '.';
      }
      if (fig.overlays.length) m += '<br><span class="note">Each overlay has its own right-hand scale. Where its line sits relative to the score lines, or crosses them, has no meaning – compare <i>when</i> things change, not heights.</span>';
    } else if (st.view !== 'scatter') {
      m += ' · ' + fig.lines + ' connection' + (fig.lines === 1 ? '' : 's') + ' between prints with identical other settings' +
           ' · ' + fig.unconnected.length + ' unconnected print' + (fig.unconnected.length === 1 ? '' : 's');
      m += '<br><span class="note">Dotted lines join only prints that differ in nothing but the axis values' +
           '. Hover a point for all its settings. Unconnected points differ from every other print in at least one setting.</span>';
    }
    if (fig.excluded.length) m += '<br><span class="note">Not placeable on these axes (value "not used"): S/N ' + esc(fig.excluded.join(', ')) + '</span>';
    var asm = fig.rows.filter(function (r) { return r._assumed && r._assumed.length; });
    if (asm.length) m += '<br><span class="note">Includes assumed values (blank in file): ' + esc(asm.map(function (r) {
      return 'S/N ' + r.sn + ' ' + r._assumed.map(function (k) { return k === 'lh' ? 'layer height 2' : k + ' ' + r[k]; }).join(', ');
    }).join('; ')) + '</span>';
    $('matchBox').innerHTML = m;
    renderPreview(fig.rows, sel);
    renderTop(fig);
    document.dispatchEvent(new CustomEvent('figuredrawn', { detail: st.last }));
  }

  function renderPreview(rows, sel) {
    rows = rows.slice();
    var plotted = sel.view === 'history' ? ['clarity', 'stability'] : sel.view === 'scatter' ? ['clarity', 'stability', sel.colorBy] : [sel.x].concat(sel.y ? [sel.y] : []).concat([sel.score]);
    var others = st.info.filter(function (p) { return p.varies && plotted.indexOf(p.key) === -1; }).map(function (p) { return p.key; });
    var cols = ['sn'].concat(plotted, others);
    var sk = sel.view === 'history' ? [] : sel.view === 'scatter' ? ['clarity', 'stability'] : [sel.x].concat(sel.y ? [sel.y] : []);
    rows.sort(function (a, b) {
      for (var i = 0; i < sk.length; i++) { var d = (a[sk[i]] > b[sk[i]]) - (a[sk[i]] < b[sk[i]]); if (d) return d; }
      return parseFloat(a.sn) - parseFloat(b.sn);
    });
    var name = function (k) { return k === 'sn' ? 'S/N' : k === 'clarity' ? 'Clarity' : k === 'stability' ? 'Stability' : plabel(k); };
    $('previewTable').innerHTML = '<thead><tr>' + cols.map(function (k, i) { return '<th' + (i > plotted.length ? ' style="color:var(--muted)"' : '') + '>' + esc(name(k)) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      rows.map(function (r) { return '<tr>' + cols.map(function (k) { return '<td>' + esc(S.vkey(r[k])) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody>';
  }

  function renderTop(fig) {
    var box = $('topBox');
    if (!fig.top || !fig.top.length || st.view !== 'history') { box.classList.add('hidden'); box.innerHTML = ''; return; }
    var params = st.info.filter(function (p) { return p.varies; });
    var head = '<tr><th>Rank</th><th>S/N</th><th>Clarity</th><th>Stability</th>' + params.map(function (p) { return '<th>' + esc(plabel(p.key)) + '</th>'; }).join('') + '</tr>';
    var body = fig.top.map(function (e) {
      var r = e.row;
      return '<tr><td>#' + e.rank + '</td><td>' + esc(r.sn) + '</td><td>' + r.clarity + '</td><td>' + r.stability + '</td>' + params.map(function (p) {
        var a = r._assumed && r._assumed.indexOf(p.key) !== -1;
        return '<td' + (a ? ' class="as" title="assumed"' : '') + '>' + esc(S.vkey(r[p.key])) + '</td>';
      }).join('') + '</tr>';
    }).join('');
    box.innerHTML = '<h3>Top results – settings</h3><div class="tablewrap"><table>' + '<thead>' + head + '</thead><tbody>' + body + '</tbody></table></div>';
    box.classList.remove('hidden');
  }

  function render() {
    Array.prototype.forEach.call($('viewSeg').querySelectorAll('button'), function (b) { b.classList.toggle('on', b.dataset.v === st.view); });
    renderControls();
    draw();
  }
  window.getSelection_ = function () { return st.last; };
})();
