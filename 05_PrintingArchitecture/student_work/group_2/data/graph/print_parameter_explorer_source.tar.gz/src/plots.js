/* plots.js – builds Plotly figures for the four views (R1: plot every print, connect only like with like).
   Pure: no DOM access. Depends on PrintSelect (S) and PrintDelaunay (D). */
(function (root) {
  'use strict';
  var S = root.PrintSelect || (typeof require !== 'undefined' && require('./select.js'));
  var D = root.PrintDelaunay || (typeof require !== 'undefined' && require('./delaunay.js'));

  // ---- colour --------------------------------------------------------------------
  // Ramps validated (ordinal, dark mode) against a #000000 surface; index 0 = lowest.
  var RAMPS = {
    blue:    ['#256abf', '#3987e5', '#6da7ec', '#9ec5f4', '#cde2fb'],
    orange:  ['#a8431a', '#d95926', '#eb7d4f', '#f4a785', '#fad3c2'],
    aqua:    ['#127a56', '#199e70', '#3fc293', '#86dcbb', '#c6f0df'],
    magenta: ['#a8325d', '#d55181', '#e87ba4', '#f2a9c4', '#f9d6e3'],
    grey:    ['#5c5c5c', '#858585', '#adadad', '#d6d6d6', '#ffffff']
  };
  // Categorical (dark steps), validated on #000000; fixed order, never cycled.
  var CATEG = ['#3987e5', '#d95926', '#199e70', '#c98500', '#d55181', '#0ca30c', '#9085e9', '#e66767'];
  var NOT_USED_COLOUR = '#6f6f6b';
  var INK = '#f0efec', INK2 = '#c3c2b7', GRID = '#2f2f2d', LINK = '#8d8d88';

  function hex2rgb(h) { h = h.replace('#', ''); return [0, 2, 4].map(function (i) { return parseInt(h.substr(i, 2), 16); }); }
  function rgb2hex(c) { return '#' + c.map(function (v) { return ('0' + Math.round(v).toString(16)).slice(-2); }).join(''); }
  // sample a ramp (array of stops) at t in [0,1]
  function sample(stops, t) {
    if (stops.length === 1) return stops[0];
    var f = t * (stops.length - 1), i = Math.min(Math.floor(f), stops.length - 2), u = f - i;
    var a = hex2rgb(stops[i]), b = hex2rgb(stops[i + 1]);
    return rgb2hex([0, 1, 2].map(function (k) { return a[k] + (b[k] - a[k]) * u; }));
  }

  /* Colour for an entity. key examples: "score|3", "temp|210", "material|PLA NX1".
     opts.ramp = array of stops, opts.overrides = {key: hex} */
  function colourFor(kind, value, allValues, numeric, opts) {
    var key = kind + '|' + value;
    if (opts.overrides && opts.overrides[key]) return opts.overrides[key];
    if (value === S.NOT_USED) return NOT_USED_COLOUR;
    if (kind === 'score') return sample(opts.ramp, (parseFloat(value) - 1) / 4);
    var vals = allValues.filter(function (v) { return v !== S.NOT_USED; });
    var idx = vals.indexOf(value);
    if (!numeric) return CATEG[idx % CATEG.length];  // > 8 categories is flagged in the UI, never generated
    return sample(opts.ramp, vals.length < 2 ? 1 : idx / (vals.length - 1));
  }

  // ---- helpers -------------------------------------------------------------------
  function median(a) { a = a.slice().sort(function (x, y) { return x - y; }); var n = a.length; return n % 2 ? a[(n - 1) / 2] : (a[n / 2 - 1] + a[n / 2]) / 2; }
  function span(vals) { var mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals); return { min: mn, max: mx, d: (mx - mn) || 1 }; }
  function unitOf(info, k) { var p = info.filter(function (i) { return i.key === k; })[0]; return p && p.unit ? ' ' + p.unit : ''; }
  function labelOf(info, k) {
    if (k === 'clarity') return 'Clarity'; if (k === 'stability') return 'Stability';
    var p = info.filter(function (i) { return i.key === k; })[0]; return p.label;
  }
  function axisTitle(info, k) { var u = unitOf(info, k).trim(); return labelOf(info, k) + (u ? ' (' + u + ')' : ''); }
  function fmtVal(info, k, v) { return v === null || v === undefined ? S.NOT_USED : v + unitOf(info, k); }

  // settings of a print not shown on the axes
  function settingsHTML(r, info, exclude) {
    return info.filter(function (p) { return p.varies && exclude.indexOf(p.key) === -1; }).map(function (p) {
      var assumed = r._assumed && r._assumed.indexOf(p.key) !== -1 ? ' <i>(assumed)</i>' : '';
      return p.label + ': ' + fmtVal(info, p.key, r[p.key]) + assumed;
    }).join('<br>');
  }
  // prints identical in every parameter and both scores merge into one marker
  function mergeDuplicates(rows, info) {
    var keys = info.map(function (p) { return p.key; }).concat(['clarity', 'stability']);
    var map = {}, out = [];
    rows.forEach(function (r) {
      var k = keys.map(function (q) { return S.vkey(r[q]); }).join('|');
      if (!map[k]) { map[k] = { rows: [] }; out.push(map[k]); }
      map[k].rows.push(r);
    });
    out.forEach(function (u) { u.r = u.rows[0]; u.sn = u.rows.map(function (r) { return r.sn; }).join(', '); });
    return out;
  }
  // offsets for k markers sharing one position (unit-free; caller scales)
  function ringOffsets(k) {
    if (k === 1) return [[0, 0]];
    var out = [];
    for (var i = 0; i < k; i++) { var a = Math.PI / 2 + 2 * Math.PI * i / k; out.push([Math.cos(a), Math.sin(a)]); }
    return out;
  }
  // one label per cluster of markers sharing a position: all S/Ns, wrapped every 4
  function clusterLabel(us) {
    var sns = [];
    us.forEach(function (u) { u.rows.forEach(function (r) { sns.push(r.sn); }); });
    sns.sort(function (a, b) { return parseFloat(a) - parseFloat(b); });
    var lines = [];
    for (var i = 0; i < sns.length; i += 4) lines.push(sns.slice(i, i + 4).join(', '));
    return lines.join('<br>');
  }
  function gridOffsets(k) {
    var c = Math.ceil(Math.sqrt(k)), rws = Math.ceil(k / c), o = [];
    for (var i = 0; i < k; i++) o.push([(i % c) - (c - 1) / 2, -(Math.floor(i / c) - (rws - 1) / 2)]);
    return { offs: o, n: Math.max(c, rws) };
  }

  function baseLayout(info) {
    return {
      paper_bgcolor: '#000000', plot_bgcolor: '#000000',
      font: { family: 'Roboto, sans-serif', color: INK, size: 13 },
      margin: { l: 70, r: 30, t: 30, b: 60 },
      hoverlabel: { bgcolor: '#1a1a19', bordercolor: '#444', font: { family: 'Roboto, sans-serif', color: INK, size: 12 }, align: 'left' },
      legend: { font: { color: INK2, size: 12 }, bgcolor: 'rgba(0,0,0,0)', itemclick: 'toggle', itemsizing: 'constant' },
      showlegend: true
    };
  }
  function axis(title, extra) {
    var a = { title: { text: title, font: { color: INK2, size: 13 } }, color: INK2, gridcolor: GRID, zeroline: false,
              linecolor: '#555', tickfont: { color: INK2, size: 12 }, automargin: true };
    for (var k in extra) a[k] = extra[k];
    return a;
  }
  function scoreAxisRange(vals) { return [Math.min.apply(null, vals) - 0.5, Math.max.apply(null, vals) + 0.5]; }
  function padRange(sp, frac) { var p = sp.d * frac; return [sp.min - p, sp.max + p]; }

  // ---- connections (like with like) ---------------------------------------------
  // returns list of {group, pts:[[x,y,zMedian]], edges:[[i,j]], kind:'surface'|'line'}
  function connections(groupList, x, y, score) {
    var out = [];
    groupList.forEach(function (g) {
      if (g.positions.length < 2) return;
      var pos = {}, list = [];
      g.rows.forEach(function (r) {
        var k = r[x] + '|' + r[y];
        if (!pos[k]) { pos[k] = { x: r[x], y: r[y], z: [] }; list.push(pos[k]); }
        pos[k].z.push(r[score]);
      });
      var pts = list.map(function (p) { return [p.x, p.y, median(p.z)]; });
      var edges = [];
      if (g.surface) {
        var seen = {};
        D.triangulate(pts.map(function (p) { return [p[0], p[1]]; })).forEach(function (t) {
          [[t[0], t[1]], [t[1], t[2]], [t[2], t[0]]].forEach(function (e) {
            var k = Math.min(e[0], e[1]) + ',' + Math.max(e[0], e[1]);
            if (!seen[k]) { seen[k] = 1; edges.push(e); }
          });
        });
        out.push({ group: g, pts: pts, edges: edges, kind: 'surface' });
      } else {
        // collinear: order along the line (normalised projection)
        var sx = span(pts.map(function (p) { return p[0]; })), sy = span(pts.map(function (p) { return p[1]; }));
        var a = pts[0], dir = null;
        pts.forEach(function (p) { var d = [(p[0] - a[0]) / sx.d, (p[1] - a[1]) / sy.d]; if (!dir && (d[0] || d[1])) dir = d; });
        var order = pts.map(function (p, i) { return { i: i, t: ((p[0] - a[0]) / sx.d) * dir[0] + ((p[1] - a[1]) / sy.d) * dir[1] }; })
                       .sort(function (u, v) { return u.t - v.t; });
        for (var i = 0; i + 1 < order.length; i++) edges.push([order[i].i, order[i + 1].i]);
        out.push({ group: g, pts: pts, edges: edges, kind: 'line' });
      }
    });
    return out;
  }

  function constHTML(g, info) {
    var keys = Object.keys(g.values);
    return keys.length ? keys.map(function (k) { return labelOf(info, k) + ': ' + g.values[k] + (g.values[k] === S.NOT_USED ? '' : unitOf(info, k)); }).join('<br>') : 'no other parameter varies';
  }

  // ---- views -----------------------------------------------------------------------
  function scoreTraces(units, info, sc, opts, posFn, extraFn, labelFn) {
    var traces = {};
    units.forEach(function (u) { var s = String(u.r[sc]); (traces[s] = traces[s] || []).push(u); });
    var data = [], keys = [];
    ['1', '2', '3', '4', '5'].forEach(function (s) {
      var us = traces[s]; if (!us) return;
      var col = colourFor('score', s, [], true, opts);
      keys.push({ key: 'score|' + s, label: labelOf(info, sc) + ' ' + s, colour: col });
      var tr = {
        type: 'scatter', mode: opts.labels ? 'markers+text' : 'markers', meta: 'score|' + s,
        name: labelOf(info, sc) + ' ' + s, legendgroup: 's' + s,
        text: us.map(labelFn), textposition: 'top center',
        textfont: { color: INK2, size: 10 },
        hovertemplate: us.map(extraFn),
        marker: { color: col, opacity: 1, size: us.map(function (u) { return 11 + 2 * Math.min(u.rows.length - 1, 4); }), line: { color: '#000', width: 1.5 } }
      };
      var p = us.map(posFn);
      tr.x = p.map(function (q) { return q[0]; }); tr.y = p.map(function (q) { return q[1]; });
      data.push(tr);
    });
    return { data: data, keys: keys };
  }

  function mapView(sel, info, opts) {
    var x = sel.x, y = sel.y, sc = sel.score;
    var grouping = S.groups(sel.allRows, info, x, y);
    var rows = []; grouping.list.forEach(function (g) { rows = rows.concat(g.rows); });
    var xs = span(rows.map(function (r) { return r[x]; })), ys = span(rows.map(function (r) { return r[y]; }));
    var conns = connections(grouping.list, x, y, sc);
    var connectedSN = {};
    conns.forEach(function (c) { c.group.rows.forEach(function (r) { connectedSN[r.sn] = 1; }); });

    // dodge prints that land on the same spot
    var units = mergeDuplicates(rows, info), at = {}, pos = new Map(), labelOfUnit = new Map();
    units.forEach(function (u) { var k = u.r[x] + '|' + u.r[y]; (at[k] = at[k] || []).push(u); });
    var centres = [];
    Object.keys(at).forEach(function (k) {
      var us = at[k], offs = ringOffsets(us.length), rad = 0.025;
      if (us.length > 1) centres.push([us[0].r[x], us[0].r[y]]);
      us.forEach(function (u, i) { pos.set(u, [u.r[x] + offs[i][0] * rad * xs.d, u.r[y] + offs[i][1] * rad * ys.d, u.r[sc]]); labelOfUnit.set(u, i === 0 ? clusterLabel(us) : ''); });
    });
    var hover = function (u) {
      return '<b>S/N ' + u.sn + '</b>' + (u.rows.length > 1 ? ' (' + u.rows.length + ' identical prints)' : '') + '<br>' +
        axisTitle(info, x) + ': ' + u.r[x] + '<br>' + axisTitle(info, y) + ': ' + u.r[y] + '<br>' + labelOf(info, sc) + ': ' + u.r[sc] +
        '<br><br>' + settingsHTML(u.r, info, [x, y]) +
        (connectedSN[u.r.sn] ? '' : '<br><br><i>Not connected: no other print shares all its other settings</i>') + '<extra></extra>';
    };
    var data = [], extraKeys = [];

    // connections
    var lx = [], ly = [], lh = [];
    conns.forEach(function (c) {
      var lab = '<b>' + (c.kind === 'surface' ? 'Surface' : 'Line') + ' through S/N ' + c.group.sns.join(', ') + '</b><br><i>Same settings:</i><br>' + constHTML(c.group, info) + '<extra></extra>';
      c.edges.forEach(function (e) {
        [c.pts[e[0]], c.pts[e[1]]].forEach(function (p) { lx.push(p[0]); ly.push(p[1]); lh.push(lab); });
        lx.push(null); ly.push(null); lh.push('');
      });
    });
    if (lx.length) {
      var linkCol = (opts.overrides && opts.overrides['link|map']) || LINK;
      data.push({ type: 'scatter', mode: 'lines', x: lx, y: ly, name: 'Identical other settings', meta: 'link|map',
                  line: { color: linkCol, width: 1.5, dash: 'dot' }, hovertemplate: lh, showlegend: true });
      extraKeys.push({ key: 'link|map', label: 'Connection lines', colour: linkCol });
    }
    if (centres.length) {
      var cenCol = (opts.overrides && opts.overrides['centre|map']) || '#777777';
      data.push({ type: 'scatter', mode: 'markers', x: centres.map(function (c) { return c[0]; }), y: centres.map(function (c) { return c[1]; }), meta: 'centre|map',
                  marker: { symbol: 'cross-thin', size: 9, line: { color: cenCol, width: 1.5 } }, hoverinfo: 'skip', name: 'Shared position (prints spread around it)' });
      extraKeys.push({ key: 'centre|map', label: 'Shared-position crosses', colour: cenCol });
    }
    var st = scoreTraces(units, info, sc, opts, function (u) { return pos.get(u); }, hover, function (u) { return labelOfUnit.get(u); });
    data = data.concat(st.data);

    var layout = baseLayout(info);
      layout.xaxis = axis(axisTitle(info, x), { range: padRange(xs, 0.08) });
      layout.yaxis = axis(axisTitle(info, y), { range: padRange(ys, 0.1) });
    return { data: data, layout: layout, colourKeys: st.keys.concat(extraKeys), rows: rows, excluded: grouping.excluded, lines: conns.length,
             unconnected: rows.filter(function (r) { return !connectedSN[r.sn]; }).map(function (r) { return r.sn; }) };
  }

  function scatterView(sel, info, opts) {
    var rows = sel.allRows, cb = sel.colorBy;
    var cbInfo = info.filter(function (p) { return p.key === cb; })[0];
    var units = mergeDuplicates(rows, info), at = {};
    units.forEach(function (u) { var k = u.r.clarity + '|' + u.r.stability; (at[k] = at[k] || []).push(u); });
    var pos = new Map();
    Object.keys(at).forEach(function (k) {
      // stable order inside a cell: by colour value, then S/N
      var us = at[k].sort(function (a, b) {
        var ia = cbInfo.values.indexOf(S.vkey(a.r[cb])), ib = cbInfo.values.indexOf(S.vkey(b.r[cb]));
        return (ia - ib) || (parseFloat(a.r.sn) - parseFloat(b.r.sn));
      });
      var g = gridOffsets(us.length), stp = Math.min(0.7 / g.n, 0.25);
      us.forEach(function (u, i) { pos.set(u, [u.r.clarity + g.offs[i][0] * stp, u.r.stability + g.offs[i][1] * stp]); });
    });
    var traces = {};
    units.forEach(function (u) { var v = S.vkey(u.r[cb]); (traces[v] = traces[v] || []).push(u); });
    var data = [], keys = [];
    cbInfo.values.forEach(function (v) {
      var us = traces[v]; if (!us) return;
      var col = colourFor(cb, v, cbInfo.values, cbInfo.numeric, opts);
      var name = labelOf(info, cb) + ' ' + fmtVal(info, cb, v === S.NOT_USED ? null : v);
      keys.push({ key: cb + '|' + v, label: name, colour: col });
      data.push({
        type: 'scatter', mode: opts.labels ? 'markers+text' : 'markers', name: name, meta: cb + '|' + v,
        x: us.map(function (u) { return pos.get(u)[0]; }), y: us.map(function (u) { return pos.get(u)[1]; }),
        text: us.map(function (u) { return u.sn; }), textposition: 'top center', textfont: { color: INK2, size: 9 },
        marker: { color: col, opacity: 1, size: us.map(function (u) { return 10 + 2 * Math.min(u.rows.length - 1, 4); }), line: { color: '#000', width: 1.5 } },
        hovertemplate: us.map(function (u) {
          return '<b>S/N ' + u.sn + '</b>' + (u.rows.length > 1 ? ' (' + u.rows.length + ' identical prints)' : '') +
                 '<br>Clarity: ' + u.r.clarity + '<br>Stability: ' + u.r.stability + '<br><br>' + settingsHTML(u.r, info, []) + '<extra></extra>';
        })
      });
    });
    var cr = scoreAxisRange(rows.map(function (r) { return r.clarity; })), sr = scoreAxisRange(rows.map(function (r) { return r.stability; }));
    var layout = baseLayout(info);
    layout.xaxis = axis('Clarity', { range: cr, dtick: 1, showgrid: false });
    layout.yaxis = axis('Stability', { range: sr, dtick: 1, showgrid: false });
    layout.shapes = [];
    for (var c = Math.ceil(cr[0]); c < cr[1]; c++) layout.shapes.push({ type: 'line', x0: c + 0.5, x1: c + 0.5, y0: sr[0], y1: sr[1], line: { color: GRID, width: 1 } });
    for (var s = Math.ceil(sr[0]); s < sr[1]; s++) layout.shapes.push({ type: 'line', y0: s + 0.5, y1: s + 0.5, x0: cr[0], x1: cr[1], line: { color: GRID, width: 1 } });
    return { data: data, layout: layout, colourKeys: keys, rows: rows, excluded: [], lines: 0, unconnected: [],
             tooManyCategories: !cbInfo.numeric && cbInfo.values.filter(function (v) { return v !== S.NOT_USED; }).length > CATEG.length };
  }


  // ---- E: history (S/N order) – scores, optionally overlaid with up to two parameters on own right axes ----
  // ---- top-n ranking (competition ranking: ties share a rank; all prints tied at the cut-off are included)
  var RANKERS = {
    clarity:   { label: 'Clarity',                          key: function (r) { return [r.clarity]; } },
    stability: { label: 'Stability',                        key: function (r) { return [r.stability]; } },
    sum:       { label: 'Combined (Clarity + Stability)',   key: function (r) { return [r.clarity + r.stability]; } },
    min:       { label: 'Weakest score, then combined',     key: function (r) { return [Math.min(r.clarity, r.stability), r.clarity + r.stability]; } }
  };
  function cmpKey(a, b) { for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return b[i] - a[i]; return 0; }
  function rankTop(rows, n, by) {
    if (!n || n < 1 || !rows.length) return [];
    var R = RANKERS[by] || RANKERS.min;
    var list = rows.map(function (r) { return { row: r, key: R.key(r) }; });
    list.sort(function (a, b) { return cmpKey(a.key, b.key) || (parseFloat(a.row.sn) - parseFloat(b.row.sn)); });
    var cut = list[Math.min(n, list.length) - 1].key;
    var top = list.filter(function (e) { return cmpKey(e.key, cut) <= 0; });
    top.forEach(function (e) { e.rank = 1 + list.filter(function (o) { return cmpKey(o.key, e.key) < 0; }).length; });
    return top;
  }

  var OVERLAY_DEFAULT = ['#199e70', '#e0e0dc'];   // validated with the two score colours on #000 (all pairs)
  var OVERLAY_DASH = ['dash', 'dot'];
  function historyView(sel, info, opts) {
    var rows = sel.allRows.slice().sort(function (a, b) {
      var na = parseFloat(a.sn), nb = parseFloat(b.sn);
      return (isNaN(na) || isNaN(nb)) ? a._row - b._row : (na - nb) || (a._row - b._row);
    });
    var xs = rows.map(function (r) { return r.sn; });
    var col = function (k, def) { return (opts.overrides && opts.overrides[k]) || def; };
    var cClar = col('hist|clarity', CATEG[0]), cStab = col('hist|stability', CATEG[1]);
    var overlays = (sel.overlays || []).filter(function (k, i, arr) {
      return k && arr.indexOf(k) === i && info.some(function (p) { return p.key === k && p.varies; });
    }).slice(0, 2);
    var data = [], layout = baseLayout(info), keys = [];
    var dashOf = function (k, def) { return (opts.dash && opts.dash[k]) || def; };

    [['clarity', 'Clarity', cClar], ['stability', 'Stability', cStab]].forEach(function (s) {
      data.push({ type: 'scatter', mode: 'lines+markers', x: xs, y: rows.map(function (r) { return r[s[0]]; }), name: s[1], yaxis: 'y', meta: 'hist|' + s[0],
                  line: { color: s[2], width: 2.5, dash: dashOf('hist|' + s[0], 'solid') }, marker: { color: s[2], size: 8, line: { color: '#000', width: 1.5 } },
                  hovertemplate: s[1] + ': %{y}<extra></extra>' });
      keys.push({ key: 'hist|' + s[0], label: s[1], colour: s[2], dash: dashOf('hist|' + s[0], 'solid') });
    });
    var scores = rows.map(function (r) { return r.clarity; }).concat(rows.map(function (r) { return r.stability; }));
    var xEnd = overlays.length === 2 ? 0.86 : overlays.length === 1 ? 0.93 : 1;
    layout.yaxis = axis('Score', { range: scoreAxisRange(scores), dtick: 1 });
    layout.xaxis = axis('S/N (test order)', { type: 'category', domain: [0, xEnd], tickangle: 0, showspikes: true, spikemode: 'across',
                                              spikecolor: '#666', spikethickness: 1, spikedash: 'dot' });

    overlays.forEach(function (k, i) {
      var p = info.filter(function (q) { return q.key === k; })[0];
      var c = col('hist|' + k, OVERLAY_DEFAULT[i]);
      var ys = rows.map(function (r) { return r[k] === null || r[k] === undefined ? null : r[k]; });
      var changed = rows.map(function (r, j) { return j === 0 || S.vkey(r[k]) !== S.vkey(rows[j - 1][k]); });
      var assumed = rows.map(function (r) { return !!(r._assumed && r._assumed.indexOf(k) !== -1); });
      var title = p.label + (p.unit ? ' (' + p.unit + ')' : '');
      data.push({
        type: 'scatter', mode: 'lines+markers', x: xs, y: ys, yaxis: i === 0 ? 'y2' : 'y3', connectgaps: false, meta: 'hist|' + k,
        name: title + ' – ' + (i === 0 ? 'right axis' : 'outer right axis'),
        line: { color: c, width: 2, shape: 'hv', dash: dashOf('hist|' + k, OVERLAY_DASH[i]) },
        marker: { color: assumed.map(function (a) { return a ? '#000' : c; }), opacity: 1, size: changed.map(function (ch) { return ch ? 9 : 0.1; }),
                  line: { color: c, width: 1.5 } },
        hovertemplate: rows.map(function (r, j) {
          return p.label + ': ' + fmtVal(info, k, r[k]) + (assumed[j] ? ' (assumed)' : '') + (changed[j] && j > 0 ? '  ← changed' : '') + '<extra></extra>';
        })
      });
      // the overlay's own axis fades with its line (axis line, ticks, tick labels, title)
      var aop = opts.opacity && opts.opacity['hist|' + k] !== undefined ? opts.opacity['hist|' + k] : 1;
      var a = axis(title, { overlaying: 'y', side: 'right', showgrid: false, linecolor: rgba(c, aop), linewidth: 2, showline: true,
                            tickmode: 'auto', nticks: 6, color: rgba(INK2, aop), tickfont: { color: rgba(INK2, aop), size: 11 } });
      a.title.font.color = rgba(INK2, aop);
      if (i === 1) { a.anchor = 'free'; a.position = 1; }
      else a.anchor = 'x';
      if (!p.numeric) { a.type = 'category'; a.categoryorder = 'array'; a.categoryarray = p.values.filter(function (v) { return v !== S.NOT_USED; }); }
      else { var v = ys.filter(function (q) { return q !== null; }); a.range = padRange(span(v), 0.12); }
      layout[i === 0 ? 'yaxis2' : 'yaxis3'] = a;
      keys.push({ key: 'hist|' + k, label: title, colour: c, dash: dashOf('hist|' + k, OVERLAY_DASH[i]) });
    });

    // top-n callouts: band behind each top S/N, rank label above, ring on the score(s) used for ranking
    var top = rankTop(rows, sel.topN, sel.rankBy), topCol = col('top|callout', '#ffffff');
    var topOp = opts.opacity && opts.opacity['top|callout'] !== undefined ? opts.opacity['top|callout'] : 1;
    if (top.length) {
      layout.shapes = (layout.shapes || []).concat(top.map(function (e) {
        var i = xs.indexOf(e.row.sn);
        return { type: 'rect', xref: 'x', yref: 'paper', x0: i - 0.42, x1: i + 0.42, y0: 0, y1: 1, layer: 'below', line: { width: 0 }, fillcolor: rgba(topCol, 0.13 * topOp) };
      }));
      layout.annotations = (layout.annotations || []).concat(top.map(function (e) {
        return { name: 'rank', xref: 'x', yref: 'paper', x: xs.indexOf(e.row.sn), y: 0, yanchor: 'bottom', yshift: 3, showarrow: false, text: '#' + e.rank,
                 font: { family: 'Roboto, sans-serif', size: 11, color: rgba(topCol, topOp) } };
      }));
      var which = sel.rankBy === 'clarity' ? ['clarity'] : sel.rankBy === 'stability' ? ['stability'] : ['clarity', 'stability'];
      var rx = [], ry = [], rh = [];
      top.forEach(function (e) { which.forEach(function (k) { rx.push(e.row.sn); ry.push(e.row[k]); rh.push('Top result #' + e.rank); }); });
      data.push({ type: 'scatter', mode: 'markers', x: rx, y: ry, yaxis: 'y', name: 'Top ' + sel.topN + ' (' + RANKERS[sel.rankBy || 'min'].label.toLowerCase() + ')',
                  meta: 'top|callout', marker: { symbol: 'circle-open', size: 17, opacity: 1, color: topCol, line: { color: topCol, width: 2 } },
                  hovertemplate: rh.map(function (h) { return h + '<extra></extra>'; }) });
      keys.push({ key: 'top|callout', label: 'Top-' + sel.topN + ' callouts', colour: topCol, noDash: true });
    }

    layout.hovermode = 'x unified';
    layout.margin = { l: 70, r: 30, t: 50, b: 60 };
    layout.legend.orientation = 'h'; layout.legend.y = 1.02; layout.legend.yanchor = 'bottom'; layout.legend.x = 0; layout.legend.xanchor = 'left';
    return { data: data, layout: layout, colourKeys: keys, rows: rows, excluded: [], lines: 0, unconnected: [], overlays: overlays, top: top };
  }

  function rgba(c, a) {
    if (typeof c !== 'string' || c.charAt(0) !== '#') return c;
    var v = hex2rgb(c); return 'rgba(' + v[0] + ',' + v[1] + ',' + v[2] + ',' + a + ')';
  }
  // apply opacity a to every visible part of a trace: line, markers (fill + outline), text labels
  function fade(t, a) {
    t._fade = a;
    if (t.line && t.line.color) t.line.color = rgba(t.line.color, a);
    if (t.marker) t.marker.opacity = a;
    if (t.textfont && t.textfont.color) t.textfont.color = rgba(t.textfont.color, a);
  }
  // per-item text sizes (px at the 1600 px export layout width); one place for every view
  var TEXT_DEFAULT = { axis: 13, tick: 12, legend: 12, label: 10 };
  function applyText(fig, ts) {
    var L = fig.layout;
    Object.keys(L).forEach(function (k) {
      if (!/^[xy]axis\d*$/.test(k)) return;
      var a = L[k];
      if (a.title && a.title.font) a.title.font.size = ts.axis;
      if (a.tickfont) a.tickfont.size = ts.tick;
    });
    if (L.legend) { L.legend.font = L.legend.font || {}; L.legend.font.size = ts.legend; }
    fig.data.forEach(function (t) { if (t.textfont) t.textfont.size = ts.label; });
    (L.annotations || []).forEach(function (a) { if (a.name === 'rank') a.font.size = ts.label; });
  }
  function build(sel, info, opts) {
    var fig = sel.view === 'map2d' ? mapView(sel, info, opts) : sel.view === 'history' ? historyView(sel, info, opts) : scatterView(sel, info, opts);
    var ts = {}; Object.keys(TEXT_DEFAULT).forEach(function (k) { ts[k] = (opts.text && opts.text[k]) || TEXT_DEFAULT[k]; });
    applyText(fig, ts);
    fig.text = ts;
    // per-entity opacity (0–1); applies to the whole trace: lines, markers and its S/N labels
    // baked into colours (not trace.opacity): SVG→PDF converters do not reliably multiply group opacity
    var op = opts.opacity || {};
    fig.data.forEach(function (t) { if (t.meta && op[t.meta] !== undefined && op[t.meta] < 1) fade(t, op[t.meta]); });
    fig.colourKeys.forEach(function (k) { k.opacity = op[k.key] !== undefined ? op[k.key] : 1; });
    return fig;
  }

  var api = { TEXT_DEFAULT: TEXT_DEFAULT, RANKERS: RANKERS, rankTop: rankTop, RAMPS: RAMPS, CATEG: CATEG, build: build, colourFor: colourFor, sample: sample, connections: connections, median: median };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PrintPlots = api;
})(this);
