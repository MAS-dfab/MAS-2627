/* parse.js – template check + row parsing for the print-parameter workbook.
   Pure functions: no DOM. Works in the browser (window.PrintParse) and in Node (module.exports). */
(function (root) {
  'use strict';

  // ---- Fixed template -------------------------------------------------------
  // row2 = main header (merged cells: value sits in the first column of the merge)
  // row3 = sub header (only for split columns)
  // blank: 'required' -> row skipped if blank
  //        'default:<n>' -> blank replaced by n (flagged as assumed)
  //        'text:<s>' -> blank replaced by text s (flagged as assumed)
  //        'notused' -> blank stored as null and shown as "not used"
  var COLUMNS = [
    { key: 'sn',        col: 'A', row2: ['S/N'],                     type: 'id',    blank: 'required', label: 'S/N' },
    { key: 'material',  col: 'B', row2: ['Material'],                type: 'text',  blank: 'required', label: 'Material' },
    { key: 'colour',    col: 'C', row2: ['Colour', 'Color'],         type: 'text',  blank: 'text:unspecified', label: 'Colour' },
    { key: 'lh',        col: 'D', row2: ['Layer Height'],            type: 'num',   blank: 'default:2', label: 'Layer Height', unit: 'mm' },
    { key: 'temp',      col: 'E', row2: ['Temperature'],             type: 'num',   blank: 'required', label: 'Temperature', unit: '°C' },
    { key: 'e1',        col: 'F', row2: ['Extrusion Speed'], row3: 'e1', type: 'num', blank: 'required', label: 'e1', unit: 'mm/s' },
    { key: 'e2',        col: 'G',                            row3: 'e2', type: 'num', blank: 'notused',  label: 'e2', unit: 'mm/s' },
    { key: 'v1',        col: 'H', row2: ['Robot Velocity'],  row3: 'v1', type: 'num', blank: 'required', label: 'v1', unit: 'mm/s' },
    { key: 'v2',        col: 'I',                            row3: 'v2', type: 'num', blank: 'notused',  label: 'v2', unit: 'mm/s' },
    { key: 'a1',        col: 'J', row2: ['Acceleration'],    row3: 'a1', type: 'num', blank: 'required', label: 'a1', unit: 'mm/s²' },
    { key: 'a2',        col: 'K',                            row3: 'a2', type: 'num', blank: 'notused',  label: 'a2', unit: 'mm/s²' },
    { key: 't1',        col: 'L', row2: ['Pause Time'],      row3: 't1', type: 'num', blank: 'required', label: 't1', unit: 's' },
    { key: 'clarity',   col: 'M', row2: ['Clarity'],                 type: 'score', blank: 'required', label: 'Clarity' },
    { key: 'stability', col: 'N', row2: ['Stability'],               type: 'score', blank: 'required', label: 'Stability' }
  ];
  var FIRST_DATA_ROW = 4;
  var BLANK_TOKENS = ['', '-', '–', '—'];

  function norm(v) {
    return v === undefined || v === null ? '' : String(v).trim().replace(/\s+/g, ' ').toLowerCase();
  }
  function isBlank(v) {
    return v === undefined || v === null || BLANK_TOKENS.indexOf(String(v).trim()) !== -1;
  }
  function cellVal(ws, addr) {
    var c = ws[addr];
    return c ? c.v : undefined;
  }
  // Number from a cell: returns {ok, value, converted}
  function toNumber(v) {
    if (typeof v === 'number' && isFinite(v)) return { ok: true, value: v, converted: false };
    if (typeof v === 'string') {
      var s = v.trim();
      if (/^-?\d+([.,]\d+)?$/.test(s)) return { ok: true, value: parseFloat(s.replace(',', '.')), converted: true };
    }
    return { ok: false };
  }
  // Rounds away float noise from Excel (e.g. 1.4500000000000002)
  function clean(n) { return Math.round(n * 1e9) / 1e9; }

  // ---- Header check ---------------------------------------------------------
  function checkHeaders(ws) {
    var problems = [];
    COLUMNS.forEach(function (c) {
      if (c.row2) {
        var got = norm(cellVal(ws, c.col + '2'));
        if (c.row2.map(norm).indexOf(got) === -1)
          problems.push('Cell ' + c.col + '2 should read "' + c.row2[0] + '" but reads "' + (cellVal(ws, c.col + '2') ?? '') + '".');
      }
      if (c.row3) {
        var got3 = norm(cellVal(ws, c.col + '3'));
        if (got3 !== c.row3)
          problems.push('Cell ' + c.col + '3 should read "' + c.row3 + '" but reads "' + (cellVal(ws, c.col + '3') ?? '') + '".');
      }
    });
    return problems;
  }

  // ---- Workbook -> dataset ----------------------------------------------------
  // XLSX is the SheetJS namespace (needed only for decode_range).
  function parseWorkbook(wb, XLSX) {
    var out = { sheetName: null, otherSheets: [], rows: [], skipped: [], warnings: [], errors: [] };

    var candidates = wb.SheetNames.filter(function (n) { return norm(cellVal(wb.Sheets[n], 'A2')) === 's/n'; });
    if (!candidates.length) {
      out.errors.push('No sheet has "S/N" in cell A2. The data sheet must follow the template (headers in rows 2–3, data from row 4).');
      return out;
    }
    out.sheetName = candidates[0];
    out.otherSheets = candidates.slice(1);
    if (out.otherSheets.length)
      out.warnings.push('Several sheets match the template; using "' + out.sheetName + '". Ignored: ' + out.otherSheets.join(', ') + '.');

    var ws = wb.Sheets[out.sheetName];
    var hp = checkHeaders(ws);
    if (hp.length) { out.errors = out.errors.concat(hp); return out; }

    var lastRow = ws['!ref'] ? XLSX.utils.decode_range(ws['!ref']).e.r + 1 : 0;
    var seenSN = {};

    for (var r = FIRST_DATA_ROW; r <= lastRow; r++) {
      var raw = {};
      var allBlank = true;
      COLUMNS.forEach(function (c) {
        raw[c.key] = cellVal(ws, c.col + r);
        if (!isBlank(raw[c.key])) allBlank = false;
      });
      if (allBlank) continue; // empty / formatting-only row

      var rec = { _row: r, _assumed: [], _converted: [] };
      var reasons = [];

      COLUMNS.forEach(function (c) {
        var v = raw[c.key];
        if (isBlank(v)) {
          if (c.blank === 'required') reasons.push(c.label + ' is blank');
          else if (c.blank === 'notused') rec[c.key] = null;
          else if (c.blank.indexOf('text:') === 0) {
            rec[c.key] = c.blank.slice(5);
            rec._assumed.push(c.key);
          }
          else if (c.blank.indexOf('default:') === 0) {
            rec[c.key] = parseFloat(c.blank.split(':')[1]);
            rec._assumed.push(c.key);
          }
          return;
        }
        if (c.type === 'text') { rec[c.key] = String(v).trim(); return; }
        if (c.type === 'id') {
          var n = toNumber(v);
          rec[c.key] = n.ok ? String(clean(n.value)) : String(v).trim();
          return;
        }
        var num = toNumber(v);
        if (!num.ok) { reasons.push(c.label + ' is not a number ("' + v + '")'); return; }
        var val = clean(num.value);
        if (num.converted) rec._converted.push(c.key);
        if (c.type === 'score' && !(Number.isInteger(val) && val >= 1 && val <= 5)) {
          reasons.push(c.label + ' must be a whole number 1–5 (got ' + val + ')');
          return;
        }
        rec[c.key] = val;
      });

      var snLabel = isBlank(raw.sn) ? '(no S/N)' : String(rec.sn !== undefined ? rec.sn : raw.sn);
      if (reasons.length) { out.skipped.push({ row: r, sn: snLabel, reasons: reasons }); continue; }

      if (seenSN[rec.sn]) out.warnings.push('S/N ' + rec.sn + ' appears more than once (rows ' + seenSN[rec.sn] + ' and ' + r + '). Both are kept.');
      else seenSN[rec.sn] = r;
      if (rec._converted.length)
        out.warnings.push('S/N ' + rec.sn + ' (row ' + r + '): ' + rec._converted.join(', ') + ' stored as text, read as number.');
      out.rows.push(rec);
    }

    if (!out.rows.length && !out.skipped.length) out.errors.push('The sheet "' + out.sheetName + '" has no data rows from row 4 onward.');
    return out;
  }

  var api = { COLUMNS: COLUMNS, FIRST_DATA_ROW: FIRST_DATA_ROW, parseWorkbook: parseWorkbook, checkHeaders: checkHeaders };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PrintParse = api;
})(this);
