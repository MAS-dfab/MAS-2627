/* delaunay.js – Bowyer–Watson triangulation for small point sets (tens of points).
   Input: array of [x, y]; coordinates are normalised to the unit square internally so that
   axes with different units (°C vs mm/s) do not distort the triangles.
   Output: array of [i, j, k] index triples (counter-clockwise). Duplicate points must be removed first. */
(function (root) {
  'use strict';

  function triangulate(pts) {
    var n = pts.length;
    if (n < 3) return [];
    var xs = pts.map(function (p) { return p[0]; }), ys = pts.map(function (p) { return p[1]; });
    var x0 = Math.min.apply(null, xs), xr = (Math.max.apply(null, xs) - x0) || 1;
    var y0 = Math.min.apply(null, ys), yr = (Math.max.apply(null, ys) - y0) || 1;
    var P = pts.map(function (p) { return [(p[0] - x0) / xr, (p[1] - y0) / yr]; });
    // super triangle well outside the unit square
    P.push([-1e5, -1e5], [1e5, -1e5], [0.5, 1e5]);
    var tris = [mk(n, n + 1, n + 2)];

    function mk(a, b, c) {
      var ax = P[a][0], ay = P[a][1], bx = P[b][0], by = P[b][1], cx = P[c][0], cy = P[c][1];
      var d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by));
      if (d < 0) { var t = b; b = c; c = t; d = -d; bx = P[b][0]; by = P[b][1]; cx = P[c][0]; cy = P[c][1]; }
      var a2 = ax * ax + ay * ay, b2 = bx * bx + by * by, c2 = cx * cx + cy * cy;
      var ux = (a2 * (by - cy) + b2 * (cy - ay) + c2 * (ay - by)) / d;
      var uy = (a2 * (cx - bx) + b2 * (ax - cx) + c2 * (bx - ax)) / d;
      return { v: [a, b, c], cx: ux, cy: uy, r2: (ax - ux) * (ax - ux) + (ay - uy) * (ay - uy) };
    }

    for (var i = 0; i < n; i++) {
      var px = P[i][0], py = P[i][1], bad = [], keep = [];
      tris.forEach(function (t) {
        var dx = px - t.cx, dy = py - t.cy;
        (dx * dx + dy * dy < t.r2 * (1 + 1e-12) ? bad : keep).push(t);
      });
      // boundary edges of the cavity = edges used by exactly one bad triangle
      var edges = {};
      bad.forEach(function (t) {
        for (var e = 0; e < 3; e++) {
          var a = t.v[e], b = t.v[(e + 1) % 3], k = a < b ? a + ',' + b : b + ',' + a;
          edges[k] = edges[k] ? null : [a, b];
        }
      });
      tris = keep;
      Object.keys(edges).forEach(function (k) { if (edges[k]) tris.push(mk(edges[k][0], edges[k][1], i)); });
    }
    return tris.filter(function (t) { return t.v[0] < n && t.v[1] < n && t.v[2] < n; })
               .map(function (t) { return t.v; })
               // drop zero-area slivers (collinear triples on the hull)
               .filter(function (v) {
                 var a = P[v[0]], b = P[v[1]], c = P[v[2]];
                 return Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])) > 1e-12;
               });
  }

  var api = { triangulate: triangulate };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PrintDelaunay = api;
})(this);
