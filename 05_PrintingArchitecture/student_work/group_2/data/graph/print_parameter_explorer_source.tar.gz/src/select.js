/* select.js – parameter info, strict grouping and group navigation. Pure, no DOM. */
(function (root) {
  'use strict';

  // Parameters a user can put on an axis or hold constant (scores excluded).
  var PARAMS = [
    { key: 'material', label: 'Material',     numeric: false },
    { key: 'colour',   label: 'Colour',       numeric: false },
    { key: 'lh',       label: 'Layer Height', numeric: true, unit: 'mm' },
    { key: 'temp',     label: 'Temperature',  numeric: true, unit: '°C' },
    { key: 'e1',       label: 'Extrusion e1', numeric: true, unit: 'mm/s' },
    { key: 'e2',       label: 'Extrusion e2', numeric: true, unit: 'mm/s' },
    { key: 'v1',       label: 'Robot v1',     numeric: true, unit: 'mm/s' },
    { key: 'v2',       label: 'Robot v2',     numeric: true, unit: 'mm/s' },
    { key: 'a1',       label: 'Accel. a1',    numeric: true, unit: 'mm/s²' },
    { key: 'a2',       label: 'Accel. a2',    numeric: true, unit: 'mm/s²' },
    { key: 't1',       label: 'Pause t1',     numeric: true, unit: 's' }
  ];
  var SCORES = [{ key: 'clarity', label: 'Clarity' }, { key: 'stability', label: 'Stability' }];
  var NOT_USED = 'not used';

  function byKey(k) { for (var i = 0; i < PARAMS.length; i++) if (PARAMS[i].key === k) return PARAMS[i]; return null; }
  function vkey(v) { return v === null || v === undefined ? NOT_USED : String(v); }
  function sortVals(vals, numeric) {
    return vals.slice().sort(function (a, b) {
      if (a === NOT_USED) return 1;
      if (b === NOT_USED) return -1;
      return numeric ? parseFloat(a) - parseFloat(b) : a.localeCompare(b);
    });
  }

  // Distinct values per parameter; parameters with one value in the whole file are "fixed".
  function paramInfo(rows) {
    return PARAMS.map(function (p) {
      var set = {};
      rows.forEach(function (r) { set[vkey(r[p.key])] = true; });
      var vals = sortVals(Object.keys(set), p.numeric);
      var numericVals = vals.filter(function (v) { return v !== NOT_USED; });
      return {
        key: p.key, label: p.label, unit: p.unit, numeric: p.numeric,
        values: vals,
        varies: vals.length > 1,
        // usable as an axis: numeric and at least two numeric values
        axisOK: p.numeric && numericVals.length > 1
      };
    });
  }

  // Normalised collinearity test for distinct (x,y) positions.
  function surfacePossible(pos) {
    if (pos.length < 3) return false;
    var xs = pos.map(function (p) { return p[0]; }), ys = pos.map(function (p) { return p[1]; });
    var x0 = Math.min.apply(null, xs), xr = Math.max.apply(null, xs) - x0;
    var y0 = Math.min.apply(null, ys), yr = Math.max.apply(null, ys) - y0;
    if (xr === 0 || yr === 0) return false;
    var n = pos.map(function (p) { return [(p[0] - x0) / xr, (p[1] - y0) / yr]; });
    var a = n[0], far = n[1], best = -1;
    n.forEach(function (p) { var d = Math.hypot(p[0] - a[0], p[1] - a[1]); if (d > best) { best = d; far = p; } });
    return n.some(function (p) {
      return Math.abs((far[0] - a[0]) * (p[1] - a[1]) - (far[1] - a[1]) * (p[0] - a[0])) > 1e-9;
    });
  }

  /* Strict groups for an X/Y choice.
     y may be null (line plot without series).
     constKeys = varying parameters other than x and y; every group has one value for each. */
  function groups(rows, info, x, y) {
    var constKeys = info.filter(function (p) { return p.varies && p.key !== x && p.key !== y; }).map(function (p) { return p.key; });
    var usable = [], excluded = [];
    rows.forEach(function (r) {
      if (r[x] === null || (y && r[y] === null)) excluded.push(r.sn); else usable.push(r);
    });
    var map = {};
    usable.forEach(function (r) {
      var tuple = constKeys.map(function (k) { return vkey(r[k]); });
      var id = JSON.stringify(tuple);
      (map[id] = map[id] || { id: id, values: {}, rows: [] }).rows.push(r);
      constKeys.forEach(function (k, i) { map[id].values[k] = tuple[i]; });
    });
    var list = Object.keys(map).map(function (id) {
      var g = map[id], pos = {}, xs = {}, ys = {};
      g.rows.forEach(function (r) {
        pos[r[x] + '|' + (y ? r[y] : '')] = [r[x], y ? r[y] : 0];
        xs[r[x]] = 1; if (y) ys[r[y]] = 1;
      });
      g.positions = Object.keys(pos).map(function (k) { return pos[k]; });
      g.nX = Object.keys(xs).length;
      g.nY = y ? Object.keys(ys).length : 0;
      g.surface = y ? surfacePossible(g.positions) : false;
      g.sns = g.rows.map(function (r) { return r.sn; });
      return g;
    });
    // most informative first: distinct positions, then distinct X, then prints
    list.sort(function (a, b) {
      return (b.positions.length - a.positions.length) || (b.nX - a.nX) || (b.rows.length - a.rows.length) ||
             (parseFloat(a.sns[0]) - parseFloat(b.sns[0]));
    });
    return { constKeys: constKeys, list: list, excluded: excluded };
  }

  // User set constKey = value: pick the group with that value that changes the fewest other settings.
  function nearestGroup(list, constKeys, current, key, value) {
    var best = null, bestScore = -1;
    list.forEach(function (g, idx) {
      if (g.values[key] !== value) return;
      var same = constKeys.reduce(function (s, k) { return s + (current && g.values[k] === current.values[k] ? 1 : 0); }, 0);
      // tie-break keeps the list order (more positions first)
      if (same > bestScore) { bestScore = same; best = g; }
    });
    return best;
  }

  // Options per constant parameter: all values present among groups; flag those reachable without other changes.
  function constOptions(list, constKeys, current, info) {
    var out = {};
    constKeys.forEach(function (k) {
      var set = {};
      list.forEach(function (g) {
        var direct = constKeys.every(function (o) { return o === k || !current || g.values[o] === current.values[o]; });
        set[g.values[k]] = set[g.values[k]] || direct;
      });
      var p = info.filter(function (i) { return i.key === k; })[0];
      out[k] = sortVals(Object.keys(set), p.numeric).map(function (v) { return { value: v, direct: set[v] }; });
    });
    return out;
  }

  // Scatter D: optional filters with "All"; standard faceted filtering.
  var ALL = '__all__';
  function filterRows(rows, filters) {
    return rows.filter(function (r) {
      return Object.keys(filters).every(function (k) { return filters[k] === ALL || vkey(r[k]) === filters[k]; });
    });
  }
  function facetOptions(rows, info, filters) {
    var out = {};
    info.filter(function (p) { return p.varies; }).forEach(function (p) {
      var others = {};
      Object.keys(filters).forEach(function (k) { if (k !== p.key) others[k] = filters[k]; });
      var set = {};
      filterRows(rows, others).forEach(function (r) { set[vkey(r[p.key])] = true; });
      out[p.key] = sortVals(Object.keys(set), p.numeric);
    });
    return out;
  }

  var api = { PARAMS: PARAMS, SCORES: SCORES, NOT_USED: NOT_USED, ALL: ALL, byKey: byKey, vkey: vkey,
              paramInfo: paramInfo, groups: groups, nearestGroup: nearestGroup, constOptions: constOptions,
              surfacePossible: surfacePossible, filterRows: filterRows, facetOptions: facetOptions };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PrintSelect = api;
})(this);
