/* app.js – UI wiring. Stage 1: load, validate, show parsed data. */
(function () {
  'use strict';
  var P = window.PrintParse;
  var state = { data: null, fileName: null };
  window.APP_STATE = state; // exposed for testing

  var $ = function (id) { return document.getElementById(id); };
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  // ---- file input -----------------------------------------------------------
  var drop = $('drop'), input = $('file');
  drop.addEventListener('click', function () { input.click(); });
  drop.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') input.click(); });
  drop.addEventListener('dragover', function (e) { e.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', function () { drop.classList.remove('over'); });
  drop.addEventListener('drop', function (e) {
    e.preventDefault(); drop.classList.remove('over');
    if (e.dataTransfer.files.length) loadFile(e.dataTransfer.files[0]);
  });
  input.addEventListener('change', function () { if (input.files.length) loadFile(input.files[0]); input.value = ''; });

  function loadFile(file) {
    $('fileName').textContent = 'Reading ' + file.name + ' …';
    var reader = new FileReader();
    reader.onload = function (ev) {
      var wb;
      try { wb = XLSX.read(new Uint8Array(ev.target.result), { type: 'array' }); }
      catch (err) { showResult(file.name, { errors: ['Could not read this file as a spreadsheet (' + err.message + ').'], rows: [], skipped: [], warnings: [] }); return; }
      showResult(file.name, P.parseWorkbook(wb, XLSX));
    };
    reader.onerror = function () { showResult(file.name, { errors: ['The file could not be read.'], rows: [], skipped: [], warnings: [] }); };
    reader.readAsArrayBuffer(file);
  }

  // ---- results ----------------------------------------------------------------
  function list(items) { return '<ul>' + items.map(function (i) { return '<li>' + esc(i) + '</li>'; }).join('') + '</ul>'; }

  function showResult(name, res) {
    state.fileName = name;
    state.data = res.errors.length ? null : res;
    $('fileName').innerHTML = '<b>' + esc(name) + '</b>' + (res.sheetName ? ' · sheet "' + esc(res.sheetName) + '"' : '');

    var m = '';
    if (res.errors.length) m += '<div class="msg err"><b>File not loaded – it does not match the template.</b>' + list(res.errors) + '</div>';
    if (res.skipped.length) m += '<div class="msg err"><b>' + res.skipped.length + ' row(s) skipped:</b>' +
      list(res.skipped.map(function (s) { return 'Row ' + s.row + ' (S/N ' + s.sn + '): ' + s.reasons.join('; '); })) + '</div>';
    if (res.warnings.length) m += '<div class="msg warn"><b>Warnings:</b>' + list(res.warnings) + '</div>';
    if (!res.errors.length && !res.skipped.length && !res.warnings.length) m = '<div class="msg ok">File matches the template. No problems found.</div>';
    $('messages').innerHTML = m;

    if (!state.data) { $('dataSection').classList.add('hidden'); $('selSection').classList.add('hidden'); return; }
    renderSummary(res);
    renderTable(res.rows);
    $('dataSection').classList.remove('hidden');
    document.dispatchEvent(new CustomEvent('dataloaded', { detail: res }));
  }

  function renderSummary(res) {
    var assumed = res.rows.filter(function (r) { return r._assumed.indexOf('lh') !== -1; }).map(function (r) { return r.sn; });
    var noColour = res.rows.filter(function (r) { return r._assumed.indexOf('colour') !== -1; }).map(function (r) { return r.sn; });
    var mats = {};
    res.rows.forEach(function (r) { mats[r.material] = (mats[r.material] || 0) + 1; });
    var h = '<div><b>' + res.rows.length + '</b>prints loaded</div>' +
            '<div><b>' + res.skipped.length + '</b>rows skipped</div>' +
            '<div><b>' + Object.keys(mats).length + '</b>materials: ' + Object.keys(mats).map(function (k) { return esc(k) + ' (' + mats[k] + ')'; }).join(', ') + '</div>';
    if (assumed.length) h += '<div><b>' + assumed.length + '</b>layer height assumed 2 mm: S/N ' + esc(assumed.join(', ')) + '</div>';
    if (noColour.length) h += '<div><b>' + noColour.length + '</b>colour blank → "unspecified": S/N ' + esc(noColour.join(', ')) + '</div>';
    $('summary').innerHTML = h;
  }

  function fmt(v) { return v === null || v === undefined ? 'not used' : String(v); }

  function renderTable(rows) {
    var C = P.COLUMNS;
    // group header row (mirrors the sheet)
    var groups = { e1: 'Extrusion Speed', v1: 'Robot Velocity', a1: 'Acceleration' };
    var top = '<tr>';
    var bottom = '<tr>';
    for (var i = 0; i < C.length; i++) {
      var c = C[i];
      if (groups[c.key]) {
        top += '<th class="grp" colspan="2">' + groups[c.key] + ' <span class="u" style="display:inline">(' + c.unit + ')</span></th>';
        bottom += '<th>' + c.label + '</th><th>' + C[i + 1].label + '</th>';
        i++;
      } else if (c.key === 't1') {
        top += '<th class="grp">Pause Time <span class="u" style="display:inline">(s)</span></th>';
        bottom += '<th>t1</th>';
      } else {
        var cls = c.type === 'text' ? ' class="t"' : '';
        top += '<th' + cls + ' rowspan="2">' + c.label + (c.unit ? '<span class="u">' + c.unit + '</span>' : '') + '</th>';
      }
    }
    top += '</tr>'; bottom += '</tr>';
    var body = rows.map(function (r) {
      return '<tr>' + C.map(function (c) {
        var v = r[c.key], cls = [];
        if (c.type === 'text') cls.push('t');
        if (v === null) cls.push('nu');
        if (r._assumed.indexOf(c.key) !== -1) cls.push('as');
        if (c.type === 'score') cls.push('score');
        var title = r._assumed.indexOf(c.key) !== -1 ? ' title="Blank in file – assumed"' : '';
        return '<td class="' + cls.join(' ') + '"' + title + '>' + esc(fmt(v)) + '</td>';
      }).join('') + '</tr>';
    }).join('');
    $('table').innerHTML = '<thead>' + top + bottom + '</thead><tbody>' + body + '</tbody>';
  }
})();
