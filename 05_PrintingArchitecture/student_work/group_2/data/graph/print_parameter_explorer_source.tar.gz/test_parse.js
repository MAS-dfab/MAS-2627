const XLSX=require('xlsx'); const P=require('./src/parse.js');
const wb=XLSX.readFile(process.argv[2]); const out=P.parseWorkbook(wb,XLSX);
console.log(JSON.stringify({sheet:out.sheetName,n:out.rows.length,skipped:out.skipped,warnings:out.warnings,errors:out.errors,
 rows:out.rows.map(r=>{const o={};P.COLUMNS.forEach(c=>o[c.key]=r[c.key]);o.assumed=r._assumed;return o;})}));
