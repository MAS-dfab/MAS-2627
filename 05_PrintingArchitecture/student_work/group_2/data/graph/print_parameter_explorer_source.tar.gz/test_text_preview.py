"""Per-item text sizes (screen + export) and the live export preview."""
from playwright.sync_api import sync_playwright
import re
R=[]
def ok(n,c,i=''): R.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n+((' ['+str(i)+']') if i!='' else ''))
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1400,'height':1000}, accept_downloads=True); errs=[]
    pg.on('pageerror',lambda e: errs.append(str(e))); pg.on('console',lambda m: m.type=='error' and errs.append(m.text))
    pg.goto('file:///home/claude/build/dist/print_parameter_explorer.html'); pg.set_input_files('#file','/home/claude/data/week1.xlsx'); pg.wait_for_timeout(1500)
    W=lambda ms=400: pg.wait_for_timeout(ms); gd=lambda js: pg.evaluate("(()=>{const gd=document.getElementById('plot');return "+js+"})()")
    pv=lambda: pg.evaluate("window.LAST_PREVIEW||null")
    def setsize(k,v): pg.eval_on_selector(f'#textRow input[data-tkey="{k}"]',f'e=>{{e.value={v};e.dispatchEvent(new Event("input"));e.dispatchEvent(new Event("change"))}}'); W(250)
    def waitpv(prev):
        for _ in range(30):
            W(150); cur=pv()
            if cur and (not prev or cur['token']!=prev['token']): return cur
        return pv()
    # ---- preview present on load
    first=waitpv(None); ok('preview rendered on load (4K 16:9, black)', first and first['w']==3840 and first['h']==2160 and first['bg']=='black', first)
    ok('preview image decoded', pg.evaluate("document.getElementById('exPreviewImg').naturalWidth")>0)
    ok('preview box is 16:9', abs(pg.evaluate("(()=>{const r=document.getElementById('exPreview').getBoundingClientRect();return r.width/r.height})()")-16/9)<0.01)
    # ---- defaults
    ok('default sizes applied', gd("[gd.layout.xaxis.title.font.size,gd.layout.xaxis.tickfont.size,gd.layout.legend.font.size,gd.data.find(t=>t.textfont).textfont.size].join()")=='13,12,12,10')
    # ---- per item, per view
    for v in ['map2d','scatter','history']:
        pg.click(f'#viewSeg button[data-v={v}]'); W()
        if v=='history': pg.select_option('#ov1','temp'); pg.select_option('#ov2','lh'); pg.select_option('#topN','3'); W()
        prev=pv()
        setsize('axis',21); setsize('tick',17); setsize('legend',19); setsize('label',15)
        axes=gd("Object.keys(gd.layout).filter(k=>/^[xy]axis\\d*$/.test(k)).map(k=>[gd.layout[k].title.font.size,gd.layout[k].tickfont.size].join('/')).join(' ')")
        ok(f'{v}: every axis title 21 / ticks 17', all(a=='21/17' for a in axes.split()), axes)
        ok(f'{v}: legend 19', gd("gd.layout.legend.font.size")==19)
        ok(f'{v}: all point labels 15', gd("gd.data.filter(t=>t.textfont).every(t=>t.textfont.size===15)"))
        if v=='history': ok('history: rank labels 15', gd("gd.layout.annotations.filter(a=>a.name==='rank').every(a=>a.font.size===15)") and gd("gd.layout.annotations.filter(a=>a.name==='rank').length")==9)
        # rendered (computed) sizes in the SVG
        ok(f'{v}: rendered x title 21px', gd("getComputedStyle(gd.querySelector('.xtitle')).fontSize")=='21px')
        cur=waitpv(prev); ok(f'{v}: preview refreshed after text change', cur['token']!=prev['token'])
        pg.click('#resetText'); W(); ok(f'{v}: reset to default sizes', gd("gd.layout.xaxis.title.font.size")==13 and pg.eval_on_selector('#textRow input[data-tkey="axis"]','e=>e.value')=='13')
    # ---- export reflects sizes; preview == export
    setsize('axis',26); setsize('legend',22)
    pg.eval_on_selector('#exCapSize','e=>{e.value=18;e.dispatchEvent(new Event("input"))}')
    prev=pv(); pg.select_option('#exFormat','svg'); cur=waitpv(prev)
    with pg.expect_download() as d: pg.click('#exGo')
    d.value.save_as('exports4/tp.svg'); s=open('exports4/tp.svg').read()
    ok('exported SVG: axis title 26px, legend 22px, caption 18px', 'font-size: 26px' in s and 'font-size: 22px' in s and 'font-size: 18px' in s)
    ok('exported SVG identical to preview', len(s)==cur['svgLength'], (len(s),cur['svgLength']))
    ok('exported SVG text all Roboto', set(re.findall(r'font-family: ([^;"]+)', s))=={'Roboto, sans-serif'}, set(re.findall(r'font-family: ([^;"]+)', s)))
    # ---- preview follows export options
    prev=pv(); pg.select_option('#exSize','a4'); cur=waitpv(prev); ok('preview follows size (A4)', cur['w']==3508 and abs(pg.evaluate("(()=>{const r=document.getElementById('exPreview').getBoundingClientRect();return r.width/r.height})()")-3508/2480)<0.01)
    prev=pv(); pg.select_option('#exBg','transparent'); cur=waitpv(prev); ok('preview follows background (checkerboard)', cur['bg']=='transparent' and pg.evaluate("document.getElementById('exPreview').classList.contains('transp')"))
    prev=pv(); pg.uncheck('#exCaption'); cur=waitpv(prev); ok('preview follows caption toggle', cur['svgLength']<prev['svgLength'])
    prev=pv(); pg.click('#viewSeg button[data-v=scatter]'); cur=waitpv(prev); ok('preview follows view change', cur['token']!=prev['token'])
    pg.select_option('#exFormat','pdf'); W(500); ok('PDF note in preview info', 'PDF is converted from' in pg.inner_text('#exPreviewInfo'))
    with pg.expect_download() as d: pg.click('#exGo')
    d.value.save_as('exports4/tp.pdf'); ok('PDF export still works', open('exports4/tp.pdf','rb').read()[:4]==b'%PDF')
    ok('no browser errors', not errs, errs[:3]); b.close()
print('TOTAL',len(R),'PASSED',sum(r[1] for r in R),'FAILED',[r[0] for r in R if not r[1]])
