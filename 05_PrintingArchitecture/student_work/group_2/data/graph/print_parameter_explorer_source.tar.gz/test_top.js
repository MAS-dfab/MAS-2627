global.PrintSelect=require('./src/select.js'); global.PrintDelaunay=require('./src/delaunay.js');
const XLSX=require('xlsx'),P=require('./src/parse.js'),PL=require('./src/plots.js');
const rows=P.parseWorkbook(XLSX.readFile('../data/week1.xlsx'),XLSX).rows;
for (const by of ['clarity','stability','sum','min']) for (const n of [1,3,10]) {
  const t=PL.rankTop(rows,n,by); console.log(by.padEnd(9),'n='+String(n).padEnd(3),'->',t.length,'prints:',t.map(e=>'#'+e.rank+' S/N'+e.row.sn+'('+e.row.clarity+'/'+e.row.stability+')').join(' '));
}
