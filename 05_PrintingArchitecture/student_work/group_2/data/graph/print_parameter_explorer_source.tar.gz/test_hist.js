global.PrintSelect=require('./src/select.js'); global.PrintDelaunay=require('./src/delaunay.js');
const XLSX=require('xlsx'),P=require('./src/parse.js'),PL=require('./src/plots.js'),S=PrintSelect;
const rows=P.parseWorkbook(XLSX.readFile('../data/week1.xlsx'),XLSX).rows, info=S.paramInfo(rows);
const vary=info.filter(i=>i.varies).map(i=>i.key); let bad=0,n=0;
const combos=[[null,null]]; vary.forEach(a=>{combos.push([a,null]); vary.forEach(b=>{ if(b!==a) combos.push([a,b]); });});
combos.push(['temp','temp']); // duplicate must collapse to one
for(const ov of combos){ const f=PL.build({view:'history',allRows:rows,overlays:ov},info,{ramp:PL.RAMPS.blue,overrides:{}}); n++;
  const exp=[...new Set(ov.filter(Boolean))];
  if(JSON.stringify(f.overlays)!==JSON.stringify(exp)) {bad++; console.log('overlay list',ov,f.overlays);}
  f.data.forEach(t=>{ if(t.name==='Clarity'||t.name==='Stability'){const k=t.name.toLowerCase(); t.x.forEach((sn,i)=>{ if(rows.find(r=>r.sn===sn)[k]!==t.y[i]) bad++;}); } });
  f.overlays.forEach((k,i)=>{ const t=f.data[2+i]; t.x.forEach((sn,j)=>{const r=rows.find(r=>r.sn===sn); if((r[k]===null?null:r[k])!==t.y[j]) bad++;});
    if(t.yaxis!==(i?'y3':'y2')||!f.layout[i?'yaxis3':'yaxis2']) bad++; });
}
console.log('overlay combinations',n,'problems',bad);
