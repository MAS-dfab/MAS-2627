import json, sys, pandas as pd, numpy as np
js=json.load(open('/tmp/sel.json'))
df=pd.read_excel('/home/claude/data/week1.xlsx',sheet_name='Week 1 Parameter',header=None,skiprows=3,usecols='A:N',nrows=33)
df.columns=['sn','material','colour','lh','temp','e1','e2','v1','v2','a1','a2','t1','clarity','stability']
df['lh']=df.lh.mask(df.lh=='-',2); df=df.mask(df=='-'); df['sn']=df.sn.astype(int).astype(str)
params=['material','colour','lh','temp','e1','e2','v1','v2','a1','a2','t1']
lab=lambda s: s.map(lambda v:'NU' if pd.isna(v) else str(v))
varying=[p for p in params if lab(df[p]).nunique()>1]
def surf(pts):
    pts=np.unique(np.array(pts,float),axis=0)
    if len(pts)<3: return False
    rng=pts.max(0)-pts.min(0)
    if (rng==0).any(): return False
    n=(pts-pts.min(0))/rng
    return bool(np.linalg.matrix_rank(n-n[0],tol=1e-9)==2)
bad=0
for key,glist in js['pairs'].items():
    x,y=key.split('|'); y=y or None
    sub=df[df[x].notna() & (df[y].notna() if y else True)]
    const=[p for p in varying if p not in (x,y)]
    py={}
    for _,g in sub.groupby([lab(sub[c]) for c in const]):
        pos=g[[x]+([y] if y else [])].drop_duplicates()
        py[tuple(sorted(g.sn))]=(len(pos), g[x].nunique(), surf(g[[x,y]].values) if y else False)
    jsd={tuple(sorted(s)):(p,nx,sf) for s,p,nx,sf in glist}
    if py!=jsd: bad+=1; print('DIFF',key, sorted(py.items())[:3], sorted(jsd.items())[:3])
print('pairs compared',len(js['pairs']),'differences',bad)
