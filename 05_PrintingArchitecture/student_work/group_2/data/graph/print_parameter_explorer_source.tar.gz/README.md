# Print Parameter Explorer – source

Single-file offline tool: load a print-parameter .xlsx (fixed template) and plot settings against Clarity / Stability.
Views: 2D map, Clarity vs Stability, History (overlays whose axes fade with their lines, line types, top-n). Graph area and slide exports are 16:9.
Per-item text sizes (axis titles, ticks, legend, point labels, caption) apply to screen and export; live export preview; Roboto throughout.

## Build
    npm install xlsx@0.18.5 plotly.js-basic-dist-min jspdf svg2pdf.js @fontsource/roboto @expo-google-fonts/roboto
    python3 make_template.py template/print_parameter_template.xlsx
    python3 build.py                      # -> dist/print_parameter_explorer.html

## Source files (src/)
- parse.js     – template check, row parsing, blank rules (pure; also runs in Node)
- select.js    – parameter info, strict like-for-like grouping
- delaunay.js  – triangulation for connection edges
- plots.js     – figure builders for the three views, colours, opacity, line types, per-item text sizes, top-n ranking
- selectui.js  – view / axis / styling controls
- export.js    – PNG / SVG / PDF export, presets (16:9 HD & 4K, A4, A3), caption, live export preview
- app.js       – file loading and parsed-data table
- guide.html   – in-page user guide; index.html – page shell with build placeholders

## Tests (need week1.xlsx at ../data/ and Chrome for the browser tests)
- Node: test_parse.js, test_select.js (+ ref_groups.py), test_delaunay.js, test_labels.js, test_hist.js, test_top.js
- Browser (Playwright): test_all.py (55 checks), test_hist2.py (21), test_axisfade.py (11), test_text_preview.py (33), test_final_extra.py (6)
- audit_fonts.py – every visible text element on page and graphs must be Roboto; PDF text must use only Roboto
