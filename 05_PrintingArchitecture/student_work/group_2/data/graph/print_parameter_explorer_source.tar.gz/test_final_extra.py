from playwright.sync_api import sync_playwright
import openpyxl
R=[]
def ok(n,c,i=''): R.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n+((' ['+str(i)+']') if i!='' else ''))
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1400,'height':1000}, accept_downloads=True); errs=[]
    pg.on('pageerror',lambda e: errs.append(str(e))); pg.on('console',lambda m: m.type=='error' and errs.append(m.text))
    pg.goto('file:///home/claude/build/dist/print_parameter_explorer.html'); pg.wait_for_timeout(500)
    ok('guide collapsed on open', not pg.is_visible('.guide'))
    pg.click('#guide summary'); pg.wait_for_timeout(200); ok('guide opens', pg.is_visible('.guide'))
    with pg.expect_download() as d: pg.click('#dlTemplate')
    d.value.save_as('exports3/tpl.xlsx'); wb=openpyxl.load_workbook('exports3/tpl.xlsx')
    ok('template downloads & opens', wb.sheetnames==['Parameters','Instructions','Grading Metrics'], wb.sheetnames)
    pg.screenshot(path='s8_guide.png', full_page=True)
    pg.set_input_files('#file','exports3/tpl.xlsx'); pg.wait_for_timeout(500)
    ok('empty template gives clear message', 'no data rows' in pg.inner_text('#messages'))
    pg.set_input_files('#file','testfiles/template_filled.xlsx'); pg.wait_for_timeout(800)
    ok('filled template loads clean', 'No problems found' in pg.inner_text('#messages') and pg.evaluate("getSelection_().fig.rows.length")==33)
    ok('no browser errors', not errs, errs[:2]); b.close()
print('TOTAL',len(R),'PASSED',sum(r[1] for r in R))
