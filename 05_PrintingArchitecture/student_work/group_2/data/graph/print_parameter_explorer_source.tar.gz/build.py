"""Inline libraries and source into one self-contained HTML file."""
import pathlib, sys
root = pathlib.Path(__file__).parent
html = (root / 'src/index.html').read_text()
parts = {
    '/*__XLSX__*/': root / 'node_modules/xlsx/dist/xlsx.full.min.js',
    '/*__PARSE__*/': root / 'src/parse.js',
    '/*__PLOTLY__*/': root / 'node_modules/plotly.js-basic-dist-min/plotly-basic.min.js',
    '/*__SELECT__*/': root / 'src/select.js',
    '/*__DELAUNAY__*/': root / 'src/delaunay.js',
    '/*__PLOTS__*/': root / 'src/plots.js',
    '/*__APP__*/': root / 'src/app.js',
    '/*__SELUI__*/': root / 'src/selectui.js',
    '/*__JSPDF__*/': root / 'node_modules/jspdf/dist/jspdf.umd.min.js',
    '/*__SVG2PDF__*/': root / 'node_modules/svg2pdf.js/dist/svg2pdf.umd.min.js',
    '/*__EXPORT__*/': root / 'src/export.js',
}
for token, path in parts.items():
    assert token in html, token
    code = path.read_text()
    assert '</script' not in code.lower(), f'{path} contains </script'
    html = html.replace(token, code)
import base64
fonts = ''
for w in (400, 500, 700):
    f = root / f'node_modules/@fontsource/roboto/files/roboto-latin-{w}-normal.woff2'
    fonts += ("@font-face{font-family:Roboto;font-style:normal;font-weight:%d;font-display:block;"
              "src:url(data:font/woff2;base64,%s) format('woff2');}\n" % (w, base64.b64encode(f.read_bytes()).decode()))
fw = root / 'node_modules/@fontsource/roboto/files'
ft = root / 'node_modules/@expo-google-fonts/roboto'
b64 = lambda p: base64.b64encode(p.read_bytes()).decode()
fontjs = ('window.ROBOTO={woff2:{400:"%s",700:"%s"},ttf:{400:"%s",700:"%s"}};' % (
    b64(fw / 'roboto-latin-400-normal.woff2'), b64(fw / 'roboto-latin-700-normal.woff2'),
    b64(ft / '400Regular/Roboto_400Regular.ttf'), b64(ft / '700Bold/Roboto_700Bold.ttf')))
assert '/*__FONTJS__*/' in html
html = html.replace('/*__FONTJS__*/', fontjs)
guide = (root / 'src/guide.html').read_text()
assert '/*__GUIDE__*/' in html
html = html.replace('/*__GUIDE__*/', guide)
tpl = base64.b64encode((root / 'template/print_parameter_template.xlsx').read_bytes()).decode()
tpljs = ("(function(){var b='%s';document.getElementById('dlTemplate').onclick=function(){"
         "var s=atob(b),u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i);"
         "var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([u],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));"
         "a.download='print_parameter_template.xlsx';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1000);};})();" % tpl)
assert '/*__TEMPLATE__*/' in html
html = html.replace('/*__TEMPLATE__*/', tpljs)
assert '/*__FONTS__*/' in html
html = html.replace('/*__FONTS__*/', fonts)
out = root / (sys.argv[1] if len(sys.argv) > 1 else 'dist/print_parameter_explorer.html')
out.parent.mkdir(exist_ok=True)
out.write_text(html)
print(out, f'{out.stat().st_size/1e6:.2f} MB')
