"""Small z-buffer renderer (numba) for CadQuery shapes -> PNG views of the actual CAD geometry."""
import math
import numpy as np
from numba import njit
from PIL import Image, ImageDraw, ImageFont

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_B = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def font(sz, bold=False):
    try:
        return ImageFont.truetype(FONT_B if bold else FONT, sz)
    except Exception:
        return ImageFont.load_default()


def tess(shape, tol=0.25, ang=0.3):
    v, f = shape.val().tessellate(tol, ang) if hasattr(shape, "val") else shape.tessellate(tol, ang)
    V = np.array([[p.x, p.y, p.z] for p in v], dtype=np.float64)
    F = np.array(f, dtype=np.int64)
    return V, F


def feature_edges(V, F, crease=35.0):
    if len(F) == 0:
        return np.zeros((0, 2), np.int64)
    # weld vertices
    key = np.round(V / 0.01).astype(np.int64)
    _, inv = np.unique(key, axis=0, return_inverse=True)
    inv = inv.ravel()
    Fw = inv[F]
    n = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    nn = np.linalg.norm(n, axis=1, keepdims=True); nn[nn == 0] = 1
    n = n / nn
    e = np.concatenate([Fw[:, [0, 1]], Fw[:, [1, 2]], Fw[:, [2, 0]]])
    fi = np.concatenate([np.arange(len(F))] * 3)
    es = np.sort(e, axis=1)
    order = np.lexsort((es[:, 1], es[:, 0]))
    es, fi, e_orig = es[order], fi[order], e[order]
    out = []
    i = 0
    m = len(es)
    rep = {}
    # representative original vertex for welded index
    for a, b in zip(Fw.ravel(), F.ravel()):
        rep.setdefault(a, b)
    cos_t = math.cos(math.radians(crease))
    while i < m:
        j = i + 1
        while j < m and es[j, 0] == es[i, 0] and es[j, 1] == es[i, 1]:
            j += 1
        if j - i == 1:
            out.append((rep[es[i, 0]], rep[es[i, 1]]))
        else:
            d = np.dot(n[fi[i]], n[fi[i + 1]])
            if d < cos_t:
                out.append((rep[es[i, 0]], rep[es[i, 1]]))
        i = j
    return np.array(out, dtype=np.int64) if out else np.zeros((0, 2), np.int64)


@njit(cache=True)
def _raster(S, C, A, zb, img, W, H):
    for t in range(S.shape[0]):
        x0, y0, z0 = S[t, 0, 0], S[t, 0, 1], S[t, 0, 2]
        x1, y1, z1 = S[t, 1, 0], S[t, 1, 1], S[t, 1, 2]
        x2, y2, z2 = S[t, 2, 0], S[t, 2, 1], S[t, 2, 2]
        den = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
        if abs(den) < 1e-12:
            continue
        xmin = max(int(math.floor(min(x0, min(x1, x2)))), 0)
        xmax = min(int(math.ceil(max(x0, max(x1, x2)))), W - 1)
        ymin = max(int(math.floor(min(y0, min(y1, y2)))), 0)
        ymax = min(int(math.ceil(max(y0, max(y1, y2)))), H - 1)
        a = A[t]
        for py in range(ymin, ymax + 1):
            for px in range(xmin, xmax + 1):
                fx = px + 0.5
                fy = py + 0.5
                w0 = ((y1 - y2) * (fx - x2) + (x2 - x1) * (fy - y2)) / den
                w1 = ((y2 - y0) * (fx - x2) + (x0 - x2) * (fy - y2)) / den
                w2 = 1.0 - w0 - w1
                if w0 < -1e-6 or w1 < -1e-6 or w2 < -1e-6:
                    continue
                z = w0 * z0 + w1 * z1 + w2 * z2
                if a >= 0.999:
                    if z < zb[py, px]:
                        zb[py, px] = z
                        img[py, px, 0] = C[t, 0]
                        img[py, px, 1] = C[t, 1]
                        img[py, px, 2] = C[t, 2]
                else:
                    if z < zb[py, px]:
                        img[py, px, 0] = img[py, px, 0] * (1 - a) + C[t, 0] * a
                        img[py, px, 1] = img[py, px, 1] * (1 - a) + C[t, 1] * a
                        img[py, px, 2] = img[py, px, 2] * (1 - a) + C[t, 2] * a


@njit(cache=True)
def _lines(Ls, col, zb, img, W, H, th, bias):
    for k in range(Ls.shape[0]):
        x0, y0, z0 = Ls[k, 0], Ls[k, 1], Ls[k, 2]
        x1, y1, z1 = Ls[k, 3], Ls[k, 4], Ls[k, 5]
        n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
        for i in range(n + 1):
            t = i / n
            x = x0 + (x1 - x0) * t
            y = y0 + (y1 - y0) * t
            z = z0 + (z1 - z0) * t
            for dx in range(-th, th + 1):
                for dy in range(-th, th + 1):
                    px = int(x) + dx
                    py = int(y) + dy
                    if 0 <= px < W and 0 <= py < H:
                        if z <= zb[py, px] + bias:
                            img[py, px, 0] = col[0]
                            img[py, px, 1] = col[1]
                            img[py, px, 2] = col[2]


class Camera:
    def __init__(self, az=-35, el=25, persp=False, dist=900.0, target=(0, 0, 120), up=(0, 0, 1)):
        az, el = math.radians(az), math.radians(el)
        # view direction: from camera to target. az measured from -Y (front) toward +X
        d = np.array([math.sin(az) * math.cos(el), -math.cos(az) * math.cos(el), math.sin(el)])
        self.eye_dir = d / np.linalg.norm(d)        # points from target toward camera
        self.f = -self.eye_dir
        upv = np.array(up, float)
        r = np.cross(self.f, upv)
        if np.linalg.norm(r) < 1e-6:
            r = np.array([1.0, 0, 0])
        self.r = r / np.linalg.norm(r)
        self.u = np.cross(self.r, self.f)
        self.persp = persp
        self.dist = dist
        self.target = np.array(target, float)

    def project(self, P):
        rel = P - self.target
        x = rel @ self.r
        y = rel @ self.u
        z = -(rel @ self.f)  # larger = closer to camera
        depth = self.dist - z
        if self.persp:
            s = self.dist / np.maximum(depth, 1.0)
            return np.stack([x * s, y * s, depth], axis=-1)
        return np.stack([x, y, depth], axis=-1)


def render(items, cam, size=(1600, 1200), ss=2, bg=(247, 246, 243), light=(-0.45, -0.8, 0.9),
           edge_col=(45, 45, 48), edges=True, fit=None, margin=0.08, title=None, subtitle=None,
           labels=None, scale_bar=True, crease=35):
    """items: list of dict(V,F,color,alpha,edges(bool))"""
    W, H = size[0] * ss, size[1] * ss
    lv = np.array(light, float); lv /= np.linalg.norm(lv)
    allP = []
    proj = []
    for it in items:
        Pp = cam.project(it["V"])
        proj.append(Pp)
        if it.get("fit", True):
            allP.append(Pp[:, :2])
    if fit is None:
        A = np.concatenate(allP)
        mn, mx = A.min(0), A.max(0)
    else:
        mn, mx = np.array(fit[0]), np.array(fit[1])
    span = mx - mn
    s = min(W * (1 - 2 * margin) / max(span[0], 1e-6), H * (1 - 2 * margin) / max(span[1], 1e-6))
    off = np.array([W / 2, H / 2]) - s * (mn + mx) / 2
    zb = np.full((H, W), np.inf)
    img = np.empty((H, W, 3), np.float64); img[:] = bg
    order = sorted(range(len(items)), key=lambda i: items[i].get("alpha", 1.0) < 1.0)  # opaque first
    linesets = []
    for i in order:
        it = items[i]
        V, F = it["V"], it["F"]
        if len(F) == 0:
            continue
        Pp = proj[i]
        S = np.empty((len(F), 3, 3))
        sp = np.empty_like(Pp)
        sp[:, 0] = Pp[:, 0] * s + off[0]
        sp[:, 1] = H - (Pp[:, 1] * s + off[1])
        sp[:, 2] = Pp[:, 2]
        S[:] = sp[F]
        n = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
        nn = np.linalg.norm(n, axis=1, keepdims=True); nn[nn == 0] = 1; n /= nn
        # two-sided lighting
        facing = n @ cam.eye_dir
        n[facing < 0] *= -1
        lam = np.clip(n @ lv, 0, 1)
        rim = np.clip(n @ cam.eye_dir, 0, 1)
        k = 0.50 + 0.42 * lam + 0.10 * rim
        col = np.array(it["color"], float)[None, :] * k[:, None]
        col = np.clip(col, 0, 255)
        a = np.full(len(F), it.get("alpha", 1.0))
        _raster(S, col, a, zb, img, W, H)
        if edges and it.get("edges", True) and it.get("alpha", 1.0) >= 0.999 and len(F) < 60000:
            E = it.get("E")
            if E is None:
                E = feature_edges(V, F, crease)
            if len(E):
                Ls = np.concatenate([sp[E[:, 0]], sp[E[:, 1]]], axis=1)
                linesets.append((Ls, it.get("edge_col", edge_col)))
    bias = 0.6
    for Ls, ec in linesets:
        _lines(Ls.astype(np.float64), np.array(ec, float), zb, img, W, H, max(1, ss // 2), bias)
    im = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)).resize(size, Image.LANCZOS)
    d = ImageDraw.Draw(im)
    if labels:
        for (pt3, text) in labels:
            q = cam.project(np.array([pt3]))[0]
            x = (q[0] * s + off[0]) / ss
            y = (H - (q[1] * s + off[1])) / ss
            d.ellipse([x - 3, y - 3, x + 3, y + 3], fill=(200, 60, 50))
            d.text((x + 6, y - 9), text, fill=(30, 30, 30), font=font(15))
    if title:
        d.text((28, 22), title, fill=(25, 25, 25), font=font(26, True))
    if subtitle:
        d.text((28, 58), subtitle, fill=(90, 90, 90), font=font(16))
    if scale_bar and not cam.persp:
        px100 = 100 * s / ss
        x0, y0 = 30, size[1] - 40
        d.line([x0, y0, x0 + px100, y0], fill=(30, 30, 30), width=3)
        for xx in (x0, x0 + px100 / 2, x0 + px100):
            d.line([xx, y0 - 6, xx, y0 + 6], fill=(30, 30, 30), width=2)
        d.text((x0, y0 - 28), "100 mm", fill=(30, 30, 30), font=font(15))
    return im, (s, off, ss, H)


def screen_xy(cam, meta, p):
    s, off, ss, H = meta
    q = cam.project(np.array([p]))[0]
    return ((q[0] * s + off[0]) / ss, (H - (q[1] * s + off[1])) / ss)
