"""
Interactive Chocolate Dispenser - parametric CAD model
MAS ETH DFAB - Daniel

Geometry kernel: CadQuery / OpenCascade (exact B-rep solids -> STEP opens in Rhino
as closed NURBS polysurfaces).

Units: millimetres. Coordinate system:
    X = width, Y = depth, Z = height
    front interface faces -Y
    origin = bottom centre of the main enclosure (underside of the lower module)

All major dimensions live in the CONFIG section. Every value marked (VERIFY) is a
preliminary reference value that must be replaced by a physical measurement.

Run:  python chocolate_dispenser.py           -> builds model, validates, exports
"""
from __future__ import annotations
import math
from dataclasses import dataclass, field
import cadquery as cq

# =============================================================================
# CONFIG
# =============================================================================
P = dict(
    # ---- fabrication (Bambu Lab A1, 0.4 nozzle) -------------------------------
    BUILD=(256.0, 256.0, 256.0),   # printer build volume (VERIFY)
    WALL=2.4,                      # main enclosure wall
    FLOOR=2.4,                     # lower module floor
    ROOF=2.4,                      # upper column roof
    BACK_T=3.2,                    # rear maintenance cover (structural, carries cleat)
    PANEL_T=4.4,                   # front interface panel total thickness
    PANEL_FLANGE=2.0,              # part of PANEL_T that sits behind the frame
    PART_T=2.0,                    # internal partition wall
    CLR=0.4,                       # general assembly clearance per side
    CLR_ROT=0.6,                   # clearance around rotating parts
    EDGE_R_FRONT=6.0,              # vertical front edges radius
    EDGE_R_BACK=1.5,               # vertical rear edges radius
    TOP_R=3.0,                     # roof / floor edge radius

    # ---- chocolate (VERIFY with the actual chocolate) ------------------------
    CH_W=30.0, CH_D=30.0, CH_T=15.0,   # wrapped chocolate envelope
    CH_CLR=1.5,                        # clearance per side in magazine / pocket
    CH_MASS_G=10.0,                    # per piece, for torque estimate
    N_CAP=11,                          # total capacity (1 in pocket + rest in tube)
    MAG_HEADROOM=17.0,
    MAG_WALL=2.0,
    MAG_SLOT_W=6.0,                    # sight slot in tube + enclosure

    # ---- rotary drum dispenser -----------------------------------------------
    DRUM_R=27.0,
    DRUM_END_T=2.5,
    POCKET_TOP_OFFSET=0.0,     # chocolate top relative to drum crest (0 = flush)
    POCKET_FILLET=3.0,
    TRANSPORT_R=32.0,          # shell radius in transport arc (passes chocolate corners)
    SHELL_T=3.0,
    HOUSING_WALL_L=4.0,        # left cheek (holds axle bushing)
    HOUSING_WALL_R=5.0,        # right frame (drum passes through, bracket bolts on)
    AXLE_D=10.0, AXLE_L=4.5, AXLE_BORE=4.4,
    HOUSING_BACK=31.2,         # housing extent behind drum axis (clears rear-cover bosses)   # printed axle stub + horn-screw access bore
    ANGLE_REST=0.0, ANGLE_MID=65.0, ANGLE_DISPENSE=130.0,   # physical drum angles (deg)
    MAG_OPEN_ANG=32.0,         # half-angle of magazine opening seen from axis
    WINDOW_START=85.0, WINDOW_END=168.0,     # release window (deg from top, toward front)
    ADAPTER_D=30.0,
    Z_DRUM=56.0,               # drum axis height (checked against ramp + servo)
    Z_SPLIT=80.0,              # seam between lower module and upper column

    # ---- servo DM996 (VERIFY) -------------------------------------------------
    SV_L=40.7, SV_W=19.7, SV_CASE_H=37.0, SV_TOTAL_H=42.9,
    SV_FLANGE_FROM_BOTTOM=26.5, SV_FLANGE_T=2.5, SV_FLANGE_L=54.0,
    SV_HOLE_L=48.0, SV_HOLE_W=10.0, SV_HOLE_D=4.4,
    SV_SHAFT_OFFSET=10.15,     # shaft axis offset from body centre along SV_L
    HORN_R=20.0, HORN_ARM_W=6.0, HORN_T=2.5, HORN_HUB_D=9.0, HORN_HUB_H=6.0,
    HORN_HOLE_R=15.0,          # radius of the horn hole used for M2 screws
    SV_STALL_TORQUE_NM=0.92,   # ~9.4 kg.cm @4.8 V datasheet class value (VERIFY)

    # ---- electronics (VERIFY) -------------------------------------------------
    BB_W=55.0, BB_L=160.0, BB_H=9.0, BB_WIRE=30.0,
    NANO_W=18.0, NANO_L=45.0, NANO_STACK=13.0,
    LCD_PCB_W=80.0, LCD_PCB_H=36.0, LCD_PCB_T=1.6,
    LCD_BEZEL_W=71.2, LCD_BEZEL_H=24.2, LCD_BEZEL_T=7.0,
    LCD_VIEW_W=64.5, LCD_VIEW_H=16.0, LCD_HOLE_SX=75.0, LCD_HOLE_SY=31.0,
    BP_W=42.0, BP_H=19.0, BP_T=15.0, LCD_CONN_CLR=10.0,
    PIR_PCB_W=32.0, PIR_PCB_H=24.0, PIR_LENS_D=23.0, PIR_LENS_H=12.5,
    PIR_BACK=11.0, PIR_HOLE_SPAN=28.0, PIR_SPACER=2.0,
    IR_L=44.5, IR_H=18.9, IR_D=13.5, IR_HOLE_SPAN=37.0,
    IR_LENS_SPACING=20.0, IR_LENS_D=8.0, IR_CONN=8.0,
    NEO_W=10.2, NEO_H=12.7, NEO_T=2.5,
    DIFF_D=16.0, DIFF_FLANGE_D=20.0, LED_CHAMBER=12.0,

    # ---- front interface layout (offsets below roof top) ----------------------
    LCD_DZ=42.0, LED_DZ=80.0, PIR_DZ=112.0, IR_DZ=146.0,

    # ---- collection tray ------------------------------------------------------
    Z_OUTLET=6.0, OUTLET_H=22.0, OUTLET_W=36.0, RAMP_ANG=30.0,
    TRAY_D=58.0, TRAY_LIP=12.0, TRAY_FLANGE=35.0, TRAY_FLANGE_T=3.0,

    # ---- shelving upright (VERIFY - measure the profile!) ---------------------
    UP_W=40.0, UP_T=2.0, UP_SIDE=40.0,
    UP_HOLE_W=6.0, UP_HOLE_H=11.0, UP_HOLE_PITCH=25.0, UP_HOLE_X=10.0,
    MOUNT_X=0.0,               # bracket centre relative to enclosure centre
    MOUNT_Z=170.0,             # cleat line height on the enclosure
    CLEAT_D=8.0, CLEAT_H=20.0, BRACKET_T=5.0, BRACKET_W=54.0, BRACKET_H=150.0,

    # ---- fasteners -----------------------------------------------------------
    DC_X_FROM_RIGHT=28.0, REAR_BOSS_W=5.5, REAR_BOSS_D=6.0,
    M3_CLEAR=3.4, M3_INSERT=4.0, M2_PILOT=1.6, M25_PILOT=2.1, M4_CLEAR=4.5,
)


# =============================================================================
# DERIVED LAYOUT
# =============================================================================
def layout(p=P):
    L = {}
    L["mag_in"] = p["CH_W"] + 2 * p["CH_CLR"]                # 33
    L["mag_out"] = L["mag_in"] + 2 * p["MAG_WALL"]           # 37
    L["DL"] = p["CH_D"] + 2 * p["CH_CLR"] + 2 * p["DRUM_END_T"]   # drum length 38
    L["adapter_t"] = p["CLR_ROT"] + p["HOUSING_WALL_R"] + 5.0    # passes frame + bearing plate
    L["elec_in"] = p["LCD_PCB_W"] + p["LCD_CONN_CLR"] + 4.0
    W = (2 * p["WALL"] + p["CLR"] + p["HOUSING_WALL_L"] + p["CLR_ROT"] + L["DL"]
         + p["CLR_ROT"] + p["HOUSING_WALL_R"] + p["CLR"] + p["PART_T"] + L["elec_in"])
    W = math.ceil(W)
    L["W"] = W
    L["xL"] = -W / 2 + p["WALL"]                  # inner left face
    L["xR"] = W / 2 - p["WALL"]                   # inner right face
    L["xm"] = L["xL"] + p["CLR"] + p["HOUSING_WALL_L"] + p["CLR_ROT"] + L["DL"] / 2
    L["x_frameR0"] = L["xm"] + L["DL"] / 2 + p["CLR_ROT"]
    L["x_frameR1"] = L["x_frameR0"] + p["HOUSING_WALL_R"]
    L["x_p"] = L["x_frameR1"] + p["CLR"]          # column partition wall start
    L["x_e0"] = L["x_p"] + p["PART_T"]            # electronics column inner left
    # depth
    front_stack = p["LCD_BEZEL_T"] + p["LCD_PCB_T"] + p["BP_T"]
    rear_stack = 0.5 + 2.4 + p["BB_H"] + p["BB_WIRE"]
    D_in = (p["PANEL_T"] - p["PANEL_FLANGE"]) + front_stack + rear_stack + 8.0
    D_in = max(D_in, 2 * (p["TRANSPORT_R"] + p["SHELL_T"]) + 2 * p["CLR"])
    D = math.ceil(D_in + p["WALL"] + p["BACK_T"])
    L["D"] = D
    L["yF"] = -D / 2                              # front outer face
    L["yFi"] = -D / 2 + p["WALL"]                 # front inner face
    L["yB"] = D / 2 - p["BACK_T"]                 # rear face of shells / inner face of cover
    L["yc"] = 0.0                                 # drum / magazine axis Y
    L["zd"] = p["Z_DRUM"]
    L["z_crest"] = L["zd"] + p["DRUM_R"]
    L["z_pocket_floor"] = L["zd"] + p["DRUM_R"] - p["CH_T"] - p["POCKET_TOP_OFFSET"]
    L["z_house_top"] = L["zd"] + p["TRANSPORT_R"] + p["SHELL_T"]
    L["z_base"] = p["FLOOR"] + 4.0                # top of floor bosses
    L["Z_rt"] = L["z_crest"] + (p["N_CAP"] - 1) * p["CH_T"] + p["MAG_HEADROOM"]
    L["H"] = L["Z_rt"]
    # servo (shaft along -X, coaxial with drum)
    L["x_horn0"] = L["xm"] + L["DL"] / 2 + L["adapter_t"]
    L["x_ct"] = L["x_horn0"] + p["HORN_T"] + p["HORN_HUB_H"]      # servo case top face
    L["x_sv_bot"] = L["x_ct"] + p["SV_CASE_H"]
    L["x_fl0"] = L["x_sv_bot"] - p["SV_FLANGE_FROM_BOTTOM"] - p["SV_FLANGE_T"]
    L["x_fl1"] = L["x_fl0"] + p["SV_FLANGE_T"]
    L["z_sv_c"] = L["zd"] - p["SV_SHAFT_OFFSET"]                    # servo body centre Z
    L["x_bp0"] = L["x_frameR1"]; L["x_bp1"] = L["x_frameR1"] + 5.0   # bearing plate
    L["x_mp0"] = L["x_fl0"] - 4.0; L["x_mp1"] = L["x_fl0"]           # servo mount plate
    # front interface
    L["x_op0"] = L["x_e0"] + 3.0
    L["x_op1"] = L["xR"] - 3.0
    L["x_lcd"] = L["x_e0"] + 2.0 + p["LCD_PCB_W"] / 2               # front element axis
    L["z_lcd"] = L["Z_rt"] - p["LCD_DZ"]
    L["z_led"] = L["Z_rt"] - p["LED_DZ"]
    L["z_pir"] = L["Z_rt"] - p["PIR_DZ"]
    L["z_ir"] = L["Z_rt"] - p["IR_DZ"]
    L["y_pf"] = L["yF"] + p["PANEL_T"]            # panel back face
    # breadboard on rear cover
    L["x_bb0"] = L["xR"] - 10.0 - p["BB_W"] - 9.0   # leaves room for T-slot rails + corner bosses
    L["y_tray1"] = L["yB"] - 0.5
    L["y_tray0"] = L["y_tray1"] - 2.4
    L["y_bb0"] = L["y_tray0"] - p["BB_H"]
    L["z_bb0"] = p["Z_SPLIT"] + 2.4 + 1.6
    # tray / ramp
    L["tan_r"] = math.tan(math.radians(p["RAMP_ANG"]))
    return L


L = layout()


# =============================================================================
# GEOMETRY HELPERS
# =============================================================================
def bx(x0, x1, y0, y1, z0, z1):
    return (cq.Workplane("XY").box(x1 - x0, y1 - y0, z1 - z0, centered=False)
            .translate((x0, y0, z0)))


def cyl(r, h, pnt, d):
    return cq.Workplane("XY").add(cq.Solid.makeCylinder(r, h, cq.Vector(*pnt), cq.Vector(*d)))


def cylX(x0, x1, y, z, r):
    return cyl(r, x1 - x0, (x0, y, z), (1, 0, 0))


def cylY(y0, y1, x, z, r):
    return cyl(r, y1 - y0, (x, y0, z), (0, 1, 0))


def cylZ(z0, z1, x, y, r):
    return cyl(r, z1 - z0, (x, y, z0), (0, 0, 1))


def polar(a_deg, r, yc=None, zc=None):
    """drum polar coords: angle from +Z toward -Y (front)."""
    yc = L["yc"] if yc is None else yc
    zc = L["zd"] if zc is None else zc
    a = math.radians(a_deg)
    return (yc - r * math.sin(a), zc + r * math.cos(a))


def wedgeX(x0, x1, a0, a1, rbig=80.0, step=3.0):
    n = max(2, int(abs(a1 - a0) / step) + 1)
    pts = [polar(0, 0)]
    for i in range(n + 1):
        pts.append(polar(a0 + (a1 - a0) * i / n, rbig))
    return cq.Workplane("YZ").polyline(pts).close().extrude(x1 - x0).translate((x0, 0, 0))


def sectorX(x0, x1, a0, a1, r0, r1):
    ring = cylX(x0, x1, L["yc"], L["zd"], r1).cut(cylX(x0 - 1, x1 + 1, L["yc"], L["zd"], r0))
    return ring.intersect(wedgeX(x0 - 1, x1 + 1, a0, a1))


def try_fillet(wp, sel, r):
    try:
        out = wp.edges(sel).fillet(r)
        if out.val().isValid():
            return out
    except Exception:
        pass
    return wp


def rot_about_drum_axis(wp, ang_deg):
    """rotate toward the front (-Y) by ang_deg about the drum axis (X axis)."""
    # positive rotation about +X turns +Z toward -Y? (y,z)->(y cos - z sin, y sin + z cos):
    # +Z (0,1) -> (-sin, cos): toward -Y for positive angle. Correct.
    return wp.rotate((0, L["yc"], L["zd"]), (1, L["yc"], L["zd"]), ang_deg)


# =============================================================================
# PART REGISTRY
# =============================================================================
@dataclass
class Part:
    name: str
    layer: str
    shape: cq.Workplane
    printable: bool = False
    material: str = ""
    color: tuple = (200, 200, 200)
    explode: tuple = (0, 0, 0)
    print_rot: tuple = ()          # list of (axis, deg) to bring into print orientation
    supports: str = "none"
    qty: int = 1
    note: str = ""


PARTS: list[Part] = []


def add(**kw):
    PARTS.append(Part(**kw))
    return PARTS[-1]


C_SHELL = (236, 234, 228)   # warm white
C_DARK = (62, 64, 68)       # graphite
C_MECH = (190, 192, 196)
C_ACC = (214, 72, 58)       # signal red accents
C_TRANS = (250, 230, 225)
C_REF = (40, 120, 170)
C_PCB = (30, 110, 70)
C_CHOC = (120, 72, 40)


# =============================================================================
# PRINTABLE PARTS
# =============================================================================
def make_lower_module():
    W, D = L["W"], L["D"]
    zs = P["Z_SPLIT"]
    outer = bx(-W / 2, W / 2, L["yF"], L["yB"], 0, zs)
    outer = try_fillet(outer, "|Z and <Y", P["EDGE_R_FRONT"])
    outer = try_fillet(outer, "<Z and (not >Y)", P["TOP_R"])
    outer = try_fillet(outer, "|Z and >Y", P["EDGE_R_BACK"])
    inner = bx(L["xL"], L["xR"], L["yFi"], L["yB"] + 5, P["FLOOR"], zs + 5)
    s = outer.cut(inner)
    # outlet
    s = s.cut(bx(L["xm"] - P["OUTLET_W"] / 2, L["xm"] + P["OUTLET_W"] / 2,
                 L["yF"] - 1, L["yFi"] + 1, P["Z_OUTLET"] - 2.4 - 0.3, P["Z_OUTLET"] + P["OUTLET_H"]))
    # floor bosses (heat-set inserts)
    for (x, y) in boss_points_floor():
        s = s.union(cylZ(P["FLOOR"] - 0.01, L["z_base"], x, y, 4.0))
        s = s.cut(cylZ(P["FLOOR"] - 0.01, L["z_base"] + 0.1, x, y, P["M3_INSERT"] / 2))
    # electronics floor posts
    for (x, y) in post_points():
        s = s.union(cylZ(P["FLOOR"] - 0.01, zs, x, y, 3.5))
        s = s.cut(cylZ(zs - 6, zs + 0.1, x, y, P["M3_INSERT"] / 2))
    # tray screw bosses (inserts from below)
    for x in tray_screw_x():
        y = L["yF"] + 20
        s = s.union(cylZ(P["FLOOR"] - 0.01, P["FLOOR"] + 4, x, y, 4.0))
        s = s.cut(cylZ(-0.1, P["FLOOR"] + 4.1, x, y, P["M3_INSERT"] / 2))
    # rear-cover bosses
    for (x, z) in rear_boss_points(lower=True):
        s = s.union(rear_boss(x, z))
        s = s.cut(cylY(L["yB"] - 5.5, L["yB"] + 0.1, x, z, P["M3_INSERT"] / 2))
    return s


def boss_points_floor():
    xm, yc = L["xm"], L["yc"]
    return [
        (xm - 21.6, yc + 25.5),                     # housing back-left pad
        (L["x_frameR0"] + 2.5, yc + 25.5),          # housing back-right pad
        ((L["x_bp0"] + L["x_mp1"]) / 2, yc - 20.0), # bracket foot
        ((L["x_bp0"] + L["x_mp1"]) / 2, yc + 20.0),
    ]


def post_points():
    x0 = L["x_bp1"] + 4.5
    return [(x0, L["yFi"] + 4.6), (L["xR"] - 7.0, L["yFi"] + 4.6),
            (L["xR"] - 7.0, L["yB"] - 10.5), (x0, L["yB"] - 4.5)]


def tray_screw_x():
    return [0.0, L["W"] / 2 - 20]          # clear of the chute footprint


def rear_boss_points(lower):
    W = L["W"]
    if lower:
        zs = [12.0, P["Z_SPLIT"] - 12.0]
    else:
        zs = [P["Z_SPLIT"] + 14.0, L["Z_rt"] - 14.0]
    pts = []
    for z in zs:
        pts += [(-W / 2 + 5.4, z), (W / 2 - 5.4, z)]
    return pts


def rear_boss(x, z):
    side = -1 if x < 0 else 1
    xw = L["xL"] if side < 0 else L["xR"]
    x0, x1 = sorted([xw + side * 0.01, xw - side * P["REAR_BOSS_W"]])
    return bx(x0, x1, L["yB"] - P["REAR_BOSS_D"], L["yB"], z - 5, z + 5)


def make_upper_column():
    W = L["W"]
    zs, zt = P["Z_SPLIT"], L["Z_rt"]
    outer = bx(-W / 2, W / 2, L["yF"], L["yB"], zs, zt)
    outer = try_fillet(outer, "|Z and <Y", P["EDGE_R_FRONT"])
    outer = try_fillet(outer, ">Z and (not >Y)", P["TOP_R"])
    outer = try_fillet(outer, "|Z and >Y", P["EDGE_R_BACK"])
    s = outer.cut(bx(L["xL"], L["xR"], L["yFi"], L["yB"] + 5, zs - 5, zt - P["ROOF"]))
    # front interface opening (open to bottom seam)
    s = s.cut(bx(L["x_op0"], L["x_op1"], L["yF"] - 1, L["yFi"] + 0.5, zs - 1, zt - 8.0))
    # sight slot on magazine
    s = s.cut(bx(L["xm"] - P["MAG_SLOT_W"] / 2, L["xm"] + P["MAG_SLOT_W"] / 2,
                 L["yF"] - 1, L["yFi"] + 0.5, L["z_house_top"] + 14, zt - 18))
    # column partition (sits on the electronics floor plate)
    s = s.union(bx(L["x_p"], L["x_e0"], L["yFi"] - 0.01, L["yB"], zs + 2.4, zt - P["ROOF"] + 0.01)
                .cut(bx(L["x_p"] - 1, L["x_e0"] + 1, L["yB"] - 14, L["yB"] + 1, zs + 2.4, zs + 16)))
    # magazine through-hole + flange recess in roof
    a = L["mag_out"] / 2 + P["CLR"]
    s = s.cut(bx(L["xm"] - a, L["xm"] + a, L["yc"] - a, L["yc"] + a, zt - 10, zt + 1))
    f = 22.5 + P["CLR"]
    s = s.cut(bx(L["xm"] - f, L["xm"] + f, L["yc"] - f, L["yc"] + f, zt - 2.0, zt + 1))
    # alignment skirt into lower module (left, right, magazine front)
    t, c = 2.0, P["CLR"]
    xl0 = L["xL"] + c
    xr1 = L["xR"] - c
    yf0 = L["yFi"] + c
    sk = bx(xr1 - t, xr1, yf0, L["yB"] - 10, zs - 6, zs + 2.0)   # (left side is occupied by the drum housing)
    sk = sk.union(bx(xr1 - t, L["xR"] + 0.01, yf0, L["yB"] - 10, zs - 0.01, zs + 2.0))      # bridge to wall
    sk = sk.union(bx(xl0, L["x_p"], yf0, yf0 + t, zs - 6, zs + 2.0))
    sk = sk.union(bx(xl0, L["x_p"], L["yFi"] - 0.01, yf0 + t, zs - 0.01, zs + 2.0))
    s = s.union(sk)
    # roof bosses for the front-panel top tab
    for x in panel_tab_x():
        s = s.union(cylZ(zt - P["ROOF"] - 5, zt - P["ROOF"] + 0.01, x, L["y_pf"] + 4.0, 4.0))
        s = s.cut(cylZ(zt - P["ROOF"] - 5.1, zt - P["ROOF"] - 0.6, x, L["y_pf"] + 4.0, P["M3_INSERT"] / 2))
    # rear cover bosses
    for (x, z) in rear_boss_points(lower=False):
        s = s.union(rear_boss(x, z))
        s = s.cut(cylY(L["yB"] - 8, L["yB"] + 0.1, x, z, P["M3_INSERT"] / 2))
    return s


def panel_tab_x():
    return [L["x_e0"] + 8.0, L["xR"] - 8.0]


def make_front_panel():
    zs, zt = P["Z_SPLIT"], L["Z_rt"]
    c = 0.3
    yF, yp = L["yF"], L["y_pf"]
    yfl = yF + (P["PANEL_T"] - P["PANEL_FLANGE"])         # flange front face
    face = bx(L["x_op0"] + c, L["x_op1"] - c, yF, yp, zs + c, zt - 8.0 - c)
    face = try_fillet(face, "|Y", 1.0)
    fl = bx(L["x_e0"] + c, L["xR"] - c, yfl, yp, zs - 4.0, zt - P["ROOF"] - 5.3)
    fl = fl.cut(bx(L["x_e0"] - 1, L["xR"] + 1, yfl - 1, yp + 1, zs - 5, zs + 2.4 + c))  # floor plate
    s = face.union(fl)
    s = s.union(bx(L["x_e0"] + c, L["xR"] - c, yfl, yp, zs - 4.0, zs + 0.01)  # hook tongue
                .intersect(bx(L["x_op0"] + 9, L["x_op1"] - 6, yfl, yp, zs - 4.0, zs + 0.01)))
    # top tab with 2 vertical screw holes
    ztab = zt - P["ROOF"] - 5.0
    tab = bx(L["x_e0"] + c, L["xR"] - c, yp - 0.01, yp + 8.0, ztab - 3.0, ztab)
    s = s.union(tab)
    for x in panel_tab_x():
        s = s.cut(cylZ(ztab - 4, ztab + 1, x, yp + 4.0, P["M3_CLEAR"] / 2))
    xa = L["x_lcd"]
    # LCD window with 45deg chamfer to the front
    vw, vh = P["LCD_VIEW_W"] + 1.0, P["LCD_VIEW_H"] + 1.0
    win = (cq.Workplane("XZ", origin=(0, yp + 0.01, 0))
           .center(xa, L["z_lcd"]).rect(vw, vh)
           .workplane(offset=P["PANEL_T"] + 0.02).rect(vw + 2 * P["PANEL_T"], vh + 2 * P["PANEL_T"])
           .loft())
    s = s.cut(win)
    # LCD posts
    for sx in (-1, 1):
        for sz in (-1, 1):
            x = xa + sx * P["LCD_HOLE_SX"] / 2
            z = L["z_lcd"] + sz * P["LCD_HOLE_SY"] / 2
            s = s.union(cylY(yp - 0.01, yp + P["LCD_BEZEL_T"], x, z, 2.6))
            s = s.cut(cylY(yp + 1, yp + P["LCD_BEZEL_T"] + 0.1, x, z, P["M25_PILOT"] / 2))
    # NeoPixel light chamber + diffuser seat
    zl = L["z_led"]
    s = s.cut(cylY(yF - 1, yp + 1, xa, zl, P["DIFF_D"] / 2 + 0.2))
    s = s.union(cylY(yp - 0.01, yp + P["LED_CHAMBER"], xa, zl, P["DIFF_FLANGE_D"] / 2 + 2.4)
                .cut(cylY(yp - 1, yp + P["LED_CHAMBER"] + 1, xa, zl, P["DIFF_FLANGE_D"] / 2 + 0.2)))
    s = s.union(bx(xa - 9, xa + 9, yp + P["LED_CHAMBER"] - 0.01, yp + P["LED_CHAMBER"] + 4.0, zl - 9, zl + 9)
                .cut(bx(xa - P["NEO_W"] / 2 - 0.3, xa + P["NEO_W"] / 2 + 0.3,
                        yp + P["LED_CHAMBER"] - 0.1, yp + P["LED_CHAMBER"] + P["NEO_T"] + 0.4,
                        zl - P["NEO_H"] / 2 - 0.3, zl + 9.5))          # slide-in slot from top
                .cut(cylY(yp + P["LED_CHAMBER"], yp + P["LED_CHAMBER"] + 5, xa, zl - 3, 2.5)))  # wire exit
    # PIR lens opening + posts
    zp = L["z_pir"]
    s = s.cut(cylY(yF - 1, yp + 1, xa, zp, P["PIR_LENS_D"] / 2 + 0.4))
    s = s.cut(cylY(yF - 1, yF + 1.0, xa, zp, P["PIR_LENS_D"] / 2 + 1.4).intersect(
        cq.Workplane("XZ", origin=(0, yF + 1.0, 0)).center(xa, zp).circle(P["PIR_LENS_D"] / 2 + 0.4)
        .workplane(offset=1.02).circle(P["PIR_LENS_D"] / 2 + 1.4).loft()))
    for sx in (-1, 1):
        x = xa + sx * P["PIR_HOLE_SPAN"] / 2
        s = s.union(cylY(yp - 0.01, yp + P["PIR_SPACER"], x, zp, 2.6))
        s = s.cut(cylY(yp - 0.5, yp + P["PIR_SPACER"] + 0.1, x, zp, P["M2_PILOT"] / 2))
    # IR distance sensor window (both optics) with 45deg flare + posts
    zi = L["z_ir"]
    ww, wh = P["IR_LENS_SPACING"] + P["IR_LENS_D"] + 4.0, P["IR_LENS_D"] + 3.0
    irw = (cq.Workplane("XZ", origin=(0, yp + 0.01, 0)).center(xa, zi).rect(ww, wh)
           .workplane(offset=P["PANEL_T"] + 0.02).rect(ww + 2 * P["PANEL_T"], wh + 2 * P["PANEL_T"]).loft())
    s = s.cut(irw)
    for sx in (-1, 1):
        x = xa + sx * P["IR_HOLE_SPAN"] / 2
        s = s.union(cylY(yp - 0.01, yp + P["IR_D"] - 2.0, x, zi, 3.0))
        s = s.cut(cylY(yp + 2, yp + P["IR_D"] - 1.9, x, zi, P["M3_INSERT"] / 2))
    return s


def make_electronics_floor():
    zs = P["Z_SPLIT"]
    c = 0.3
    s = bx(L["x_e0"] + c, L["xR"] - 2.4 - 0.4 - c, L["y_pf"] + c, L["yB"] - c, zs, zs + 2.4)   # clears the skirt bridge
    for (x, y) in post_points():
        s = s.cut(cylZ(zs - 1, zs + 3, x, y, P["M3_CLEAR"] / 2))
        s = s.cut(cylZ(zs + 1.0, zs + 3, x, y, 3.2))        # counterbore
    # servo cable pass-through and DC cable pass-through
    s = s.cut(bx(L["x_sv_bot"] - 14, L["x_sv_bot"] - 2, L["yc"] + 14, L["yc"] + 26, zs - 1, zs + 3)
              .edges("|Z").fillet(3))
    s = s.cut(bx(L["xR"] - 16, L["xR"] - 6, L["yB"] - 16, L["yB"] - 6, zs - 1, zs + 3)
              .edges("|Z").fillet(3))
    # ventilation slots
    for i in range(5):
        x = L["x_e0"] + 18 + i * 9
        s = s.cut(bx(x, x + 4, L["yFi"] + 10, L["yFi"] + 40, zs - 1, zs + 3).edges("|Z").fillet(1.9))
    return s


def make_magazine():
    zt = L["Z_rt"]
    z0 = L["z_house_top"] - 6.0
    xm, yc = L["xm"], L["yc"]
    a, b = L["mag_out"] / 2, L["mag_in"] / 2
    s = bx(xm - a, xm + a, yc - a, yc + a, z0, zt - 2.0)
    s = try_fillet(s, "|Z", 2.0)
    s = s.union(bx(xm - 22.5, xm + 22.5, yc - 22.5, yc + 22.5, zt - 2.0, zt).edges("|Z").fillet(4))
    s = s.cut(bx(xm - b, xm + b, yc - b, yc + b, z0 - 1, zt + 1).edges("|Z").fillet(1.0))
    s = s.cut(bx(xm - P["MAG_SLOT_W"] / 2, xm + P["MAG_SLOT_W"] / 2, yc - a - 1, yc - b + 0.5,
                 L["z_house_top"] + 14, zt - 18).edges("|Y").fillet(P["MAG_SLOT_W"] / 2 - 0.1))
    # entry chamfer at the top
    s = s.cut(cq.Workplane("XY", origin=(0, 0, zt - 3.0)).center(xm, yc).rect(2 * b, 2 * b)
              .workplane(offset=3.01).rect(2 * b + 6, 2 * b + 6).loft())
    return s


def make_lid():
    zt = L["Z_rt"]
    xm, yc = L["xm"], L["yc"]
    b = L["mag_in"] / 2 - P["CLR"]
    s = bx(xm - 22.5, xm + 22.5, yc - 22.5, yc + 22.5, zt, zt + 4.0)
    s = try_fillet(s, "|Z", 4.0)
    s = try_fillet(s, ">Z", 1.5)
    s = s.union(bx(xm - b, xm + b, yc - b, yc + b, zt - 5.0, zt + 0.01).edges("|Z").fillet(1))
    s = s.cut(bx(xm - b + 1.6, xm + b - 1.6, yc - b + 1.6, yc + b - 1.6, zt - 5.1, zt - 1.0))
    # finger notch on the front edge
    s = s.cut(cylX(xm - 12, xm + 12, yc - 22.5, zt + 4.0, 3.2))
    return s


def make_drum(angle=0.0):
    xm, yc, zd, R = L["xm"], L["yc"], L["zd"], P["DRUM_R"]
    DL = L["DL"]
    s = cylX(xm - DL / 2, xm + DL / 2, yc, zd, R)
    s = try_fillet(s, "%CIRCLE", 1.0)
    b = L["mag_in"] / 2
    pocket = bx(xm - b, xm + b, yc - b, yc + b, L["z_pocket_floor"], zd + R + 10)
    pocket = try_fillet(pocket, "|X and <Z", P["POCKET_FILLET"])
    s = s.cut(pocket)
    # axle stub (left) + horn-screw access bore
    s = s.union(cylX(xm - DL / 2 - P["AXLE_L"], xm - DL / 2 + 0.01, yc, zd, P["AXLE_D"] / 2))
    s = s.cut(cylX(xm - DL / 2 - P["AXLE_L"] - 1, xm + DL / 2 + 1, yc, zd, P["AXLE_BORE"] / 2))
    # adapter screw holes (inserts) on the right face
    for ang in (90, 210, 330):
        y, z = polar(ang, 9.0)
        s = s.cut(cylX(xm + DL / 2 - 6, xm + DL / 2 + 0.1, y, z, P["M3_INSERT"] / 2))
    return rot_about_drum_axis(s, angle) if angle else s


def horn_profile(offset=0.0, x0=0.0, x1=1.0):
    """cross-shaped servo horn (4 arms) extruded along X."""
    r, w = P["HORN_R"] + offset, P["HORN_ARM_W"] + 2 * offset
    a = bx(x0, x1, L["yc"] - w / 2, L["yc"] + w / 2, L["zd"] - r, L["zd"] + r)
    b = bx(x0, x1, L["yc"] - r, L["yc"] + r, L["zd"] - w / 2, L["zd"] + w / 2)
    hub = cylX(x0, x1, L["yc"], L["zd"], P["HORN_HUB_D"] / 2 + 1.5 + offset)
    return a.union(b).union(hub)


def make_adapter(angle=0.0):
    xm, yc, zd = L["xm"], L["yc"], L["zd"]
    x0 = xm + L["DL"] / 2
    x1 = x0 + L["adapter_t"]
    s = cylX(x0, x1, yc, zd, P["ADAPTER_D"] / 2)
    s = try_fillet(s, "%CIRCLE", 0.6)
    # horn key pocket on the servo side (depth 1.6)
    s = s.cut(horn_profile(0.25, x1 - 1.6, x1 + 0.1))
    s = s.cut(cylX(x0 - 1, x1 + 1, yc, zd, 3.0))                  # screwdriver access
    s = s.cut(cylX(x1 - 4.0, x1 + 1, yc, zd, 4.0))                # horn screw head
    for ang in (90, 210, 330):
        y, z = polar(ang, 9.0)
        s = s.cut(cylX(x0 - 1, x1 + 1, y, z, P["M3_CLEAR"] / 2))
        s = s.cut(cylX(x1 - 4.5, x1 + 1, y, z, 3.1))               # head counterbore
    for ang in (0, 180):  # M2 screws through horn arms (on the vertical arm pair)
        y, z = polar(ang + 45, P["HORN_HOLE_R"])
    for (dy, dz) in ((0, P["HORN_HOLE_R"]), (0, -P["HORN_HOLE_R"])):
        s = s.cut(cylX(x0 + 2.0, x1 + 1, yc + dy, zd + dz, P["M2_PILOT"] / 2))
    return rot_about_drum_axis(s, angle) if angle else s


def make_housing():
    xm, yc, zd = L["xm"], L["yc"], L["zd"]
    DL, c = L["DL"], P["CLR_ROT"]
    xi0, xi1 = xm - DL / 2 - c, xm + DL / 2 + c
    xl0 = xi0 - P["HOUSING_WALL_L"]
    r_out = P["TRANSPORT_R"] + P["SHELL_T"]
    zb, zt = L["z_base"], L["z_house_top"]
    # left cheek
    yb_ = yc + P["HOUSING_BACK"]
    left = bx(xl0, xi0 + 0.01, yc - r_out, yb_, zb, zt)
    left = left.cut(cylX(xl0 - 1, xi0 + 1, yc, zd, P["AXLE_D"] / 2 + 0.3))
    # right frame (drum passes through)
    right = bx(L["x_frameR0"] - 0.01, L["x_frameR1"], yc - r_out, yb_, zb, zt)
    right = right.cut(cylX(L["x_frameR0"] - 1, L["x_frameR1"] + 1, yc, zd, P["DRUM_R"] + c))
    for (y, z) in frame_insert_points():
        right = right.cut(cylX(L["x_frameR1"] - 6, L["x_frameR1"] + 0.1, y, z, P["M3_INSERT"] / 2))
    # shells
    front = sectorX(xi0, xi1, P["MAG_OPEN_ANG"], P["WINDOW_START"], P["TRANSPORT_R"], r_out)
    back = sectorX(xi0, xi1, P["WINDOW_END"], 360 - P["MAG_OPEN_ANG"], P["DRUM_R"] + c, P["DRUM_R"] + c + P["SHELL_T"])
    top = bx(xi0, xi1, yc - 24.0, yc + 24.0, zd + 18.0, zt)
    s = left.union(right).union(front).union(back).union(top)
    # rotor clearance: drum bore + transport arc
    cut = cylX(xi0, xi1, yc, zd, P["DRUM_R"] + c)
    cut = cut.union(sectorX(xi0, xi1, -P["MAG_OPEN_ANG"], P["WINDOW_START"] + 5, 0.0, P["TRANSPORT_R"]))
    s = s.cut(cut)
    # magazine opening + socket
    b = L["mag_in"] / 2
    s = s.cut(bx(xm - b, xm + b, yc - b, yc + b, zd, zt + 1))
    a = L["mag_out"] / 2 + P["CLR"]
    s = s.cut(bx(xm - a, xm + a, yc - a, yc + a, zt - 6.0, zt + 1))
    # release window: keep cheeks, open shell (already open by sector limits)
    # feet pads with M3 holes (back-left on cheek, back-right on frame)
    pads = bx(xl0, xi0 + 2.0, yc + 20.0, yb_, zb, zb + 5.0)
    pads = pads.union(bx(L["x_frameR0"] - 2.0, L["x_frameR1"], yc + 20.0, yb_, zb, zb + 5.0))
    s = s.union(pads)
    for (x, y) in boss_points_floor()[:2]:
        s = s.cut(cylZ(zb - 1, zt, x, y, P["M3_CLEAR"] / 2).intersect(bx(x - 5, x + 5, y - 5, y + 5, zb - 1, zb + 6)))
    return s


def frame_insert_points():
    yc, zd = L["yc"], L["zd"]
    return [(yc - 31.0, zd + 20.0), (yc + 31.0, zd + 20.0), (yc - 31.0, zd - 30.0), (yc + 31.0, zd - 30.0)]


def make_servo_bracket():
    yc, zd = L["yc"], L["zd"]
    r_out = P["TRANSPORT_R"] + P["SHELL_T"]
    zb = L["z_base"]
    ztop = P["Z_SPLIT"] - 0.4
    bp = bx(L["x_bp0"], L["x_bp1"], yc - r_out, yc + P["HOUSING_BACK"], zb, ztop)
    bp = bp.cut(cylX(L["x_bp0"] - 1, L["x_bp1"] + 1, yc, zd, P["ADAPTER_D"] / 2 + P["CLR_ROT"]))
    for (y, z) in frame_insert_points():
        bp = bp.cut(cylX(L["x_bp0"] - 1, L["x_bp1"] + 1, y, z, P["M3_CLEAR"] / 2))
    zc = L["z_sv_c"]
    mp = bx(L["x_mp0"], L["x_mp1"], yc - 28, yc + 28, zc - 31, min(zc + 31, ztop))
    mp = mp.cut(bx(L["x_mp0"] - 1, L["x_mp1"] + 1, yc - P["SV_W"] / 2 - 0.4, yc + P["SV_W"] / 2 + 0.4,
                   zc - P["SV_L"] / 2 - 0.4, zc + P["SV_L"] / 2 + 0.4))
    for sy in (-1, 1):
        for sz in (-1, 1):
            mp = mp.cut(cylX(L["x_mp0"] - 1, L["x_mp1"] + 1, yc + sy * P["SV_HOLE_W"] / 2,
                             zc + sz * P["SV_HOLE_L"] / 2, P["M3_INSERT"] / 2))
    rails = bx(L["x_bp1"] - 0.01, L["x_mp0"] + 0.01, yc + 22, yc + 28, zc - 31, min(zc + 31, ztop))
    rails = rails.union(bx(L["x_bp1"] - 0.01, L["x_mp0"] + 0.01, yc - 28, yc - 22, zc - 31, min(zc + 31, ztop)))
    foot = bx(L["x_bp0"], L["x_mp1"], yc - 28, yc + 28, zb, zb + 4.0)
    for (x, y) in boss_points_floor()[2:]:
        foot = foot.cut(cylZ(zb - 1, zb + 5, x, y, P["M3_CLEAR"] / 2))
    s = bp.union(mp).union(rails).union(foot)
    # horn swing clearance (radius HORN_R + 1.5)
    s = s.cut(cylX(L["x_bp1"] - 0.1, L["x_mp0"] + 0.1, yc, zd, P["HORN_R"] + 1.5))
    return s


def make_chute():
    xm, yc = L["xm"], L["yc"]
    x0, x1 = xm - L["DL"] / 2 - 0.2, xm + L["DL"] / 2 + 0.2   # fits between housing cheeks
    yF, zo = L["yF"], P["Z_OUTLET"]
    tr = L["tan_r"]
    z_end = L["zd"] - (P["DRUM_R"] + P["CLR_ROT"] + P["SHELL_T"]) - 1.5
    y_end = yF + (z_end - zo) / tr
    t = 2.4
    # ramp profile (Y,Z) extruded along X
    prof = [(yF, zo), (y_end, z_end), (y_end, z_end - t / math.cos(math.radians(P["RAMP_ANG"]))),
            (y_end, P["FLOOR"]), (L["yFi"] + 6, P["FLOOR"]), (L["yFi"] + 6, zo - t), (yF, zo - t)]
    ramp = cq.Workplane("YZ").polyline(prof).close().extrude(x1 - x0).translate((x0, 0, 0))
    # side walls inside the outlet zone + guide fins
    sw = 2.0
    walls = bx(x0, x0 + sw, yF, y_end, P["FLOOR"], z_end + 6)
    walls = walls.union(bx(x1 - sw, x1, yF, y_end, P["FLOOR"], z_end + 6))
    walls = walls.intersect(cq.Workplane("YZ").polyline(
        [(yF + 2.4, P["FLOOR"]), (y_end, P["FLOOR"]), (y_end, z_end + 8), (yF + 2.4, zo + P["OUTLET_H"] - 1)])
        .close().extrude(x1 - x0 + 2).translate((x0 - 1, 0, 0)))
    s = ramp.union(walls)
    # outlet lip must fit through the outlet opening
    s = s.cut(bx(x0 - 1, xm - P["OUTLET_W"] / 2 + 0.3, yF - 1, L["yFi"] + 0.01, 0, 100))
    s = s.cut(bx(xm + P["OUTLET_W"] / 2 - 0.3, x1 + 1, yF - 1, L["yFi"] + 0.01, 0, 100))
    return s, (y_end, z_end)


def make_tray():
    W = L["W"]
    yF = L["yF"]
    zf = P["Z_OUTLET"] - 1.0          # tray floor top (1 mm step below ramp lip)
    d = P["TRAY_D"]
    body = bx(-W / 2, W / 2, yF - d, yF, -P["TRAY_FLANGE_T"], zf + P["TRAY_LIP"])
    body = try_fillet(body, "|Z and <Y", 12.0)
    body = try_fillet(body, ">Z", 2.0)
    s = body.cut(bx(-W / 2 + 4, W / 2 - 4, yF - d + 4, yF + 1, zf, zf + 50)
                 .edges("|Z and <Y").fillet(8))
    s = try_fillet(s, "(not >Z) and (not <Z) and (not |Z) and (not >Y)", 0.0) if False else s
    flange = bx(-W / 2 + 6, W / 2 - 6, yF - 0.01, yF + P["TRAY_FLANGE"], -P["TRAY_FLANGE_T"], 0)
    flange = try_fillet(flange, "|Z and >Y", 5.0)
    s = s.union(flange)
    # hollow underside to save material
    s = s.cut(bx(-W / 2 + 4, W / 2 - 4, yF - d + 4, yF - 4, -P["TRAY_FLANGE_T"] - 1, zf - 2.0)
              .edges("|Z").fillet(6))
    for x in tray_screw_x():
        y = yF + 20
        s = s.cut(cylZ(-10, 1, x, y, P["M3_CLEAR"] / 2))
        s = s.cut(cq.Workplane("XY").add(cq.Solid.makeCone(3.4, 1.7, 1.8, cq.Vector(x, y, -P["TRAY_FLANGE_T"] - 0.01))))
    return s


def make_diffuser():
    xa, zl, yF = L["x_lcd"], L["z_led"], L["yF"]
    yfl = yF + (P["PANEL_T"] - P["PANEL_FLANGE"])
    s = cylY(yF + 0.2, L["y_pf"] + 0.01, xa, zl, P["DIFF_D"] / 2 - 0.1)
    s = s.union(cylY(L["y_pf"], L["y_pf"] + 1.6, xa, zl, P["DIFF_FLANGE_D"] / 2))
    s = try_fillet(s, "<Y", 0.8)
    return s


def make_outlet_flap():
    xm = L["xm"]
    y0 = L["yFi"]
    zo = P["Z_OUTLET"]
    s = bx(xm - P["OUTLET_W"] / 2 + 1.2, xm + P["OUTLET_W"] / 2 - 1.2, y0 + 0.2, y0 + 1.0, zo + 3.0, zo + P["OUTLET_H"] - 0.5)
    for i in range(1, 4):
        x = xm - P["OUTLET_W"] / 2 + i * P["OUTLET_W"] / 4
        s = s.cut(bx(x - 0.4, x + 0.4, y0, y0 + 2, zo + 1.0, zo + P["OUTLET_H"] - 2))
    return s


def make_rear_cover():
    W, zt = L["W"], L["Z_rt"]
    y0, y1 = L["yB"], L["yB"] + P["BACK_T"]
    s = bx(-W / 2, W / 2, y0, y1, 0, zt)
    s = try_fillet(s, "|Y", P["TOP_R"])
    s = try_fillet(s, ">Y", 0.8)
    for (x, z) in rear_boss_points(True) + rear_boss_points(False):
        s = s.cut(cylY(y0 - 1, y1 + 1, x, z, P["M3_CLEAR"] / 2))
        s = s.cut(cq.Workplane("XY").add(cq.Solid.makeCone(1.8, 3.3, 1.6, cq.Vector(x, y1 - 1.6, z), cq.Vector(0, 1, 0))))
    # breadboard tray T-slot rails (L-profiles) on the inner face
    xb = L["x_bb0"]
    zr0, zr1 = L["z_bb0"] - 1.0, zt - P["ROOF"] - 0.5
    for (v0, v1, l0, l1) in ((xb - 9, xb - 7, xb - 9, xb - 3), (xb + P["BB_W"] + 7, xb + P["BB_W"] + 9, xb + P["BB_W"] + 3, xb + P["BB_W"] + 9)):
        s = s.union(bx(v0, v1, L["y_tray0"] - 1.6, y0 + 0.01, zr0, zr1))
        s = s.union(bx(l0, l1, L["y_tray0"] - 1.6, L["y_tray0"] - 0.3, zr0, zr1))
    # USB-C (right-angle cable) exit at Nano position, DC jack cable entry, vents
    xn = L["x_bb0"] + P["BB_W"] / 2
    zu = L["z_bb0"] + P["BB_L"] - 8
    s = s.cut(bx(xn - 8, xn + 8, y0 - 3, y1 + 1, zu - 5, zu + 5).edges("|Y").fillet(3))
    s = s.cut(cylY(y0 - 1, y1 + 1, L["W"] / 2 - P["DC_X_FROM_RIGHT"], 22.0, 4.5))
    for i in range(6):
        x = L["x_e0"] + 10 + i * 8
        for (za, zb_) in ((P["Z_SPLIT"] + 8, P["Z_SPLIT"] + 38), (zt - 40, zt - 10)):
            s = s.cut(bx(x, x + 3.5, y0 - 1, y1 + 1, za, zb_).edges("|Y").fillet(1.7))
    xcomb = (L["x_e0"] + 0.5 + L["x_bb0"] - 9.5) / 2
    s = s.cut(cylY(y0 - 1, y1 + 1, xcomb, P["Z_SPLIT"] + 36, P["M3_CLEAR"] / 2))
    # French cleat on the outer face
    zc = P["MOUNT_Z"]
    xc0, xc1 = P["MOUNT_X"] - 40, P["MOUNT_X"] + 40
    cd = P["CLEAT_D"]
    cleat = cq.Workplane("YZ").polyline([(y1 - 0.01, zc + 0.4), (y1 + cd, zc - cd + 0.4), (y1 + cd, zc + P["CLEAT_H"]),
                                          (y1 - 0.01, zc + P["CLEAT_H"])]).close().extrude(xc1 - xc0).translate((xc0, 0, 0))
    s = s.union(cleat)
    return s


def make_tray_electronics():
    xb = L["x_bb0"]
    x0, x1 = xb - 6.6, xb + P["BB_W"] + 6.6
    z0, z1 = L["z_bb0"] - 1.6, L["Z_rt"] - P["ROOF"] - 1.0
    s = bx(x0, x1, L["y_tray0"], L["y_tray1"], z0, z1)
    s = s.union(bx(xb, xb + P["BB_W"], L["y_tray0"] - 3.0, L["y_tray0"] + 0.01, z0, z0 + 1.6))      # bottom stop
    s = s.union(bx(xb - 1.8, xb, L["y_tray0"] - 3.0, L["y_tray0"] + 0.01, z0, z1))                   # side locators
    s = s.union(bx(xb + P["BB_W"], xb + P["BB_W"] + 1.8, L["y_tray0"] - 3.0, L["y_tray0"] + 0.01, z0, z1))
    for x in (xb + 8, xb + P["BB_W"] - 14):                                                           # top snap clips
        s = s.union(bx(x, x + 6, L["y_tray0"] - P["BB_H"] - 1.6, L["y_tray0"] + 0.01,
                       L["z_bb0"] + P["BB_L"] + 0.3, L["z_bb0"] + P["BB_L"] + 2.0))
    xn = xb + P["BB_W"] / 2
    zu = L["z_bb0"] + P["BB_L"] - 8
    s = s.cut(bx(xn - 8, xn + 8, L["y_tray0"] - 4, L["y_tray1"] + 1, zu - 5, zu + 5))
    s = s.cut(bx(xb + 6, xb + P["BB_W"] - 6, L["y_tray0"] - 1, L["y_tray1"] + 1, z0 + 20, z0 + 120).edges("|Y").fillet(4))
    return s


def make_shelf_bracket():
    y_back = L["yB"] + P["BACK_T"]            # device rear face
    yb0 = y_back + P["CLEAT_D"]
    yb1 = yb0 + P["BRACKET_T"]
    zc = P["MOUNT_Z"]
    x0, x1 = P["MOUNT_X"] - P["BRACKET_W"] / 2, P["MOUNT_X"] + P["BRACKET_W"] / 2
    z0, z1 = zc - P["BRACKET_H"] + 30, zc + 30
    plate = bx(x0, x1, yb0, yb1, z0, z1)
    plate = try_fillet(plate, "|Y", 6.0)
    cd = P["CLEAT_D"]
    cleat = cq.Workplane("YZ").polyline([(y_back, zc), (y_back, zc - P["CLEAT_H"]), (yb0 + 0.01, zc - P["CLEAT_H"]),
                                          (yb0 + 0.01, zc - cd)]).close().extrude(x1 - x0 - 6).translate((x0 + 3, 0, 0))
    s = plate.union(cleat)
    # hooks into upright slots (two, upper) and M4 bolt holes (two, lower)
    hx = (P["MOUNT_X"] - P["UP_HOLE_X"], P["MOUNT_X"] + P["UP_HOLE_X"])
    p_ = P["UP_HOLE_PITCH"]
    zh = zc + 12.0
    for x in hx:
        tongue = bx(x - 2.5, x + 2.5, yb1 - 0.01, yb1 + P["UP_T"] + 1.0, zh - 6.5, zh + 3.0)
        drop = bx(x - 2.5, x + 2.5, yb1 + P["UP_T"] + 1.0 - 0.01, yb1 + P["UP_T"] + 4.0, zh - 14, zh + 3.0)
        s = s.union(tongue).union(drop)
        for k in (3, 4):
            s = s.cut(cylY(yb0 - 30, yb1 + 1, x, zh - k * p_, P["M4_CLEAR"] / 2))
    return s, (yb1, zh)


def make_cable_clip():
    # 2-channel cable comb on the rear cover, between partition and breadboard rail (1x M3)
    x0, x1 = L["x_e0"] + 0.5, L["x_bb0"] - 9.5
    y0, y1 = L["yB"] - 10.0, L["yB"]
    z0 = P["Z_SPLIT"] + 30
    s = bx(x0, x1, y0, y1, z0, z0 + 12)
    s = try_fillet(s, "|Y and <Y", 1.5)
    xc = (x0 + x1) / 2
    for dx in (-2.6, 2.6):
        s = s.cut(cylZ(z0 - 1, z0 + 13, xc + dx, y0 + 3.0, 2.2))
    s = s.cut(bx(x0 - 1, x1 + 1, y0 - 1, y0 + 1.6, z0 - 1, z0 + 13))
    s = s.cut(cylY(y0 - 1, y1 + 1, xc, z0 + 6, P["M3_CLEAR"] / 2))
    return s


def make_strain_relief():
    x = L["W"] / 2 - P["DC_X_FROM_RIGHT"]
    y0 = L["yB"] - 14
    s = bx(x - 9, x + 9, y0, y0 + 10, 14, 30)
    s = try_fillet(s, "|Y", 2.0)
    s = s.cut(cylY(y0 - 1, y0 + 11, x, 22, 2.6))
    s = s.cut(bx(x - 0.6, x + 0.6, y0 - 1, y0 + 11, 22, 31))
    return s


def make_calibration_coupon():
    # tolerance coupon: pins 3.0..4.2 in 0.3 steps against Ø4 holes + slot gauges, printed separately
    s = bx(0, 60, 0, 20, 0, 4)
    for i in range(5):
        s = s.cut(cylZ(-1, 5, 7 + i * 11, 6, 2.0 + i * 0.1))
        s = s.union(cylZ(4 - 0.01, 10, 7 + i * 11, 15, 1.85 + i * 0.1))
    return s.translate((L["W"] / 2 + 40, -60, 0))


# =============================================================================
# REFERENCE GEOMETRY (non-printable)
# =============================================================================
def chocolate(x, y, z0, rot=None):
    s = bx(x - P["CH_D"] / 2, x + P["CH_D"] / 2, y - P["CH_W"] / 2, y + P["CH_W"] / 2, z0, z0 + P["CH_T"])
    s = try_fillet(s, "|Z", 3.0)
    s = try_fillet(s, "not |Z", 1.5)
    return s


def chocolates_in_magazine():
    out = cq.Workplane("XY")
    z = L["z_crest"]
    for i in range(P["N_CAP"] - 1):
        out = out.union(chocolate(L["xm"], L["yc"], z + 0.05 + i * (P["CH_T"] + 0.05)))
    return out


def chocolate_in_pocket(angle=0.0):
    s = chocolate(L["xm"], L["yc"], L["z_pocket_floor"])
    return rot_about_drum_axis(s, angle) if angle else s


def servo_ref():
    yc, zc = L["yc"], L["z_sv_c"]
    x0, x1 = L["x_ct"], L["x_sv_bot"]
    case = bx(x0, x1, yc - P["SV_W"] / 2, yc + P["SV_W"] / 2, zc - P["SV_L"] / 2, zc + P["SV_L"] / 2)
    fl = bx(L["x_fl0"], L["x_fl1"], yc - P["SV_W"] / 2, yc + P["SV_W"] / 2, zc - P["SV_FLANGE_L"] / 2, zc + P["SV_FLANGE_L"] / 2)
    for sz in (-1, 1):
        for sy in (-1, 1):
            fl = fl.cut(cylX(L["x_fl0"] - 1, L["x_fl1"] + 1, yc + sy * P["SV_HOLE_W"] / 2, zc + sz * P["SV_HOLE_L"] / 2, P["SV_HOLE_D"] / 2))
    boss = cylX(x0 - (P["SV_TOTAL_H"] - P["SV_CASE_H"]), x0 + 0.01, yc, L["zd"], 3.0)   # output spline
    return case.union(fl).union(boss)


def horn_ref(angle=0.0):
    s = horn_profile(0.0, L["x_horn0"], L["x_horn0"] + P["HORN_T"])
    s = s.union(cylX(L["x_horn0"] + P["HORN_T"] - 0.01, L["x_ct"] - 0.2, L["yc"], L["zd"], P["HORN_HUB_D"] / 2)
                .cut(cylX(L["x_horn0"] + P["HORN_T"] - 1, L["x_ct"], L["yc"], L["zd"], 3.05)))
    return rot_about_drum_axis(s, angle) if angle else s


def breadboard_ref():
    x0 = L["x_bb0"]
    s = bx(x0, x0 + P["BB_W"], L["y_bb0"], L["y_tray0"], L["z_bb0"], L["z_bb0"] + P["BB_L"])
    s = s.cut(bx(x0 + P["BB_W"] / 2 - 1.5, x0 + P["BB_W"] / 2 + 1.5, L["y_bb0"] - 1, L["y_bb0"] + 2,
                 L["z_bb0"] + 3, L["z_bb0"] + P["BB_L"] - 3))
    return s


def nano_ref():
    xn = L["x_bb0"] + P["BB_W"] / 2
    z1 = L["z_bb0"] + P["BB_L"] - 2
    y = L["y_bb0"]
    pcb = bx(xn - P["NANO_W"] / 2, xn + P["NANO_W"] / 2, y - 10.5, y - 8.9, z1 - P["NANO_L"], z1)
    mod = bx(xn - 7, xn + 7, y - 13, y - 10.5, z1 - 26, z1 - 8)
    usb = bx(xn - 4.5, xn + 4.5, y - 13.7, y - 10.5, z1 - 7, z1 + 1)
    pins = bx(xn - P["NANO_W"] / 2 + 0.5, xn + P["NANO_W"] / 2 - 0.5, y - 8.9, y - 0.01, z1 - P["NANO_L"] + 1, z1 - 1)
    return pcb.union(mod).union(usb).union(pins.cut(bx(xn - 6.5, xn + 6.5, y - 9, y + 1, z1 - 50, z1 + 1)))


def wire_envelope():
    x0 = L["x_bb0"]
    return bx(x0, x0 + P["BB_W"], L["y_bb0"] - P["BB_WIRE"], L["y_bb0"], L["z_bb0"], L["z_bb0"] + P["BB_L"])


def lcd_ref():
    xa, z = L["x_lcd"], L["z_lcd"]
    yp = L["y_pf"]
    bez = bx(xa - P["LCD_BEZEL_W"] / 2, xa + P["LCD_BEZEL_W"] / 2, yp, yp + P["LCD_BEZEL_T"], z - P["LCD_BEZEL_H"] / 2, z + P["LCD_BEZEL_H"] / 2)
    y1 = yp + P["LCD_BEZEL_T"]
    pcb = bx(xa - P["LCD_PCB_W"] / 2, xa + P["LCD_PCB_W"] / 2, y1, y1 + P["LCD_PCB_T"], z - P["LCD_PCB_H"] / 2, z + P["LCD_PCB_H"] / 2)
    for sx in (-1, 1):
        for sz in (-1, 1):
            pcb = pcb.cut(cylY(y1 - 1, y1 + 3, xa + sx * P["LCD_HOLE_SX"] / 2, z + sz * P["LCD_HOLE_SY"] / 2, 1.5))
    y2 = y1 + P["LCD_PCB_T"]
    bp = bx(xa - P["BP_W"] / 2 + 6, xa + P["BP_W"] / 2 + 6, y2, y2 + P["BP_T"], z + P["LCD_PCB_H"] / 2 - P["BP_H"] - 1, z + P["LCD_PCB_H"] / 2 - 1)
    return bez.union(pcb).union(bp)


def lcd_conn_envelope():
    xa, z = L["x_lcd"], L["z_lcd"]
    y2 = L["y_pf"] + P["LCD_BEZEL_T"] + P["LCD_PCB_T"]
    x0 = xa + P["LCD_PCB_W"] / 2
    return bx(x0 - 3, x0 + P["LCD_CONN_CLR"] - 1, y2 + 2, y2 + 13, z + P["LCD_PCB_H"] / 2 - 15, z + P["LCD_PCB_H"] / 2 - 3)


def pir_ref():
    xa, z = L["x_lcd"], L["z_pir"]
    y0 = L["y_pf"] + P["PIR_SPACER"]
    pcb = bx(xa - P["PIR_PCB_W"] / 2, xa + P["PIR_PCB_W"] / 2, y0, y0 + 1.6, z - P["PIR_PCB_H"] / 2, z + P["PIR_PCB_H"] / 2)
    back = bx(xa - 12, xa + 12, y0 + 1.6, y0 + P["PIR_BACK"], z - 9, z + 9)
    base = bx(xa - 11.5, xa + 11.5, y0 - 2.0, y0 + 0.01, z - 11.5, z + 11.5)
    dome = cq.Workplane("XY").add(cq.Solid.makeSphere(P["PIR_LENS_D"] / 2, cq.Vector(xa, y0 - 2.0, z), angleDegrees1=-90, angleDegrees2=90))
    dome = dome.intersect(bx(xa - 20, xa + 20, y0 - P["PIR_LENS_H"], y0 - 2.0, z - 20, z + 20))
    return pcb.union(back).union(base).union(dome)


def ir_ref():
    xa, z = L["x_lcd"], L["z_ir"]
    y0 = L["y_pf"]
    body = bx(xa - 14.75, xa + 14.75, y0, y0 + P["IR_D"], z - P["IR_H"] / 2, z + P["IR_H"] / 2 - 4)
    ears = bx(xa - P["IR_L"] / 2, xa + P["IR_L"] / 2, y0 + P["IR_D"] - 2.0, y0 + P["IR_D"], z - 4, z + 4)
    for sx in (-1, 1):
        ears = ears.cut(cylY(y0, y0 + 20, xa + sx * P["IR_HOLE_SPAN"] / 2, z, 1.6))
    conn = bx(xa - 4, xa + 4, y0 + P["IR_D"] - 0.01, y0 + P["IR_D"] + P["IR_CONN"], z + 1, z + 6)
    lens = cq.Workplane("XY")
    for sx in (-1, 1):
        lens = lens.union(cylY(y0 - 0.6, y0 + 0.01, xa + sx * P["IR_LENS_SPACING"] / 2, z, P["IR_LENS_D"] / 2 - 0.5))
    return body.union(ears).union(conn).union(lens)


def neopixel_ref():
    xa, z = L["x_lcd"], L["z_led"]
    y0 = L["y_pf"] + P["LED_CHAMBER"] + 0.2
    return bx(xa - P["NEO_W"] / 2, xa + P["NEO_W"] / 2, y0, y0 + P["NEO_T"], z - P["NEO_H"] / 2, z + P["NEO_H"] / 2)


def upright_ref():
    yb1 = L["yB"] + P["BACK_T"] + P["CLEAT_D"] + P["BRACKET_T"]
    x0 = P["MOUNT_X"] - P["UP_W"] / 2
    zr0, zr1 = -900.0, 1100.0
    face = bx(x0, x0 + P["UP_W"], yb1, yb1 + P["UP_T"], zr0, zr1)
    side = bx(x0 + P["UP_W"] - P["UP_T"], x0 + P["UP_W"], yb1, yb1 + P["UP_SIDE"], zr0, zr1)
    s = face.union(side)
    zs = P["MOUNT_Z"] + 12.0
    k0 = int((zr0 - zs) / P["UP_HOLE_PITCH"]) + 1
    k1 = int((zr1 - zs) / P["UP_HOLE_PITCH"]) - 1
    holes = None
    for k in range(k0, k1):
        for sx in (-1, 1):
            h = bx(P["MOUNT_X"] + sx * P["UP_HOLE_X"] - P["UP_HOLE_W"] / 2, P["MOUNT_X"] + sx * P["UP_HOLE_X"] + P["UP_HOLE_W"] / 2,
                   yb1 - 1, yb1 + P["UP_T"] + 1, zs + k * P["UP_HOLE_PITCH"] - 7.5, zs + k * P["UP_HOLE_PITCH"] + 3.5)
            holes = h if holes is None else holes.union(h)
    return s.cut(holes)


def screw(p0, d, length, dia, head_d, head_h):
    """simple screw: shank along +d from p0 (head on -d side)."""
    shank = cyl(dia / 2, length, p0, d)
    hp = tuple(p0[i] - d[i] * head_h for i in range(3))
    head = cyl(head_d / 2, head_h, hp, d)
    return shank.union(head)


def fasteners():
    out = []
    zt = L["Z_rt"]
    y1 = L["yB"] + P["BACK_T"]
    for (x, z) in rear_boss_points(True) + rear_boss_points(False):
        out.append(("M3x10_rear_cover", screw((x, y1, z), (0, -1, 0), 10, 3, 5.5, 0.01)))
    for (y, z) in frame_insert_points():
        out.append(("M3x10_bracket_to_frame", screw((L["x_bp1"], y, z), (-1, 0, 0), 10, 3, 5.5, 2.0)))
    for sy in (-1, 1):
        for sz in (-1, 1):
            out.append(("M3x8_servo_flange", screw((L["x_fl1"], L["yc"] + sy * P["SV_HOLE_W"] / 2, L["z_sv_c"] + sz * P["SV_HOLE_L"] / 2),
                                                    (-1, 0, 0), 8, 3, 5.5, 2.0)))
    for (x, y) in boss_points_floor():
        z = L["z_base"] + (5.0 if x < L["x_bp0"] else 4.0)
        out.append(("M3x10_mechanism_to_floor", screw((x, y, z), (0, 0, -1), 10, 3, 5.5, 2.0)))
    for (x, y) in post_points():
        out.append(("M3x8_electronics_floor", screw((x, y, P["Z_SPLIT"] + 2.4), (0, 0, -1), 8, 3, 5.5, 1.4)))
    for x in tray_screw_x():
        out.append(("M3x8_tray", screw((x, L["yF"] + 20, -P["TRAY_FLANGE_T"]), (0, 0, 1), 8, 3, 5.5, 0.01)))
    ztab = zt - P["ROOF"] - 5.0 - 3.0
    for x in panel_tab_x():
        out.append(("M3x8_front_panel_tab", screw((x, L["y_pf"] + 4.0, ztab), (0, 0, 1), 8, 3, 5.5, 2.0)))
    x1 = L["xm"] + L["DL"] / 2 + L["adapter_t"]
    for ang in (90, 210, 330):
        y, z = polar(ang, 9.0)
        out.append(("M3x10_adapter_to_drum", screw((x1 - 4.5, y, z), (-1, 0, 0), 10, 3, 5.5, 2.0)))
    for dz in (P["HORN_HOLE_R"], -P["HORN_HOLE_R"]):
        out.append(("M2x8_horn_to_adapter", screw((L["x_horn0"] + P["HORN_T"], L["yc"], L["zd"] + dz), (-1, 0, 0), 8, 2, 3.8, 1.4)))
    for sx in (-1, 1):
        out.append(("M3x6_ir_sensor", screw((L["x_lcd"] + sx * P["IR_HOLE_SPAN"] / 2, L["y_pf"] + P["IR_D"] + 1.5, L["z_ir"]), (0, -1, 0), 6, 3, 5.5, 1.5)))
        out.append(("M2x5_pir", screw((L["x_lcd"] + sx * P["PIR_HOLE_SPAN"] / 2, L["y_pf"] + P["PIR_SPACER"] + 3.0, L["z_pir"]), (0, -1, 0), 5, 2, 3.8, 1.3)))
    for sx in (-1, 1):
        for sz in (-1, 1):
            out.append(("M2.5x6_lcd", screw((L["x_lcd"] + sx * P["LCD_HOLE_SX"] / 2, L["y_pf"] + P["LCD_BEZEL_T"] + P["LCD_PCB_T"] + 1.6,
                                              L["z_lcd"] + sz * P["LCD_HOLE_SY"] / 2), (0, -1, 0), 6, 2.5, 4.5, 1.6)))
    return out


# =============================================================================
# ASSEMBLY
# =============================================================================
def build():
    PARTS.clear()
    Z = P["Z_SPLIT"]
    add(name="P01_lower_module", layer="01_ENCLOSURE", shape=make_lower_module(), printable=True,
        material="PLA (matte white)", color=C_SHELL, explode=(0, 0, -120), print_rot=(),
        supports="none (outlet top edge = 36 mm bridge)", note="printed upright, floor on bed")
    add(name="P02_upper_column", layer="01_ENCLOSURE", shape=make_upper_column(), printable=True,
        material="PLA (matte white)", color=C_SHELL, explode=(0, 0, 90), print_rot=(("X", 180),),
        supports="none", note="printed upside down, roof on bed")
    add(name="P03_front_interface_panel", layer="02_FRONT_INTERFACE", shape=make_front_panel(), printable=True,
        material="PLA (matte graphite)", color=C_DARK, explode=(0, -110, 40), print_rot=(("X", -90),),
        supports="none (posts/chamber point up)", note="printed face down -> clean front surface")
    add(name="P04_rear_maintenance_cover", layer="01_ENCLOSURE", shape=make_rear_cover(), printable=True,
        material="PETG (structural, carries cleat)", color=C_SHELL, explode=(0, 140, 0), print_rot=(("X", 90),),
        supports="none (inner face up; cleat 45deg)", note="outer face on bed")
    add(name="P05_electronics_tray", layer="04_ELECTRONICS_MOUNTS", shape=make_tray_electronics(), printable=True,
        material="PLA", color=C_MECH, explode=(0, 95, 0), print_rot=(("X", -90),), supports="none")
    add(name="P06_electronics_floor_partition", layer="04_ELECTRONICS_MOUNTS", shape=make_electronics_floor(), printable=True,
        material="PLA", color=C_MECH, explode=(0, 0, 35), print_rot=(), supports="none")
    add(name="P07_chocolate_magazine", layer="05_CHOCOLATE_STORAGE", shape=make_magazine(), printable=True,
        material="PETG (translucent optional)", color=C_MECH, explode=(0, 0, 160), print_rot=(), supports="none")
    add(name="P08_refill_lid", layer="05_CHOCOLATE_STORAGE", shape=make_lid(), printable=True,
        material="PLA (signal red)", color=C_ACC, explode=(0, 0, 230), print_rot=(("X", 180),), supports="none")
    add(name="P09_dispenser_housing", layer="06_DISPENSING_MECHANISM", shape=make_housing(), printable=True,
        material="PETG", color=C_DARK, explode=(-40, 0, -40), print_rot=(("Y", 90),),
        supports="minimal: none if printed on left cheek (bore axis vertical)")
    add(name="P10_rotary_drum", layer="06_DISPENSING_MECHANISM", shape=make_drum(0), printable=True,
        material="PETG", color=C_ACC, explode=(-30, -60, -40), print_rot=(("Y", -90),), supports="none (pocket opens sideways, 3 mm fillets)")
    add(name="P11_servo_bracket", layer="07_SERVO_MOTOR", shape=make_servo_bracket(), printable=True,
        material="PETG", color=C_DARK, explode=(45, 0, -40), print_rot=(("Y", -90),), supports="none")
    add(name="P12_horn_adapter", layer="08_MECHANICAL_TRANSMISSION", shape=make_adapter(0), printable=True,
        material="PETG", color=C_MECH, explode=(25, -60, -40), print_rot=(("Y", 90),), supports="none")
    chute, ramp_end = make_chute()
    add(name="P13_exit_chute", layer="06_DISPENSING_MECHANISM", shape=chute, printable=True,
        material="PETG", color=C_MECH, explode=(0, -60, -100), print_rot=(("Y", 90),), supports="none (profile extrusion on its side)")
    add(name="P14_collection_tray", layer="09_COLLECTION_TRAY", shape=make_tray(), printable=True,
        material="PLA (matte graphite)", color=C_DARK, explode=(0, -120, -150), print_rot=(), supports="none")
    add(name="P15_neopixel_diffuser", layer="10_LIGHT_DIFFUSER", shape=make_diffuser(), printable=True,
        material="PETG natural / translucent white", color=C_TRANS, explode=(0, -150, 40), print_rot=(("X", -90),), supports="none")
    sb, _ = make_shelf_bracket()
    add(name="P16_shelving_mount_bracket", layer="11_SHELVING_MOUNT", shape=sb, printable=True,
        material="PETG, 100% walls around holes", color=C_DARK, explode=(0, 120, 60), print_rot=(("X", 90),), supports="none (hooks 45deg)")
    add(name="P17_cable_comb", layer="13_CABLE_ROUTING", shape=make_cable_clip(), printable=True,
        material="PLA", color=C_MECH, explode=(0, 60, 0), supports="none")
    add(name="P18_strain_relief", layer="13_CABLE_ROUTING", shape=make_strain_relief(), printable=True,
        material="PETG", color=C_MECH, explode=(0, 60, 0), supports="none")
    add(name="P19_outlet_flap_TPU_optional", layer="09_COLLECTION_TRAY", shape=make_outlet_flap(), printable=True,
        material="TPU 95A (optional finger guard)", color=(90, 90, 90), explode=(0, -40, -100), print_rot=(("X", -90),), supports="none")
    add(name="P20_tolerance_coupon", layer="16_PRINTABLE_PARTS", shape=make_calibration_coupon(), printable=True,
        material="same as production", color=C_MECH, supports="none", note="print first to tune insert/clearance holes")

    # ---- references ----
    add(name="REF_servo_DM996", layer="07_SERVO_MOTOR", shape=servo_ref(), color=(30, 30, 30), explode=(45, 0, -40))
    add(name="REF_servo_horn_original", layer="08_MECHANICAL_TRANSMISSION", shape=horn_ref(0), color=(20, 20, 20), explode=(35, -60, -40))
    add(name="REF_breadboard", layer="03_ELECTRONICS", shape=breadboard_ref(), color=(245, 245, 245), explode=(0, 95, 0))
    add(name="REF_arduino_nano_esp32", layer="03_ELECTRONICS", shape=nano_ref(), color=(20, 90, 150), explode=(0, 95, 0))
    add(name="REF_lcd1602_i2c", layer="03_ELECTRONICS", shape=lcd_ref(), color=C_PCB, explode=(0, -110, 40))
    add(name="REF_pir_hcsr501", layer="03_ELECTRONICS", shape=pir_ref(), color=(240, 240, 240), explode=(0, -110, 40))
    add(name="REF_ir_sharp_gp2y0a21", layer="03_ELECTRONICS", shape=ir_ref(), color=(25, 25, 25), explode=(0, -110, 40))
    add(name="REF_neopixel", layer="03_ELECTRONICS", shape=neopixel_ref(), color=(250, 250, 250), explode=(0, -110, 40))
    add(name="REF_chocolates_magazine", layer="00_REFERENCE", shape=chocolates_in_magazine(), color=C_CHOC, explode=(0, 0, 160))
    add(name="REF_chocolate_pocket", layer="00_REFERENCE", shape=chocolate_in_pocket(0), color=C_CHOC, explode=(-30, -60, -40))
    add(name="REF_shelving_upright", layer="00_REFERENCE", shape=upright_ref(), color=(175, 180, 186), explode=(0, 180, 60))
    add(name="ENV_jumper_wire_space", layer="13_CABLE_ROUTING", shape=wire_envelope(), color=(255, 180, 0), explode=(0, 95, 0))
    add(name="ENV_lcd_connector_space", layer="13_CABLE_ROUTING", shape=lcd_conn_envelope(), color=(255, 180, 0), explode=(0, -110, 40))
    return PARTS, ramp_end


def mechanism_states():
    """drum, chocolate, adapter, horn at rest / mid / dispense."""
    out = {}
    for tag, a in (("A_rest", P["ANGLE_REST"]), ("B_mid", P["ANGLE_MID"]), ("C_dispense", P["ANGLE_DISPENSE"])):
        out[tag] = dict(drum=make_drum(a), choc=chocolate_in_pocket(a), adapter=make_adapter(a), horn=horn_ref(a))
    return out


def swept_envelopes():
    yc, zd = L["yc"], L["zd"]
    xm, DL = L["xm"], L["DL"]
    rc = math.hypot(P["CH_W"] / 2, P["DRUM_R"])
    env_choc = sectorX(xm - P["CH_D"] / 2, xm + P["CH_D"] / 2, -32, P["ANGLE_DISPENSE"] + 32, 0, rc)
    env_horn = cylX(L["x_horn0"], L["x_horn0"] + P["HORN_T"], yc, zd, P["HORN_R"])
    env_drum = cylX(xm - DL / 2, xm + DL / 2 + L["adapter_t"], yc, zd, P["DRUM_R"])
    return dict(ENV_chocolate_sweep=env_choc, ENV_horn_sweep=env_horn, ENV_drum_rotor=env_drum)


if __name__ == "__main__":
    import json
    parts, ramp_end = build()
    print(json.dumps({k: (round(v, 2) if isinstance(v, float) else v) for k, v in L.items()}, indent=1))
    for p in parts:
        v = p.shape.val()
        print(f"{p.name:36s} valid={v.isValid()}  vol={v.Volume()/1000:.1f} cm3")
