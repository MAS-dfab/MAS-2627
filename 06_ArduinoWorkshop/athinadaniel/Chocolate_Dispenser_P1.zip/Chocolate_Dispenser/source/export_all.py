"""Export: Rhino 3dm (assembly + exploded), STEP (assembly + per part), STL/3MF (print-oriented), OBJ (named objects)."""
import os, json, math, sys
import numpy as np
import cadquery as cq
import rhino3dm as r3
import trimesh
import chocolate_dispenser as cd

OUT = sys.argv[1] if len(sys.argv) > 1 else "Chocolate_Dispenser"
for sub in ("STEP_parts", "STL_print_oriented", "3MF_print_oriented"):
    os.makedirs(os.path.join(OUT, sub), exist_ok=True)

parts, ramp_end = cd.build()
L, P = cd.L, cd.P
fast = cd.fasteners()
states = cd.mechanism_states()
envs = cd.swept_envelopes()

LAYERS = ["00_REFERENCE", "01_ENCLOSURE", "02_FRONT_INTERFACE", "03_ELECTRONICS", "04_ELECTRONICS_MOUNTS",
          "05_CHOCOLATE_STORAGE", "06_DISPENSING_MECHANISM", "07_SERVO_MOTOR", "08_MECHANICAL_TRANSMISSION",
          "09_COLLECTION_TRAY", "10_LIGHT_DIFFUSER", "11_SHELVING_MOUNT", "12_FASTENERS", "13_CABLE_ROUTING",
          "14_MOVEMENT_ENVELOPES", "15_DIMENSIONS", "16_PRINTABLE_PARTS"]
LAYER_COL = {"00_REFERENCE": (120, 72, 40), "01_ENCLOSURE": (236, 234, 228), "02_FRONT_INTERFACE": (62, 64, 68),
             "03_ELECTRONICS": (30, 110, 70), "04_ELECTRONICS_MOUNTS": (190, 192, 196), "05_CHOCOLATE_STORAGE": (190, 192, 196),
             "06_DISPENSING_MECHANISM": (214, 72, 58), "07_SERVO_MOTOR": (30, 30, 30), "08_MECHANICAL_TRANSMISSION": (150, 150, 150),
             "09_COLLECTION_TRAY": (62, 64, 68), "10_LIGHT_DIFFUSER": (250, 230, 225), "11_SHELVING_MOUNT": (62, 64, 68),
             "12_FASTENERS": (120, 120, 130), "13_CABLE_ROUTING": (255, 170, 0), "14_MOVEMENT_ENVELOPES": (255, 80, 200),
             "15_DIMENSIONS": (0, 0, 0), "16_PRINTABLE_PARTS": (40, 120, 170)}


def rgba(c, a=255):
    return (int(c[0]), int(c[1]), int(c[2]), a)


def to_tri(shape, tol=0.1, ang=0.2):
    v, f = shape.val().tessellate(tol, ang) if hasattr(shape, "val") else shape.tessellate(tol, ang)
    V = np.array([[p.x, p.y, p.z] for p in v]); F = np.array(f)
    tm = trimesh.Trimesh(V, F, process=True)
    tm.merge_vertices()
    return tm


def r3mesh(tm, offset=(0, 0, 0)):
    m = r3.Mesh()
    o = np.array(offset)
    for v in tm.vertices + o:
        m.Vertices.Add(float(v[0]), float(v[1]), float(v[2]))
    for f in tm.faces:
        m.Faces.AddFace(int(f[0]), int(f[1]), int(f[2]))
    m.Normals.ComputeNormals()
    m.Compact()
    return m


class Doc:
    def __init__(self):
        self.m = r3.File3dm()
        self.m.Settings.ModelUnitSystem = r3.UnitSystem.Millimeters
        self.m.Settings.ModelAbsoluteTolerance = 0.01
        self.idx = {}
        for n in LAYERS:
            self.layer(n, LAYER_COL[n])

    def layer(self, name, col=(128, 128, 128), parent=None, visible=True):
        key = f"{parent}::{name}" if parent else name
        if key in self.idx:
            return self.idx[key]
        ly = r3.Layer()
        ly.Name = name
        ly.Color = rgba(col)
        ly.Visible = visible
        if parent:
            ly.ParentLayerId = self.m.Layers.FindIndex(self.idx[parent]).Id
        i = self.m.Layers.Add(ly)
        self.idx[key] = i
        return i

    def attrs(self, name, layer_i, col=None):
        a = r3.ObjectAttributes()
        a.Name = name
        a.LayerIndex = layer_i
        if col is not None:
            a.ObjectColor = rgba(col)
            a.ColorSource = r3.ObjectColorSource.ColorFromObject
        return a

    def mesh(self, tm, name, layer_i, col=None, offset=(0, 0, 0)):
        self.m.Objects.AddMesh(r3mesh(tm, offset), self.attrs(name, layer_i, col))

    def write(self, fn):
        self.m.Write(fn, 7)


def build_doc(exploded=False):
    D = Doc()
    k = 1.25 if exploded else 0.0
    sub = {}
    for p in parts:
        if p.name == "P20_tolerance_coupon" and not exploded:
            continue
        li = D.idx[p.layer]
        if p.printable and p.layer not in ("16_PRINTABLE_PARTS",):
            pass
        off = tuple(k * v for v in p.explode)
        D.mesh(MESH[p.name], p.name, li, p.color, off)
    if not exploded:
        # fasteners
        li = D.idx["12_FASTENERS"]
        for i, (nm, sh) in enumerate(fast):
            D.mesh(to_tri(sh, 0.2), f"{nm}_{i:02d}", li, (120, 120, 130))
        # mechanism states on sublayers (B and C hidden)
        for tag, vis in (("A_rest", True), ("B_mid", False), ("C_dispense", False)):
            li = D.layer(f"STATE_{tag}", (214, 72, 58), parent="06_DISPENSING_MECHANISM", visible=vis)
            if tag == "A_rest":
                continue   # rest state = the main parts already placed
            for kk, sh in states[tag].items():
                D.mesh(to_tri(sh, 0.15), f"STATE_{tag}_{kk}", li, {"drum": (214, 72, 58), "choc": (120, 72, 40)}.get(kk, (150, 150, 150)))
        # envelopes
        li = D.idx["14_MOVEMENT_ENVELOPES"]
        for nm, sh in envs.items():
            D.mesh(to_tri(sh, 0.3), nm, li, (255, 80, 200))
        # cable routes (polylines)
        li = D.idx["13_CABLE_ROUTING"]
        xn = L["x_bb0"] + P["BB_W"] / 2
        routes = {
            "ROUTE_usb_c_to_nano": [(xn, L["yB"] + 30, L["z_bb0"] + P["BB_L"] - 8), (xn, L["y_bb0"] - 12, L["z_bb0"] + P["BB_L"] - 8)],
            "ROUTE_servo_power_dc": [(L["W"] / 2 - P["DC_X_FROM_RIGHT"], L["yB"] + 30, 22), (L["W"] / 2 - P["DC_X_FROM_RIGHT"], L["yB"] - 8, 22),
                                     (L["xR"] - 11, L["yB"] - 11, 30), (L["xR"] - 11, L["yB"] - 11, P["Z_SPLIT"] + 10), (L["x_bb0"] + 50, L["y_bb0"] - 5, P["Z_SPLIT"] + 20)],
            "ROUTE_servo_cable": [(L["x_sv_bot"], L["yc"] + 8, L["z_sv_c"] - 15), (L["x_sv_bot"] - 8, L["yc"] + 20, 60), (L["x_sv_bot"] - 8, L["yc"] + 20, P["Z_SPLIT"] + 5),
                                  (L["x_bb0"] + 10, L["y_bb0"] - 8, P["Z_SPLIT"] + 30)],
            "ROUTE_sensor_bundle": [(L["x_lcd"] + 30, L["y_pf"] + 20, L["z_lcd"]), (L["x_lcd"] + 30, L["y_pf"] + 28, L["z_ir"]), (L["x_bb0"] + 20, L["y_bb0"] - 10, L["z_ir"])],
        }
        for nm, pts in routes.items():
            pl = r3.Polyline()
            for q in pts:
                pl.Add(*q)
            D.m.Objects.AddPolyline(pl, D.attrs(nm, li, (255, 170, 0)))
        # dimensions: lines + text dots
        li = D.idx["15_DIMENSIONS"]
        W, Dd, H = L["W"], L["D"], L["H"]
        y = L["yF"] - 80
        dims = [((-W / 2, y, 0), (W / 2, y, 0), f"W {W:.0f}"), ((W / 2 + 30, L["yF"], 0), (W / 2 + 30, L["yB"] + P["BACK_T"], 0), f"D {Dd:.0f}"),
                ((W / 2 + 30, L["yF"], 0), (W / 2 + 30, L["yF"], H), f"H {H:.0f} (+4 lid)"),
                ((-W / 2 - 30, L["yF"], 0), (-W / 2 - 30, L["yF"], P["Z_SPLIT"]), f"seam {P['Z_SPLIT']:.0f}"),
                ((-W / 2 - 30, L["yF"], 0), (-W / 2 - 30, L["yF"], L["zd"]), f"drum axis {L['zd']:.0f}"),
                ((-W / 2, L["yF"] - P["TRAY_D"], -3), (-W / 2, L["yF"], -3), f"tray {P['TRAY_D']:.0f}")]
        for a, b, t in dims:
            D.m.Objects.AddLine(r3.Point3d(*a), r3.Point3d(*b), D.attrs("DIM_" + t, li))
            mid = tuple((a[i] + b[i]) / 2 for i in range(3))
            D.m.Objects.AddTextDot(t, r3.Point3d(*mid), D.attrs("DIM_" + t, li))
        # printable parts laid out in print orientation on build plates
        li = D.idx["16_PRINTABLE_PARTS"]
        for (nm, tm, plate_xy) in PRINT_LAYOUT:
            D.mesh(tm, "PRINT_" + nm, li, (40, 120, 170), offset=(plate_xy[0], plate_xy[1], 0))
        for (px, py, label) in PLATES:
            pl = r3.Polyline()
            for q in ((px, py, 0), (px + 256, py, 0), (px + 256, py + 256, 0), (px, py + 256, 0), (px, py, 0)):
                pl.Add(*q)
            D.m.Objects.AddPolyline(pl, D.attrs("BUILD_PLATE_" + label, li))
            D.m.Objects.AddTextDot(label, r3.Point3d(px + 10, py - 10, 0), D.attrs("BUILD_PLATE_" + label, li))
    else:
        li = D.idx["15_DIMENSIONS"]
        D.m.Objects.AddTextDot("Exploded along assembly vectors (x1.25). Sequence in TECHNICAL_DOCUMENTATION.md",
                               r3.Point3d(0, -300, 400), D.attrs("NOTE", li))
    return D


def print_oriented(p):
    s = p.shape
    for ax, deg in p.print_rot:
        axis = {"X": (1, 0, 0), "Y": (0, 1, 0), "Z": (0, 0, 1)}[ax]
        s = s.rotate((0, 0, 0), axis, deg)
    bb = s.val().BoundingBox()
    return s.translate((-bb.xmin, -bb.ymin, -bb.zmin))


if __name__ == "__main__":
    MESH = {p.name: to_tri(p.shape, 0.08 if p.printable else 0.15) for p in parts}
    # ---- per-part exports ----
    table = []
    oriented = {}
    for p in parts:
        if not p.printable:
            continue
        s = print_oriented(p)
        oriented[p.name] = s
        cq.exporters.export(s, os.path.join(OUT, "STL_print_oriented", p.name + ".stl"), tolerance=0.02, angularTolerance=0.1)
        tm = trimesh.load(os.path.join(OUT, "STL_print_oriented", p.name + ".stl"))
        tm.export(os.path.join(OUT, "3MF_print_oriented", p.name + ".3mf"))
        cq.exporters.export(p.shape, os.path.join(OUT, "STEP_parts", p.name + ".step"))
        bb = s.val().BoundingBox()
        v = p.shape.val().Volume()
        # mass estimate: 3 perimeters (1.2 mm) + 15% infill, from volume & area
        area = p.shape.val().Area()
        shell_v = min(v, area * 1.2 / 2)
        dens = 1.27 if "PETG" in p.material else (1.21 if "TPU" in p.material else 1.24)
        m = (shell_v + 0.15 * max(v - shell_v, 0)) / 1000 * dens
        table.append(dict(part=p.name, layer=p.layer, material=p.material, qty=p.qty,
                          print_bbox_mm=[round(bb.xlen, 1), round(bb.ylen, 1), round(bb.zlen, 1)],
                          solid_volume_cm3=round(v / 1000, 1), est_mass_g=round(m, 0), supports=p.supports,
                          watertight=bool(tm.is_watertight), note=p.note))
    json.dump(table, open(os.path.join(OUT, "parts_table.json"), "w"), indent=1)
    for p in parts:
        if not p.printable:
            cq.exporters.export(p.shape, os.path.join(OUT, "STEP_parts", p.name + ".step"))
    # ---- STEP assembly with names and colours ----
    asm = cq.Assembly(name="Chocolate_Dispenser")
    for p in parts:
        if p.name == "P20_tolerance_coupon":
            continue
        asm.add(p.shape, name=p.name, color=cq.Color(*[c / 255 for c in p.color]))
    asm.save(os.path.join(OUT, "Chocolate_Dispenser_Assembly.step"))
    # ---- print plate layout (simple shelf packing on 256 plates) ----
    PRINT_LAYOUT, PLATES = [], []
    order = sorted([(n, s) for n, s in oriented.items()], key=lambda t: -t[1].val().BoundingBox().xlen * t[1].val().BoundingBox().ylen)
    plates = []  # each: list of (name, x, y, w, h)

    def try_place(pl, w, h):
        # naive skyline: rows
        y = 4; rowh = 0; x = 4
        for (_, px, py, pw, ph) in pl:
            pass
        cand = [(4, 4)] + [(px + pw + 6, py) for (_, px, py, pw, ph) in pl] + [(4, py + ph + 6) for (_, px, py, pw, ph) in pl]
        for (cx, cy) in sorted(cand, key=lambda c: (c[1], c[0])):
            if cx + w > 252 or cy + h > 252:
                continue
            ok = all(cx >= px + pw + 5 or cx + w + 5 <= px or cy >= py + ph + 5 or cy + h + 5 <= py for (_, px, py, pw, ph) in pl)
            if ok:
                return cx, cy
        return None
    BYN = {p.name: p for p in parts}

    def mkey(n):
        m = BYN[n].material
        if "TPU" in m: return "TPU"
        if "translucent" in m and "PETG natural" in m: return "PETG translucent"
        if "PETG" in m: return "PETG"
        if "graphite" in m: return "PLA graphite"
        if "red" in m: return "PLA red"
        return "PLA white"
    plate_mat = []
    for n, s in order:
        bb = s.val().BoundingBox()
        w, h = bb.xlen, bb.ylen
        for pi, pl in enumerate(plates):
            if plate_mat[pi] != mkey(n):
                continue
            r = try_place(pl, w, h)
            if r:
                pl.append((n, r[0], r[1], w, h)); break
        else:
            plates.append([(n, 4, 4, w, h)]); plate_mat.append(mkey(n))
    for i, pl in enumerate(plates):
        px, py = 400 + (i % 4) * 300, -(i // 4) * 320 - 500
        PLATES.append((px, py, f"PLATE_{i + 1}_{plate_mat[i].replace(' ', '_')}"))
        for (n, x, y, w, h) in pl:
            PRINT_LAYOUT.append((n, to_tri(oriented[n], 0.2), (px + x, py + y)))
    json.dump([dict(plate=i + 1, material=plate_mat[i], parts=[n for (n, *_ ) in pl]) for i, pl in enumerate(plates)],
              open(os.path.join(OUT, "print_plates.json"), "w"), indent=1)
    # ---- 3dm ----
    build_doc(False).write(os.path.join(OUT, "Chocolate_Dispenser_Assembly.3dm"))
    build_doc(True).write(os.path.join(OUT, "Chocolate_Dispenser_Exploded.3dm"))
    # ---- OBJ with named objects + mtl ----
    with open(os.path.join(OUT, "Chocolate_Dispenser_Assembly.mtl"), "w") as f:
        for p in parts:
            c = [x / 255 for x in p.color]
            f.write(f"newmtl mat_{p.name}\nKd {c[0]:.3f} {c[1]:.3f} {c[2]:.3f}\nKa 0 0 0\nd 1\n\n")
    with open(os.path.join(OUT, "Chocolate_Dispenser_Assembly.obj"), "w") as f:
        f.write("# Chocolate Dispenser assembly - UNITS: MILLIMETRES (1 unit = 1 mm), Z up, front = -Y\n")
        f.write("# OBJ has no unit field: import with 'millimetres' / scale 1.0\nmtllib Chocolate_Dispenser_Assembly.mtl\n")
        base = 1
        for p in parts:
            if p.name == "P20_tolerance_coupon":
                continue
            tm = MESH[p.name]
            f.write(f"o {p.name}\ng {p.layer}\nusemtl mat_{p.name}\n")
            for v in tm.vertices:
                f.write(f"v {v[0]:.4f} {v[1]:.4f} {v[2]:.4f}\n")
            for fc in tm.faces:
                f.write(f"f {fc[0] + base} {fc[1] + base} {fc[2] + base}\n")
            base += len(tm.vertices)
    print("plates:", [[n for (n, *_ ) in pl] for pl in plates])
    print("exported to", OUT)
