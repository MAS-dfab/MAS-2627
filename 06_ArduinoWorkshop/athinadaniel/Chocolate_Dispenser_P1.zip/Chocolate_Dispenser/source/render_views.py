"""Render all documentation views from the generated CAD geometry."""
import math, os, sys
import numpy as np
from PIL import Image, ImageDraw
import cadquery as cq
import chocolate_dispenser as cd
from render import tess, render, Camera, font, screen_xy

OUT = sys.argv[1] if len(sys.argv) > 1 else "renders"
os.makedirs(OUT, exist_ok=True)
parts, ramp_end = cd.build()
L, P = cd.L, cd.P
BYNAME = {p.name: p for p in parts}
CACHE = {}

HIDE_DEFAULT = {"REF_shelving_upright", "P20_tolerance_coupon", "ENV_jumper_wire_space", "ENV_lcd_connector_space"}


def mesh_of(name, shape=None, tol=0.25):
    key = (name, id(shape) if shape is not None else 0)
    if key not in CACHE:
        CACHE[key] = tess(shape if shape is not None else BYNAME[name].shape, tol)
    return CACHE[key]


def items_for(names, offset=None, alpha=None, colors=None, shapes=None):
    out = []
    for n in names:
        sh = shapes.get(n) if shapes else None
        V, F = mesh_of(n, sh)
        if offset and n in offset:
            V = V + np.array(offset[n])
        a = (alpha or {}).get(n, 1.0)
        c = (colors or {}).get(n, BYNAME[n].color if n in BYNAME else (180, 180, 180))
        out.append(dict(V=V, F=F, color=c, alpha=a, edges=not n.startswith("REF_pir")))
    return out


def assembly_names(extra_hide=()):
    return [p.name for p in parts if p.name not in HIDE_DEFAULT and p.name not in extra_hide]


def save(im, name):
    im.save(os.path.join(OUT, name))
    print("saved", name)


SUB = f"{L['W']} x {L['D']} x {L['H'] + 4:.0f} mm (W x D x H, + tray 58 mm, + bracket)  |  capacity {P['N_CAP']} chocolates  |  CAD render, not to scale on screen"

# 1-4 orthographic + iso -------------------------------------------------------
names = assembly_names()
for fn, az, el, title in (("01_front_view.png", 0, 0, "Front view"), ("02_rear_view.png", 180, 0, "Rear view"),
                          ("03_side_view_right.png", 90, 0, "Side view (right)"),
                          ("04_isometric_view.png", -38, 24, "Isometric view")):
    im, _ = render(items_for(names), Camera(az=az, el=el), size=(1400, 1400), title=title, subtitle=SUB)
    save(im, fn)

im, _ = render(items_for(names), Camera(az=145, el=22), size=(1400, 1400), title="Rear isometric (cleat + maintenance cover)", subtitle=SUB)
save(im, "04b_rear_isometric.png")

# 5 exploded -----------------------------------------------------------------
ex_names = [p.name for p in parts if p.name not in ("REF_shelving_upright", "P20_tolerance_coupon", "ENV_jumper_wire_space",
                                                     "ENV_lcd_connector_space")]
k = 1.25
offs = {p.name: tuple(k * v for v in p.explode) for p in parts}
cam = Camera(az=-40, el=20)
labels = []
for n in ex_names:
    if not n.startswith("P"):
        continue
    bb = BYNAME[n].shape.val().BoundingBox()
    c = np.array([(bb.xmin + bb.xmax) / 2, (bb.ymin + bb.ymax) / 2, (bb.zmin + bb.zmax) / 2]) + np.array(offs[n])
    labels.append((c, n.split("_")[0]))
im, meta = render(items_for(ex_names, offset=offs), cam, size=(1700, 1700), title="Exploded axonometric",
                  subtitle="assembly sequence: P01 lower module > mechanism (P09-P13) > P06 floor > P02 column > P03 panel > P05/P04 rear > P07/P08 > P14 tray > P16 bracket",
                  labels=labels)
save(im, "05_exploded_axonometric.png")


# sections ---------------------------------------------------------------------
def section_items(names, keep_box, shapes=None, alpha=None):
    out = []
    for n in names:
        sh = (shapes or {}).get(n, BYNAME[n].shape if n in BYNAME else None)
        if sh is None:
            continue
        bb = sh.val().BoundingBox()
        kb = keep_box.val().BoundingBox()
        if bb.xmax < kb.xmin or bb.xmin > kb.xmax:
            continue
        try:
            s = sh.intersect(keep_box)
            if s.val().Volume() < 1e-3:
                continue
        except Exception:
            continue
        V, F = tess(s, 0.25)
        col = BYNAME[n].color if n in BYNAME else (150, 150, 150)
        out.append(dict(V=V, F=F, color=col, alpha=(alpha or {}).get(n, 1.0)))
    return out


sec_names = [p.name for p in parts if p.name not in ("REF_shelving_upright", "P20_tolerance_coupon", "ENV_lcd_connector_space")]
xa = L["x_lcd"]
kb = cd.bx(xa, 300, -300, 300, -100, 400)
it = section_items(sec_names, kb, alpha={"ENV_jumper_wire_space": 0.22})
im, meta = render(it, Camera(az=-90, el=0), size=(1300, 1600), title="Section A-A: electronics compartment",
                  subtitle=f"cut plane X = {xa:.1f} (front-element axis), viewed from -X. Orange = jumper-wire envelope ({P['BB_WIRE']:.0f} mm)")
d = ImageDraw.Draw(im)
for (p3, t) in (((xa, L["yF"], L["z_lcd"]), "LCD 1602 + I2C backpack"), ((xa, L["yF"], L["z_led"]), "NeoPixel light chamber + diffuser"),
                ((xa, L["yF"], L["z_pir"]), "PIR HC-SR501 lens"), ((xa, L["yF"], L["z_ir"]), "Sharp IR distance sensor"),
                ((xa, L["y_bb0"], L["z_bb0"] + 120), "breadboard + Nano ESP32 (on slide-out tray)"),
                ((xa, L["yc"], P["Z_SPLIT"] + 1.2), "electronics floor / partition"), ((xa, L["yc"], 45), "servo DM996")):
    x, y = screen_xy(Camera(az=-90, el=0), meta, p3)
    d.line([x, y, x - 0 if False else x, y], fill=(0, 0, 0))
    d.ellipse([x - 4, y - 4, x + 4, y + 4], fill=(200, 60, 50))
    d.text((x + 8, y - 10), t, fill=(20, 20, 20), font=font(17))
save(im, "06_section_electronics.png")

xm = L["xm"]
kb = cd.bx(xm, xm + 14, -300, 300, -100, 400)   # 14 mm slice: true profiles of shells, drum, ramp
it = section_items([n for n in sec_names if not n.startswith("ENV")], kb)
cam = Camera(az=-90, el=0)
im, meta = render(it, cam, size=(1300, 1600), title="Section B-B: chocolate storage + dispensing",
                  subtitle=f"14 mm slice at X = {xm:.1f} (magazine / drum axis), viewed from -X, drum at rest (0 deg). Front (-Y) is on the right.")
d = ImageDraw.Draw(im)
for (p3, t) in (((xm, L["yc"], L["Z_rt"] - 10), "refill lid + magazine (10 chocolates)"),
                ((xm, L["yc"], L["zd"] + 20), "pocket: exactly 1 chocolate"),
                ((xm, L["yc"] - 33, L["zd"] + 10), "transport shell R32"), ((xm, -20, 14), "exit ramp 30 deg"),
                ((xm, L["yF"] - 30, 3), "collection tray"), ((xm, 30, L["zd"]), "drum housing")):
    x, y = screen_xy(cam, meta, p3)
    d.ellipse([x - 4, y - 4, x + 4, y + 4], fill=(200, 60, 50))
    d.text((x + 8, y - 10), t, fill=(20, 20, 20), font=font(17))
save(im, "07_section_dispensing.png")

# 8 mechanism states ---------------------------------------------------------
states = cd.mechanism_states()
static = ["P09_dispenser_housing", "P13_exit_chute", "P01_lower_module", "P14_collection_tray", "P07_chocolate_magazine",
          "REF_chocolates_magazine", "P11_servo_bracket"]
kb = cd.bx(xm - 0.01, xm + 14, -300, 300, -100, 400)
panels = []
fitbox = None
for tag, ang in (("A_rest", 0), ("B_mid", 65), ("C_dispense", 130)):
    st = states[tag]
    shapes = {n: BYNAME[n].shape for n in static}
    shapes.update({"P10_rotary_drum": st["drum"], "REF_chocolate_pocket": st["choc"]})
    nm = static + ["P10_rotary_drum", "REF_chocolate_pocket"]
    it = section_items(nm, kb, shapes=shapes)
    if ang == 130:  # show chocolate leaving: place it on the ramp
        c = cd.chocolate(xm, 0, 0).rotate((0, 0, 0), (1, 0, 0), 30).translate((0, -24, 8))
        sec = c.intersect(kb)
        V, F = tess(sec, 0.25)
        it.append(dict(V=V, F=F, color=(160, 100, 60), alpha=0.55))
    cam = Camera(az=-90, el=0)
    fit = ((-75, -20), (60, 150))
    proj_fit = None
    im, meta = render(it, cam, size=(800, 900), title={"A_rest": "A  rest 0 deg", "B_mid": "B  transfer 65 deg", "C_dispense": "C  dispense 130 deg"}[tag],
                      fit=None, scale_bar=False)
    panels.append(im)
W_ = sum(p.width for p in panels)
sheet = Image.new("RGB", (W_, panels[0].height + 120), (247, 246, 243))
x = 0
for p in panels:
    sheet.paste(p, (x, 120)); x += p.width
d = ImageDraw.Draw(sheet)
d.text((28, 20), "Mechanism states (section B-B)", fill=(20, 20, 20), font=font(28, True))
d.text((28, 62), "A: pocket filled from stack  >  B: chocolate carried in transport arc, next chocolate lifted ~3.9 mm  >  C: pocket faces front-down, chocolate slides out onto the ramp  >  return to A",
       fill=(80, 80, 80), font=font(16))
sheet.save(os.path.join(OUT, "08_mechanism_states.png")); print("saved 08")

# 9 mechanism module iso -----------------------------------------------------
mech = ["P09_dispenser_housing", "P10_rotary_drum", "P11_servo_bracket", "P12_horn_adapter", "P13_exit_chute",
        "REF_servo_DM996", "REF_servo_horn_original", "REF_chocolate_pocket"]
im, _ = render(items_for(mech), Camera(az=-48, el=28), size=(1400, 1100), title="Dispensing module (removable as one unit)",
               subtitle="housing + rotary drum + horn adapter + servo bracket + DM996 + exit chute")
save(im, "09_mechanism_module.png")
offm = {"P10_rotary_drum": (0, -70, 0), "REF_chocolate_pocket": (0, -70, 0), "P12_horn_adapter": (35, -70, 0),
        "REF_servo_horn_original": (55, -70, 0), "P11_servo_bracket": (60, 0, 0), "REF_servo_DM996": (110, 0, 0),
        "P13_exit_chute": (0, -40, -60)}
im, _ = render(items_for(mech, offset=offm), Camera(az=-40, el=26), size=(1600, 1100), title="Dispensing module, exploded",
               subtitle="servo horn keyed into adapter (2x M2) > adapter screwed to drum (3x M3) > bracket bolts to housing frame (4x M3)")
save(im, "09b_mechanism_module_exploded.png")

# 10 installed context -------------------------------------------------------
Zi = 1050.0  # device bottom above floor (VERIFY)
ctx = []
dev = assembly_names() + ["REF_shelving_upright"]
for n in dev:
    V, F = mesh_of(n)
    ctx.append(dict(V=V + np.array([0, 0, Zi]), F=F, color=BYNAME[n].color))
yb1 = L["yB"] + P["BACK_T"] + P["CLEAT_D"] + P["BRACKET_T"]
def boxmesh(x0, x1, y0, y1, z0, z1, col, alpha=1.0, edges=True, fit=False):
    V, F = tess(cd.bx(x0, x1, y0, y1, z0, z1), 1.0)
    return dict(V=V, F=F, color=col, alpha=alpha, edges=edges, fit=fit)
ctx.append(boxmesh(-1600, 1400, -1500, 900, -10, 0, (205, 200, 192), edges=False))       # floor
# second upright + shelves (shelving unit to the right, behind glass line)
ux = P["MOUNT_X"] - P["UP_W"] / 2
ctx.append(boxmesh(ux, ux + 40, yb1 + 410, yb1 + 450, 0, 2050, (175, 180, 186)))   # rear upright (depth assumed)
ctx.append(boxmesh(ux + 40, ux + 600, yb1, yb1 + 450, 1960, 1985, (180, 184, 190), alpha=0.6))  # indicative top shelf only
# glass partition line behind the shelf and door opening to the left
gy = yb1 + 470
ctx.append(boxmesh(ux - 120, 1400, gy, gy + 12, 0, 2600, (200, 225, 235), alpha=0.25, edges=False))
ctx.append(boxmesh(ux - 170, ux - 120, gy - 40, gy + 40, 0, 2600, (225, 225, 228)))          # door frame post
ctx.append(boxmesh(ux - 1120, ux - 170, gy - 40, gy + 40, 2100, 2160, (225, 225, 228)))      # head
ctx.append(boxmesh(ux - 1170, ux - 1120, gy - 40, gy + 40, 0, 2600, (225, 225, 228)))
# door leaf open 90deg toward corridor, hinged on the far (left) jamb
ctx.append(boxmesh(ux - 1120, ux - 1080, gy - 900, gy - 40, 0, 2090, (230, 232, 234), alpha=0.5))
# person-scale reference (simple column)
pv, pf = tess(cq.Workplane("XY").add(cq.Solid.makeCylinder(160, 1750, cq.Vector(-700, -1100, 0))), 4.0)
# (person silhouette omitted for legibility)
ctx.append(boxmesh(ux - 1170, ux + 950, gy, gy + 1, 0, 2600, (0, 0, 0), alpha=0.0, fit=True))
cam = Camera(az=-22, el=10, persp=True, dist=5200, target=(-300, -200, 1100))
im, meta = render(ctx, cam, size=(1500, 1500), title="Installed on the shelving upright next to the classroom door",
                  subtitle=f"device bottom at {Zi:.0f} mm AFF (assumed), LCD at ~{Zi + L['z_lcd']:.0f} mm, IR/PIR aimed along the approach path. Door swings away from the upright (per photos).",
                  fit=None, margin=0.04, scale_bar=False)
save(im, "10_installed_context.png")
for c_ in ctx:
    c_["fit"] = False
for c_ in ctx[:len(dev)]:
    c_["fit"] = True
ctx[len(dev) - 1]["fit"] = False   # upright
cam = Camera(az=-55, el=8, persp=True, dist=2600, target=(0, 0, Zi + 120))
im, _ = render(ctx, cam, size=(1400, 1400), title="Installed - close-up", subtitle="French cleat on rear cover hangs on PETG bracket hooked into the upright perforations + 2x M4",
               fit=None, margin=0.14, scale_bar=False)
save(im, "10b_installed_closeup.png")
print("done")
