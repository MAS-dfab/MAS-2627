"""Geometric + mechanical validation of the chocolate dispenser model."""
import math, json, itertools, time
import numpy as np
import cadquery as cq
import trimesh
import chocolate_dispenser as cd

def vol_common(a, b):
    try:
        r = a.val().intersect(b.val()) if hasattr(a,'val') else a.intersect(b)
        return r.Volume()
    except Exception as e:
        return -1.0

def bbox_overlap(a, b, tol=0.0):
    A, B = a.val().BoundingBox(), b.val().BoundingBox()
    return not (A.xmax < B.xmin - tol or B.xmax < A.xmin - tol or A.ymax < B.ymin - tol or
                B.ymax < A.ymin - tol or A.zmax < B.zmin - tol or B.zmax < A.zmin - tol)

def run(report):
    parts, ramp_end = cd.build()
    L, P = cd.L, cd.P
    R = {"solids": [], "interference": [], "sweep": [], "build_volume": [], "checks": [], "notes": []}
    # 1. validity / closed / watertight
    for p in parts:
        v = p.shape.val()
        shells_closed = all(sh.Closed() for sh in v.Shells()) if hasattr(v, "Shells") else None
        import tempfile, os
        fn = os.path.join(tempfile.gettempdir(), "wt.stl")
        cq.exporters.export(p.shape, fn, tolerance=0.05, angularTolerance=0.2)
        tm = trimesh.load(fn)
        R["solids"].append(dict(name=p.name, valid=v.isValid(), n_solids=len(v.Solids()), closed=bool(shells_closed),
                                watertight=bool(tm.is_watertight), volume_cm3=round(v.Volume() / 1000, 2),
                                printable=p.printable))
    # 2. pairwise interference (static assembly, rest position)
    allowed = {("REF_chocolate_pocket", "P10_rotary_drum")}  # touching only, sanity
    names = [p for p in parts if p.name not in ("REF_shelving_upright", "P20_tolerance_coupon")]
    for a, b in itertools.combinations(names, 2):
        if a.name.startswith("ENV") or b.name.startswith("ENV"):
            other = b if a.name.startswith("ENV") else a
            if other.name.startswith("ENV") or other.name.startswith("REF_arduino") or other.name.startswith("REF_lcd"):
                continue   # envelopes intentionally contain their own components
        if not bbox_overlap(a.shape, b.shape):
            continue
        v = vol_common(a.shape, b.shape)
        if v > 0.5:
            R["interference"].append(dict(a=a.name, b=b.name, vol_mm3=round(v, 2)))
    # upright vs bracket only
    up = [p for p in parts if p.name == "REF_shelving_upright"][0]
    for p in parts:
        if p.name in ("P16_shelving_mount_bracket", "P04_rear_maintenance_cover", "P02_upper_column", "P01_lower_module"):
            v = vol_common(up.shape, p.shape)
            if v > 0.5:
                R["interference"].append(dict(a=up.name, b=p.name, vol_mm3=round(v, 2)))
    # 3. mechanism sweep: drum + chocolate + adapter + horn vs static neighbours
    static = {p.name: p.shape for p in parts if p.name in (
        "P09_dispenser_housing", "P11_servo_bracket", "P13_exit_chute", "P01_lower_module", "P07_chocolate_magazine",
        "REF_servo_DM996", "P06_electronics_floor_partition", "P02_upper_column")}
    mag_choc = [p for p in parts if p.name == "REF_chocolates_magazine"][0].shape
    worst = {}
    for ang in list(range(0, int(P["ANGLE_DISPENSE"]) + 1, 10)) + [int(P["ANGLE_DISPENSE"])]:
        movers = dict(drum=cd.make_drum(ang), adapter=cd.make_adapter(ang), horn=cd.horn_ref(ang))
        if ang < P["ANGLE_DISPENSE"]:
            movers["chocolate"] = cd.chocolate_in_pocket(ang)
        for mn, m in movers.items():
            for sn, s in static.items():
                if not bbox_overlap(m, s):
                    continue
                v = vol_common(m, s)
                if v > 0.5:
                    R["sweep"].append(dict(angle=ang, moving=mn, static=sn, vol_mm3=round(v, 2)))
        # chocolate #2 lift: pocket chocolate vs lowest magazine chocolate at this angle
        if ang < P["ANGLE_DISPENSE"] and ang <= 60:
            v = vol_common(movers["chocolate"], mag_choc)
            worst[ang] = round(v, 1)
    R["notes"].append({"pocket_chocolate_vs_stack_overlap_mm3_by_angle": worst,
                       "meaning": "non-zero = stack must be lifted by the trailing corner (expected, max lift computed below)"})
    # 4. analytic checks
    Rd, ch_w, ch_t = P["DRUM_R"], P["CH_W"], P["CH_T"]
    rc = math.hypot(ch_w / 2, Rd - P["POCKET_TOP_OFFSET"])
    R["checks"].append(dict(check="chocolate corner radius < transport shell radius", value=round(rc, 2),
                            limit=P["TRANSPORT_R"], ok=rc + 0.3 < P["TRANSPORT_R"]))
    lift = rc - Rd
    R["checks"].append(dict(check="max stack lift during transfer (mm)", value=round(lift, 2), ok=lift < 6))
    half = math.degrees(math.asin((L["mag_in"] / 2) / Rd))
    a = P["ANGLE_DISPENSE"]
    R["checks"].append(dict(check="pocket mouth inside release window at dispense",
                            value=[round(a - half, 1), round(a + half, 1)], limit=[P["WINDOW_START"], P["WINDOW_END"]],
                            ok=(a - half >= P["WINDOW_START"] - 3) and (a + half <= P["WINDOW_END"])))
    mu = 0.4
    tilt = a - 90.0
    slide_ok = math.tan(math.radians(90 - (180 - a))) if a < 180 else 0
    along = math.cos(math.radians(180 - a)); perp = math.sin(math.radians(180 - a))
    R["checks"].append(dict(check="chocolate slides out of pocket at dispense (gravity along pocket axis > friction)",
                            value=dict(along_g=round(along, 2), friction_g=round(mu * perp, 2), mu=mu), ok=along > mu * perp))
    m_stack = (P["N_CAP"] - 1) * P["CH_MASS_G"] / 1000 * 9.81
    t_lift = m_stack * (ch_w / 2) / 1000
    t_fric = 0.5 * m_stack * Rd / 1000
    t_req = t_lift + t_fric
    R["checks"].append(dict(check="servo torque (estimate, N.m)", value=dict(stack_N=round(m_stack, 2), lift=round(t_lift, 4),
                            friction=round(t_fric, 4), total=round(t_req, 4), servo_rated=P["SV_STALL_TORQUE_NM"],
                            safety_factor=round(P["SV_STALL_TORQUE_NM"] / t_req, 1)), ok=P["SV_STALL_TORQUE_NM"] / t_req > 5))
    # pocket holds exactly one chocolate
    pocket_depth = Rd - (L["z_pocket_floor"] - L["zd"])
    R["checks"].append(dict(check="pocket depth vs chocolate thickness (one per cycle)", value=round(pocket_depth, 2),
                            limit=[ch_t, 1.5 * ch_t], ok=ch_t <= pocket_depth + 0.01 < 1.5 * ch_t))
    # magazine ↔ pocket ↔ chute ↔ tray alignment
    R["checks"].append(dict(check="magazine axis == drum pocket axis (x,y)", value=[L["xm"], L["yc"]], ok=True))
    R["checks"].append(dict(check="outlet centred on drum axis X", value=L["xm"], ok=True))
    y_end, z_end = ramp_end
    shell_bottom_outer = L["zd"] - (Rd + P["CLR_ROT"] + P["SHELL_T"])
    R["checks"].append(dict(check="ramp top end below drum shell (no gap for chocolate to slip behind)",
                            value=dict(ramp_end_y=round(y_end, 1), ramp_end_z=round(z_end, 1), shell_bottom_z=round(shell_bottom_outer, 1)),
                            ok=z_end < shell_bottom_outer and (shell_bottom_outer - z_end) < 0.5 * ch_t))
    mouth_y, mouth_z = cd.polar(a, Rd * 0.75)
    ramp_z_at = P["Z_OUTLET"] + (mouth_y - L["yF"]) * L["tan_r"]
    R["checks"].append(dict(check="drop height pocket mouth -> ramp (mm)", value=round(mouth_z - ramp_z_at, 1), ok=mouth_z > ramp_z_at))
    R["checks"].append(dict(check="tray floor below outlet lip", value=dict(tray_floor=P["Z_OUTLET"] - 1, outlet=P["Z_OUTLET"]), ok=True))
    # breadboard fits electronics column height
    room = (L["Z_rt"] - P["ROOF"]) - L["z_bb0"]
    R["checks"].append(dict(check="breadboard length fits electronics column (mm spare)", value=round(room - P["BB_L"], 1), ok=room > P["BB_L"]))
    gap = (L["y_bb0"] - P["BB_WIRE"]) - (L["y_pf"] + P["LCD_BEZEL_T"] + P["LCD_PCB_T"] + P["BP_T"])
    R["checks"].append(dict(check="free depth between LCD stack and jumper-wire envelope (mm)", value=round(gap, 1), ok=gap >= 3))
    # servo below electronics floor
    R["checks"].append(dict(check="servo flange top below electronics floor", value=round(L["z_sv_c"] + P["SV_FLANGE_L"] / 2, 1),
                            limit=P["Z_SPLIT"], ok=L["z_sv_c"] + P["SV_FLANGE_L"] / 2 < P["Z_SPLIT"]))
    # finger-reach: distance from outlet plane to nearest moving edge
    dist = math.hypot(mouth_y - L["yF"], mouth_z - (P["Z_OUTLET"] + P["OUTLET_H"]))
    R["checks"].append(dict(check="outlet opening -> pocket mouth distance (finger reach, mm)", value=round(dist, 1), ok=dist > 25,
                            note="ISO 13857 for children needs far more; TPU flap P19 + slow servo motion recommended"))
    # 5. build volume per printable part (in print orientation)
    bx_, by_, bz_ = P["BUILD"]
    for p in parts:
        if not p.printable:
            continue
        s = p.shape
        for ax, deg in p.print_rot:
            axis = {"X": (1, 0, 0), "Y": (0, 1, 0), "Z": (0, 0, 1)}[ax]
            s = s.rotate((0, 0, 0), axis, deg)
        bb = s.val().BoundingBox()
        dims = sorted([bb.xlen, bb.ylen])
        ok = dims[1] <= max(bx_, by_) and dims[0] <= min(bx_, by_) and bb.zlen <= bz_
        R["build_volume"].append(dict(name=p.name, x=round(bb.xlen, 1), y=round(bb.ylen, 1), z=round(bb.zlen, 1), fits=ok))
    return R, parts

if __name__ == "__main__":
    t = time.time()
    R, parts = run(True)
    json.dump(R, open("validation_report.json", "w"), indent=1)
    print("bad solids:", [s for s in R["solids"] if not (s["valid"] and s["closed"] and s["watertight"])])
    print("interference:"); [print(" ", i) for i in R["interference"]]
    print("sweep:"); [print(" ", i) for i in R["sweep"]]
    print("checks:"); [print(" ", c) for c in R["checks"]]
    print("build:", [b for b in R["build_volume"] if not b["fits"]])
    print(R["notes"])
    print("time", round(time.time() - t))
