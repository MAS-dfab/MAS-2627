# Interactive Chocolate Dispenser - CAD package (rev P1)
Open `Chocolate_Dispenser_Assembly.3dm` in Rhino (mm). Exact NURBS solids: `Chocolate_Dispenser_Assembly.step`.
Print files: `3MF_print_oriented/` (pre-oriented, 1:1 mm). Start with P20_tolerance_coupon.
Everything is parametric: edit `P` in `source/chocolate_dispenser.py`, then run
`python export_all.py OUT && python validate.py && python render_views.py OUT/renders`.
Full documentation, BOM, assembly, risks and unverified dimensions: `TECHNICAL_DOCUMENTATION.md`.
